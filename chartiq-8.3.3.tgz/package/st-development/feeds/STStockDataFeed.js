/**
 *	2.2.0
 *	customized quotefeed
 */
const quoteFeedSimulator = {};
import {config} from "./STDataFeedAccessUrl.js"
import {CIQ} from "chartiq/js/standard.js"
import axios from "axios"
import jutils from 'jutils-src'
import LRUCache from 'lru-cache';

// 目前只给pairdata LRU缓存
const cache = new LRUCache({
  max: 100, // 缓存的最大项数
  maxAge: 1000 * 60 * 5, // 缓存项的生命周期为5分钟
});
function getCachedData(url) {
    const cachedData = cache.get(url);
    if (cachedData) {
        // console.log('!!!!get cachedData!!!!: ',cachedData.config.url)
        return Promise.resolve(cachedData);
    } else {
        return CIQ.axios.get(url).then((response) => {
            cache.set(url, response);
            return response;
        });
    }
}

quoteFeedSimulator.sendAjax = async function (url, cb) {
    let stockName = CIQ.store.state.stocksList.find(x=>x.stock==CIQ.stxx.chart.symbol)
    let indexName = CIQ.store.state.indexsList.find(x=>x.symbol==CIQ.stxx.chart.symbol)
    CIQ.stxx.chart.symbolDisplay = stockName?stockName.name:indexName.name
    try{
        const res = await getCachedData(url)
        if(res.status==200){
            cb(res.status, res.data);
        }else{
            cb(500)
        }
    }catch(error){
        cb(500)
    }

};

quoteFeedSimulator.url = config.pairDataUrl;
quoteFeedSimulator.indicatorsList = []

quoteFeedSimulator.sendReq = async function(symbol,start,end,new_str,freq,cb){
        var queryUrl = this.url + 
        "?symbol=" + symbol + 
        new_str +
        "&start="+start+
        "&end=" + end +
        "&freq=" + freq
       
    // set initial symbol value to the form
    //utils.setSymbol(symbol)

    CIQ.symbol = symbol;
    try{
        var favoriteSymbolList = []
        var favoriteIndicatorList = []
        if(CIQ.store.state.favoriteSymbolList.length>0){
            favoriteSymbolList = CIQ.store.state.favoriteSymbolList
        }else{
            const data = await CIQ.getFavorite()
            try{
                favoriteSymbolList = JSON.parse(data.favorite_symbol)
                favoriteIndicatorList = JSON.parse(data.favorite_indicator)
            }catch{}
        }
        
        CIQ.store.commit('setFavoriteIndicatorList',favoriteIndicatorList)
        CIQ.store.commit('setFavoriteSymbolList',favoriteSymbolList)
        //console.log("quoteFeedSimulator.sendReq",favoriteSymbolList)
        try{
            var div = document.querySelectorAll(".cq-comparison-new")[0].querySelectorAll("button")[0]
            var count=0;
            for(var item in favoriteSymbolList){
                if(favoriteSymbolList[item] == CIQ.symbol){
                    // del
                    div.style.cssText = "width: 188px;height: 35px;border-radius: 20px;border: 0.1rem rgb(80, 166, 252) solid;font-size: 0.6rem;font-weight:bold;background: #409EFF;color: white;font-family: Helvetica, sans-serif;cursor:pointer"
                    div.innerHTML = "<div><svg t='1638255076868' class='button_icon' viewBox='0 0 1024 1024' version='1.1' xmlns='http://www.w3.org/2000/svg' p-id='2654' width='200' height='200'><path d='M885.942179 427.687756l-267.445168-22.933315-104.470353-246.470461L409.553235 404.75444l-267.336698 22.933315 202.846918 175.770236-60.789505 261.34524 229.753731-138.569986 229.859132 138.569986-60.785411-261.34524L885.942179 427.687756zM514.026658 656.403854l-139.875724 84.425831 37.038568-159.160953-123.591853-106.975407 162.91751-14.053064 63.511499-150.116973 63.620993 150.116973 162.860205 14.053064-123.534548 106.975407 37.038568 159.160953L514.026658 656.403854z' p-id='2655' fill='#FFFFFF'></path></svg><span>Remove from favorites</span></div>";
                    div.attributes.stxtap.nodeValue="SentimentLook.delSymbolCookie()";
                    count++
                }
            }
            if (count === 0){
                // add
                //document.querySelectorAll(".cq-comparison-new")[0].classList.remove('stxMenuActive')
                div.style.cssText = "width: 188px;height: 32px;border-radius: 20px;border: 0.1rem rgb(80, 166, 252) solid;font-size: 0.6rem;font-weight:bold;background: #f8f8f9;font-family: Helvetica, sans-serif;cursor:pointer;color: #666"
                div.innerHTML = "<div><svg t='1638255076868' class='button_icon' viewBox='0 0 1024 1024' version='1.1' xmlns='http://www.w3.org/2000/svg' p-id='2654' width='200' height='200'><path d='M885.942179 427.687756l-267.445168-22.933315-104.470353-246.470461L409.553235 404.75444l-267.336698 22.933315 202.846918 175.770236-60.789505 261.34524 229.753731-138.569986 229.859132 138.569986-60.785411-261.34524L885.942179 427.687756zM514.026658 656.403854l-139.875724 84.425831 37.038568-159.160953-123.591853-106.975407 162.91751-14.053064 63.511499-150.116973 63.620993 150.116973 162.860205 14.053064-123.534548 106.975407 37.038568 159.160953L514.026658 656.403854z' p-id='2655' fill='#1296db'></path></svg><span>Add to favorites</span></div>";
                div.attributes.stxtap.nodeValue="SentimentLook.addSymbolCookie()";
            }
        }catch(e){
            //console.error(e)
        }
    }catch(e){
        //console.error(e)
    }

    this.sendAjax(queryUrl,async function (status, response){
        const isWholeData = CIQ.initialDate.start==parseInt(process.env.VUE_APP_START_DATE)
        console.log("we load all of the data in the same time:",isWholeData)
        if (status == 200){
            var newQuotes = await quoteFeedSimulator.formatChartData(response);
            //window.sessionStorage.setItem('isValid', true)
            //console.log('sendAjax:',newQuotes)
            cb({
                moreAvailable:isWholeData?false:true,
                quotes:newQuotes,
                upToDate: true  // set to true in the initial and pagination fetch callbacks if the responses do not require more "future" data (i.e., forward pagination)
            });
            let view = CIQ.stxx.exportLayout()

        }else{
            cb({error:response ? response : status});
        }
    });
}

quoteFeedSimulator.fetchInitialData = function(symbol,startDate,endDate,params,cb){
    // initEndDate for testing
    //CIQ.updateFavorite(JSON.stringify([]),JSON.stringify([]))	
    this.initEndDate = endDate 
    var oneYear = (24 *60 *60 *1000) * 365

    // 466963200000
    // -138009600000
    var startDateParse = Date.parse(params.symbolObject.startDate?params.symbolObject.startDate:startDate)
    var endDateParse = Date.parse(params.symbolObject.endDate?params.symbolObject.endDate:endDate)
    var start = config.timestampToTime(startDateParse)
    var end = config.timestampToTime(endDateParse)
    console.log('Initial urlstart: '+start + ' end:'+end);
    
    // CIQ.initialDate is provided for Marker
    CIQ.initialDate = {start:startDateParse,end:endDateParse}

    //this.fetchStatus(symbol,start,end,params.symbolObject.indicator)
    CIQ.symbol = symbol;
    
    if (params.symbolObject.indicator === undefined){
        if (CIQ.objIndicator === undefined){
            CIQ.objIndicator = 'AAPL'
            // AAPL
        }
    }else if(params.symbolObject.indicator.length == 0){
        //console.log('load default symbol as indicator', CIQ.objIndicator)
        // when first time loading a technical indicator, no params of indicators in query, pick default value
        CIQ.objIndicator = ['AAPL']
    }else {
        CIQ.objIndicator = params.symbolObject.indicator
    }
    var new_str = ''

    if (CIQ.indicatorList) {
        if (CIQ.indicatorList.length != 0) {
            // console.log(
            //     'data already in indicatorList from datafeed',
            //     CIQ.indicatorList.length
            // )
            this.indicatorsList = CIQ.store.state.indicatorsList
            this.indicatorsList = CIQ.indicatorList

            CIQ.store.commit('getIndicatorsList',this.indicatorsList)
            CIQ.store.commit('getAllSymbolsList',this.indicatorsList);

            var orignalFreq = 'daily'
            var selectedFreq = 'daily'

            let techList = CIQ.store.state.indicators.technicalIndicators
            let list = []
            for(var i in CIQ.objIndicator){
                if(techList.indexOf(CIQ.objIndicator[i]) == -1){
                    list.push(CIQ.objIndicator[i])
                }
            }

            if(params.symbolObject.indicator === undefined){
                // freq is daily when using default indicator
                new_str += '&indicator=' +CIQ.objIndicator;
            }else if(list.length == 0){
                new_str += '&indicator=' +'AAPL'
            }else{
                try{
                    var freqList = []
                    // console.log("CIQ.objIndicator: ",CIQ.objIndicator)
                    // console.log('current entry/exit: ',CIQ.store.state.indicators.formIndicators)

                    for ( var  i = 0,valid = 0 ; i < CIQ.objIndicator.length;i++) {
                        // when both sentiment and tech exist in CIQ.objIndicator, filter tech indicator
                        if(CIQ.isSentiIndicator(CIQ.objIndicator[i])){
                            let _obj = this.indicatorsList.find(x => x.url == CIQ.objIndicator[i])
                            freqList.push(_obj.updated)
                            
                            new_str += `${valid==0?'&indicator=':`&indicator_${valid+1}=`}`+CIQ.objIndicator[i];
                            valid++
                            continue
                        }
                        // 之后加一个symbol判断和小李新senti判断
                        if(CIQ.isUserIndicator(CIQ.objIndicator[i])){       
                            new_str += `${valid==0?'&indicator=':`&indicator_${valid+1}=`}`+CIQ.objIndicator[i];
                            valid++
                            continue
                        }
                    }
                    
                    if(freqList.find(item => item=="Weekly"))  orignalFreq= 'weekly';   
                    if(freqList.find(item => item=="Monthly"))  orignalFreq= 'monthly';  
                }catch(err){
                    console.error(err)
                }
            } 
            // orignalFreq is the minimum timeframe, selectedFreq is the timeframe sent to req, default value is orignalFreq
            selectedFreq = orignalFreq
            switch(CIQ.store.state.exitFrequency){
                case "Monthly":{
                    selectedFreq = "monthly"
                    break;
                }
                case "Weekly":{
                    if(orignalFreq != 'monthly'){
                        selectedFreq = "weekly"
                    }
                    break;
                }
                case "Daily":{
                    if(orignalFreq != 'monthly' && orignalFreq != 'weekly'){
                        selectedFreq = "daily"
                    } 
                    break;
                }
                default: {
                    break;
                }
            }
            var restoreFreq = CIQ.store.state.restoreFreq
            if(restoreFreq != ''){
                selectedFreq = restoreFreq
            }
            CIQ.store.commit('setRestoreFreq', '')
            
            // setFreq firstly called when loading aapl symbol during chart initiation, the value is daily by default
            CIQ.store.commit('setFreqency',selectedFreq)
 
            try{
                switch(selectedFreq){
                    case "monthly":{
                        CIQ.periodicity.timeUnit = 'month'
                        break;
                    }
                    case "weekly":{
                        CIQ.periodicity.timeUnit = 'week'
                        break;
                    }
                    case "daily":{    
                        CIQ.periodicity.timeUnit = 'day'
                        break;
                    }
                    default:
                }
            }catch(err){}
            
            var daily=[],weekly=[],monthly=[]
            var nodeSetup = document.getElementsByTagName('li')

            for(var i =0;i<nodeSetup.length;i++){
                for(var j in nodeSetup[i].firstChild){
                    if(j == 'textContent'){
                        if(nodeSetup[i].firstChild.textContent === 'Daily'){
                            daily.push(nodeSetup[i])
                        }
                        if(nodeSetup[i].firstChild.textContent === 'Weekly'){
                            weekly.push(nodeSetup[i])
                        }
                        if(nodeSetup[i].firstChild.textContent === 'Monthly'){
                            monthly.push(nodeSetup[i])
                        }
                    }
                }		
			}
        
            var node = document.querySelector("cq-menu-container[cq-name = 'menuPeriodicity']")
            for(var i = 0;i < node.children.length;i++){
                node.children[i].style.display = "inherit"
            }

            //console.log("orignalFreq: ",orignalFreq)

            if(orignalFreq == "monthly"){
                for(var i = 0;i < node.children.length;i++){            
                    if(node.children[i].firstChild.nodeValue == '1 D'){
                        node.children[i].setAttribute('tf','disabled')
                    }
                }
                for(var i = 0;i < node.children.length;i++){            
                    if(node.children[i].firstChild.nodeValue == '1 W'){
                        node.children[i].setAttribute('tf','disabled')
                    }
                }
                

                for(var i = 0;i <daily.length;i++){
                    daily[i].setAttribute('tf','disabled')
                }
                for(var i = 0;i <weekly.length;i++){
                    weekly[i].setAttribute('tf','disabled')
                }
            }else if(orignalFreq == "weekly"){
                for(var i = 0;i <node.children.length;i++){
                    if(node.children[i].firstChild.nodeValue == '1 D'){
                        node.children[i].setAttribute('tf','disabled')
                    }
                }

                for(var i = 0;i < node.children.length;i++){            
                    if(node.children[i].firstChild.nodeValue == '1 W'){
                        node.children[i].setAttribute('tf','enabled')
                    }
                }

                for(var i = 0;i <daily.length;i++){
                    daily[i].setAttribute('tf','disabled')
                }

                for(var i = 0;i <weekly.length;i++){
                    weekly[i].setAttribute('tf','enabled')
   
                }
            }else{
                for(var i = 0;i < node.children.length;i++){            
                    if(node.children[i].firstChild.nodeValue == '1 D'){
                        node.children[i].setAttribute('tf','enabled')
  
                    }
                }
                for(var i = 0;i < node.children.length;i++){            
                    if(node.children[i].firstChild.nodeValue == '1 W'){
                        node.children[i].setAttribute('tf','enabled')
 
                    }
                }
    
                for(var i = 0;i <daily.length;i++){
                    daily[i].setAttribute('tf','enabled')
  
                }
                for(var i = 0;i <weekly.length;i++){
                    weekly[i].setAttribute('tf','enabled')

                }
            }
            //console.log('selectedFreq: ',selectedFreq)
            this.sendReq(symbol,start,end,new_str,selectedFreq,cb)
        }
    }else{
        CIQ.axios.get(
            config.getAllSymbols,
            {
                cache:true,
                auth: {
                    username: 'sentimentrader_backtest_api',
                    password: 'TAZcbpTmQVAJW4GW3ZMQA1su0ynjqJJsYo6vfkapx'
                }
            }
        ).then(res=>{
            CIQ.store.commit('getIndicatorsList', res.data)
            CIQ.store.commit('getAllSymbolsList',res.data);
            this.indicatorsList = res.data
        
            CIQ.indicatorList = this.indicatorList

            var orignalFreq = 'daily'
            var selectedFreq = 'daily'
            if(params.symbolObject.indicator === undefined){
                //console.log("freq is daily when using default indicator")
                // freq is daily when using default indicator
                new_str += '&indicator=' +CIQ.objIndicator;
            }else{
                try{
                    var freqList = []
                    for ( var  i = 0; i < CIQ.objIndicator.length; i++) {
                        // if(CIQ.objIndicator[i] == CIQ.store.state.indicators.formIndicators.entry || CIQ.objIndicator[i] == CIQ.store.state.indicators.formIndicators.exit){
                        //     //console.log(CIQ.store.state.exitFrequency)
                        //     freqList.push(CIQ.store.state.exitFrequency)
                        // }else{
                            let _obj = this.indicatorsList.find(x => x.url == CIQ.objIndicator[i])
                            freqList.push(_obj.updated)
                       // }
                        
                        new_str += `${i==0?'&indicator=':`&indicator_${i+1}=`}`+CIQ.objIndicator[i];
                    }
                    
                    if(freqList.find(item => item=="Weekly"))  orignalFreq= 'weekly';   
                    if(freqList.find(item => item=="Monthly"))  orignalFreq= 'monthly';  
                }catch(err){
                    console.error(err)
                }
            } 
            selectedFreq = orignalFreq
            switch(CIQ.store.state.exitFrequency){
                case "month":{
                    selectedFreq = "monthly"
                    break;
                }
                case "week":{
                    selectedFreq = "weekly"
                    break;
                }
                case "day":{
                    selectedFreq = "daily"
                    break;
                }
                default:
            }
            // commment it becasue commit cannot be use in this js
             CIQ.store.commit('setFreqency',selectedFreq)
            
            
            switch(selectedFreq){
                case "monthly":{
                    CIQ.periodicity.timeUnit = 'month'
                    break;
                }
                case "weekly":{
                    CIQ.periodicity.timeUnit = 'week'
                    break;
                }
                case "daily":{    
                    CIQ.periodicity.timeUnit = 'day'
                    break;
                }
                default:
            }
        
            var daily=[],weekly=[],monthly=[]
            var nodeSetup = document.getElementsByTagName('li')
            for(var i =0;i<nodeSetup.length;i++){
                for(var j in nodeSetup[i].firstChild){
                    if(j == 'textContent'){
                        if(nodeSetup[i].firstChild.textContent === 'Daily'){
                            daily.push(nodeSetup[i])
                        }
                        if(nodeSetup[i].firstChild.textContent === 'Weekly'){
                            weekly.push(nodeSetup[i])
                        }
                        if(nodeSetup[i].firstChild.textContent === 'Monthly'){
                            monthly.push(nodeSetup[i])
                        }
                    }
                }		
			}
        
            var node = document.querySelector("cq-menu-container[cq-name = 'menuPeriodicity']")
            for(var i = 0;i < node.children.length;i++){
                node.children[i].style.display = "inherit"
            }

            //console.log("orignalFreq: ",orignalFreq)

            if(orignalFreq == "monthly"){
                for(var i = 0;i < node.children.length;i++){            
                    if(node.children[i].firstChild.nodeValue == '1 D'){
                        node.children[i].setAttribute('tf','disabled')
                    }
                }
                for(var i = 0;i < node.children.length;i++){            
                    if(node.children[i].firstChild.nodeValue == '1 W'){
                        node.children[i].setAttribute('tf','disabled')
                    }
                }
                

                for(var i = 0;i <daily.length;i++){
                    daily[i].setAttribute('tf','disabled')
                }
                for(var i = 0;i <weekly.length;i++){
                    weekly[i].setAttribute('tf','disabled')
                }
            }else if(orignalFreq == "weekly"){
                for(var i = 0;i <node.children.length;i++){
                    if(node.children[i].firstChild.nodeValue == '1 D'){
                        node.children[i].setAttribute('tf','disabled')
                    }
                }

                for(var i = 0;i < node.children.length;i++){            
                    if(node.children[i].firstChild.nodeValue == '1 W'){
                        node.children[i].setAttribute('tf','enabled')
                    }
                }

                for(var i = 0;i <daily.length;i++){
                    daily[i].setAttribute('tf','disabled')
                }

                for(var i = 0;i <weekly.length;i++){
                    weekly[i].setAttribute('tf','enabled')
   
                }
            }else{
                for(var i = 0;i < node.children.length;i++){            
                    if(node.children[i].firstChild.nodeValue == '1 D'){
                        node.children[i].setAttribute('tf','enabled')
  
                    }
                }
                for(var i = 0;i < node.children.length;i++){            
                    if(node.children[i].firstChild.nodeValue == '1 W'){
                        node.children[i].setAttribute('tf','enabled')
 
                    }
                }
    
                for(var i = 0;i <daily.length;i++){
                    daily[i].setAttribute('tf','enabled')
  
                }
                for(var i = 0;i <weekly.length;i++){
                    weekly[i].setAttribute('tf','enabled')

                }
            }
            this.sendReq(symbol,start,end,new_str,selectedFreq,cb)
        })
    }

};

quoteFeedSimulator.fetchUpdateData = function (symbol, startDate, params,cb){
    var start = config.timestampToTime(Date.parse(this.initEndDate))

    // if (params.symbolObject.indicator === undefined){
    //     params.symbolObject.indicator = symbol
    // }

    // fetch indicator
    var new_str = ''
    var freq = 'daily'

    let techList = CIQ.store.state.indicators.technicalIndicators
    let list = []
    for(var i in CIQ.objIndicator){
        if(techList.indexOf(CIQ.objIndicator[i]) == -1){
            list.push(CIQ.objIndicator[i])
        }
    }

    if(params.symbolObject.indicator === undefined){
        //console.log('CIQ.objIndicator is not defined');
        new_str += '&indicator=' +CIQ.objIndicator;
    }else if(list.length == 0){
        new_str += '&indicator=' +'AAPL'
    }else{
        var freqList = []
        for ( var  i = 0,valid = 0; i < CIQ.objIndicator.length; i++) {
            // when both sentiment and tech exist in CIQ.objIndicator, filter tech indicator
            //let alphabetized = CIQ.alphabetized
            let sentiList = []
            CIQ.indicatorList.forEach(e => {
                sentiList.push(e.url)
            })
            if(sentiList){
                if(sentiList.indexOf(CIQ.objIndicator[i]) == -1){
                    continue
                }
            }

            // check if this indicator was selected from setup form
            if(CIQ.objIndicator[i] == CIQ.store.state.indicators.formIndicators.entry || CIQ.objIndicator[i] == CIQ.store.state.indicators.formIndicators.exit){
                let _obj = this.indicatorsList.find(x => x.url == CIQ.objIndicator[i])
                freqList.push(_obj.updated)
            }else{
                let _obj = this.indicatorsList.find(x => x.url == CIQ.objIndicator[i])
                freqList.push(_obj.updated)
            }
            new_str += `${valid==0?'&indicator=':`&indicator_${valid+1}=`}`+CIQ.objIndicator[i];
            valid++
        }
        
        if(freqList.find(item => item=="Weekly"))  freq= 'weekly';
        if(freqList.find(item => item=="Monthly"))  freq= 'monthly';
    }   
    switch(CIQ.store.state.exitFrequency){
        case "Monthly":{
            freq = "monthly"
            break;
        }
        case "Weekly":{
            freq = "weekly"
            break;
        }
        case "Daily":{
            freq = "daily"
            break;
        }
        default:
    }
    var queryUrl = this.url + 
       "?symbol=" + symbol + 
        new_str +
       "&start="+start + 
       "&freq=" + freq;

   // console.log("update: ",queryUrl);

    this.sendAjax(queryUrl,function(status, response){
        if (status == 200){
            var newQuotes = quoteFeedSimulator.formatChartData(response);
            
            cb({quotes:newQuotes});
        }else{
            cb({error:response ? response:status});
        }    
    });
};

quoteFeedSimulator.fetchPaginationData = function(symbol, suggestedStartDate, endDate, params,cb){
    //console.log("comparation for pag and init: ", config.timestampToTime(Date.parse(suggestedStartDate)), config.timestampToTime(CIQ.initialDate.start))
   
    var start = config.timestampToTime(Date.parse(suggestedStartDate)) 
    var end = config.timestampToTime(Date.parse(endDate)) 
    console.log('Pagination urlstart: '+start + ' end:'+end);

    var new_str = ''
    var freq = 'daily'

    let techList = CIQ.store.state.indicators.technicalIndicators
    let list = []
    for(var i in CIQ.objIndicator){
        if(techList.indexOf(CIQ.objIndicator[i]) == -1){
            list.push(CIQ.objIndicator[i])
        }
    }

    if(params.symbolObject.indicator === undefined){
        //console.log('CIQ.objIndicator is not defined');
        new_str += '&indicator=' +CIQ.objIndicator;
    }else if(list.length == 0){
        new_str += '&indicator=' +'AAPL'
    }else{
        var freqList = []
        for ( var  i = 0, valid = 0; i < CIQ.objIndicator.length; i++) {
            // when both sentiment and tech exist in CIQ.objIndicator, filter tech indicator
            //let alphabetized = CIQ.alphabetized
            let sentiList = []
            CIQ.indicatorList.forEach(e => {
                sentiList.push(e.url)
            })
            if(sentiList){
                if(sentiList.indexOf(CIQ.objIndicator[i]) == -1){
                    continue
                }
            }

            // check if this indicator was selected from setup form
            if(CIQ.objIndicator[i] == CIQ.store.state.indicators.formIndicators.entry || CIQ.objIndicator[i] == CIQ.store.state.indicators.formIndicators.exit){
                let _obj = this.indicatorsList.find(x => x.url == CIQ.objIndicator[i])
                freqList.push(_obj.updated)
            }else{
                let _obj = this.indicatorsList.find(x => x.url == CIQ.objIndicator[i])
                freqList.push(_obj.updated)
            }
            new_str += `${valid==0?'&indicator=':`&indicator_${valid+1}=`}`+CIQ.objIndicator[i];
            valid++
        }
        
        if(freqList.find(item => item=="Weekly"))  freq= 'weekly';
        if(freqList.find(item => item=="Monthly"))  freq= 'monthly';
    }   
   
    switch(CIQ.store.state.exitFrequency){
        case "Monthly":{
            freq = "monthly"
            break;
        }
        case "Weekly":{
            freq = "weekly"
            break;
        }
        case "Daily":{
            freq = "daily"
            break;
        }
        default:
    }   
    var queryUrl = this.url + 
       "?symbol=" + symbol + 
        new_str +
       "&start="+start+
       "&end=" + end + 
       "&freq=" + freq;
    //console.log("pagination: ",queryUrl);

    this.sendAjax(queryUrl, function(status,response){
        if(status == 200){
            // don't need to load markers here
            // if(CIQ.isMarkerShown === true){
            //     // load markers for pagination quotefeed
            //     let list = quoteFeedSimulator.filterMarkerDate(
            //         new Date(Date.parse(suggestedStartDate)),new Date(Date.parse(endDate)),CIQ.store.state.markerSet
            //     )
            //     console.log("CIQ.loadChart from pagination")
            //     CIQ.loadChart(list, CIQ.addMarker)
            // }

            var newQuotes = quoteFeedSimulator.formatChartData(response);
            cb({
                quotes: newQuotes, 
                upToDate: endDate.getTime() >=  Date.now(),
                moreAvailable: suggestedStartDate.getTime() > 0
            });
            
        }else{
            cb({error: response ? response :status})
        }
    })

}

// filter markerSet by given start date and end date during backtest setup
quoteFeedSimulator.filterMarkerDate = function(start_date,end_date,markerSet){
    let list = []
    let _date = {
        start: jutils.formatDate(start_date,"YYYYMMDD"),
        end: jutils.formatDate(end_date,"YYYYMMDD")
    }
    for(var date in markerSet){
        let markerSetDate = markerSet[date].DT.slice(0,4)+markerSet[date].DT.slice(5,7)+markerSet[date].DT.slice(8,10)
        if(markerSetDate>_date.start && markerSetDate<=_date.end){
            list.push(markerSet[date])
        }
    }
    //console.log(_date,list)
    return list
}

quoteFeedSimulator.formatChartData = async function(response){
    var data = response
    if(data == null){
        data = []
    }

    var newQuotes = [];
    var oneDay = (24 *60 *60 *1000) * 0
    //var objIndicatorList = CIQ.objIndicator
    try{
        if('High' in data[0]){
            //console.log(CIQ.objIndicator,data)
            for (var i = 0; i < data.length; i++) {
                newQuotes[i] = {};
                
                var datatime = new Date(data[i].DT)
                
                var offset = datatime.getTimezoneOffset() * 60 * 1000
                
                newQuotes[i].DT = new Date(datatime.setTime(datatime.getTime() + offset));

                
            // console.log(newQuotes[i].DT)
                newQuotes[i].Open = data[i].Open;
                newQuotes[i].High = data[i].High;
                newQuotes[i].Low = data[i].Low;
                newQuotes[i].Close = data[i].Close;
                newQuotes[i].Volume = data[i].Volume;
                
                for(var j in CIQ.objIndicator){
                    var str = j==0?'indicator_Close':`indicator${Number(j)+1}_Close`;    
                    newQuotes[i][CIQ.objIndicator[j]] = data[i][str];
                }
            } 
            
            CIQ.stxx.setChartType("line"); 
            var node = document.querySelector("cq-menu-container[cq-name = 'menuChartStyle']")
            for(var i = 0;i < node.children.length;i++){
                node.children[i].style.display = "inherit"
            }
        }else{
            for (var i = 0; i < data.length; i++) {
                newQuotes[i] = {};

                var datatime = new Date(data[i].DT)

                var offset = datatime.getTimezoneOffset() * 60 * 1000
                
                newQuotes[i].DT = new Date(datatime.setTime(datatime.getTime() + offset));
    
                newQuotes[i].Open = data[i].Close;
                newQuotes[i].High = data[i].Close;
                newQuotes[i].Low = data[i].Close;
                newQuotes[i].Close = data[i].Close;
                
                if(data[i].Volume){
                    newQuotes[i].Volume = data[i].Volume
                }

                for(var j in CIQ.objIndicator){
                    var str = j==0?'indicator_Close':`indicator${Number(j)+1}_Close`;
                    newQuotes[i][CIQ.objIndicator[j]] = data[i][str];
                }
            }
            CIQ.stxx.setChartType("line"); 
            var node = document.querySelector("cq-menu-container[cq-name = 'menuChartStyle']")
            for(var i = 0;i < node.children.length;i++){
                node.children[i].style.display = "inherit"
            }
            for(var i = 0;i < node.children.length;i++){
                if(node.children[i].firstChild.nodeValue != "Line"){
                    node.children[i].style.display = "none"
                }
            } 
        }
    }catch(err){}
       
    // 可以封装成promise
    //return new Promise(async(resolve)=>{
        if(typeof CIQ.objIndicator !== 'string'){
            for(var j in CIQ.objIndicator){
                //console.log(CIQ.objIndicator[j])
                // 之后加一个symbol判断和小李新senti判断
                if(CIQ.isUserIndicator(CIQ.objIndicator[j])){
                    let [name,hash] = CIQ.objIndicator[j].split(/HASH/)
                    let res = await config.csvFileRead(name,hash)
                    const datafeed = res.data.data.csv_content
                    
                    for (var i = 0; i < datafeed.length; i++) {
                        var index = data.findIndex(item=>item.DT == datafeed[i].DT)        
                        newQuotes[index][CIQ.objIndicator[j]] = parseFloat(datafeed[i]['indicator_Close'])
                    }  
                    //console.log('after adding user customized datafeed',newQuotes)
                    
                }
            }
            //console.log('before resolve new quotes',newQuotes);
            return newQuotes
        }else{
            //console.log('before resolve new quotes(default indicator)',newQuotes);
            return newQuotes
        }
    //})

    //return newQuotes
}

export default quoteFeedSimulator;