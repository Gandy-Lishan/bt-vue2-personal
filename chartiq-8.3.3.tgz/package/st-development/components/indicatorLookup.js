import {CIQ} from "../../js/chartiq.js"

CIQ.Studies.studyLibrary["ST Indicator"] = {
    inputs: {},
    outputs: { "Close":"green"}
};
let __js_webcomponents_indicators_ = (_exports) => {

	/* global _CIQ, _timezoneJS, _SplinePlotter */
	console.log('indi_lookup')
	var CIQ = typeof _CIQ !== "undefined" ? _CIQ : _exports.CIQ;
	
	/**
	 * Studies list web component `<cq-indicators>`.
	 *
	 * Lists all studies contained in the study library, {@link CIQ.Studies.studyLibrary}.
	 *
	 * @namespace WebComponents.cq-indicators
	 * @since 5.2.0
	 *
	 * @example
	 * <cq-menu class="ciq-menu ciq-studies collapse">
	 *     <span>Studies</span>
	 *     <cq-menu-dropdown cq-no-scroll>
	 *         <cq-study-legend cq-no-close>
	 *             <cq-section-dynamic>
	 *                 <cq-heading>Current Studies</cq-heading>
	 *                 <cq-study-legend-content>
	 *                     <template>
	 *                         <cq-item>
	 *                             <cq-label class="click-to-edit"></cq-label>
	 *                             <div class="ciq-icon ciq-close"></div>
	 *                         </cq-item>
	 *                     </template>
	 *                 </cq-study-legend-content>
	 *                 <cq-placeholder>
	 *                     <div stxtap="Layout.clearStudies()" class="ciq-btn sm">Clear All</div>
	 *                 </cq-placeholder>
	 *             </cq-section-dynamic>
	 *         </cq-study-legend>
	 *         <cq-scroll>
	 *             <cq-indicators>
	 *                 <cq-indicatorss-content>
	 *                     <template>
	 *                         <cq-item>
	 *                             <cq-label></cq-label>
	 *                         </cq-item>
	 *                     </template>
	 *                 </cq-indicators-content>
	 *             </cq-indicators>
	 *         </cq-scroll>
	 *     </cq-menu-dropdown>
	 * </cq-menu>
	 */
	class Indicators extends CIQ.UI.ContextTag {
		disconnectedCallback() {
			if (this.context)
				CIQ.UI.unobserveProperty(
					"studyLibraryHash",
					this.context.stx.chart,
					this.listener
				);
			super.disconnectedCallback();
		}
	
		/**
		 * Initializes and displays the list of available studies.
		 *
		 * @param {object} [params] Parameters to control initialization of the studies list.
		 * @param {object} [params.excludedStudies] A map of study names that should be excluded from
		 * 		the studies list, for example: <code>{&nbsp;"macd":&nbsp;true&nbsp;}</code>.
		 * @param {object|boolean} [params.alwaysDisplayDialog=false] If set to boolean true (not
		 * 		truthy), the study edit dialog box is automatically opened for any of the available
		 * 		studies after the study has been added to the chart. If set to boolean false, the
		 * 		study edit dialog box is not opened for any of the available studies after the study
		 * 		has been added to the chart.
		 * 		<p>If set to an object containing a map of study names and boolean values (for example,
		 * 		<code>{&nbsp;"ma":&nbsp;true,&nbsp;"AVWAP":&nbsp;true&nbsp;}</code>), the study edit
		 * 		dialog box is opened after the study has been added to the chart for studies in the
		 * 		map that have a boolean value of true but not for those that have a value of false or
		 * 		for any studies not included in the map.
		 * @param {object|boolean} [params.dialogBeforeAddingStudy=false] If set to boolean true (not
		 * 		truthy), the study edit dialog box is automatically opened for any of the available
		 * 		studies before the study is added to the chart. If set to boolean false, the study
		 * 		edit dialog box is not opened for any of the available studies before the study is
		 * 		added to the chart.
		 * 		<p>If set to an object containing a map of study names and boolean values (for example,
		 * 		<code>{&nbsp;"macd":&nbsp;true&nbsp;}</code>), the study edit dialog box is opened
		 * 		before the study is added to the chart for studies in the map that have a boolean value
		 * 		of true but not for those that have a value of false or for any studies not included
		 * 		in the map.
		 *
		 * @alias initialize
		 * @memberof WebComponents.cq-indicators
		 * @since 5.2.0 The `CIQ.UI.StudyMenu` helper has been deprecated. Please call
		 * 		`document.querySelector("cq-indicators").initialize()` now.
		 *
		 * @example
		 * let params = {
		 *     excludedStudies: { "macd": true },  // Exclude studies from the list of available studies.
		 *     alwaysDisplayDialog: { "ma": true },  // Show the study preferences dialog after adding studies.
		 *     dialogBeforeAddingStudy: { "rsi": true }  // Show the study preferences dialog before adding studies.
		 * };
		 * document.querySelectorAll("cq-studies").forEach(function(i) {
		 *     i.initialize(params);
		 * });
		 */
		initialize(params) {
			console.log('init')
			this.addDefaultMarkup();
			this.params = params || {};
			this.alwaysDisplayDialog = this.params.alwaysDisplayDialog || false;
			this.excludedStudies = this.params.excludedStudies || [];
			if (!this.params.template) this.params.template = "template";
			this.params.template = this.node.find(this.params.template);
			console.log(this.params.template)
			this.renderMenu();
	
			var self = this,
				stx = this.context.stx;
			this.listener = function (obj) {
				self.renderMenu();
			};
			CIQ.UI.observeProperty("studyLibraryHash", stx.chart, this.listener);
		}
	
		setContext({ config }) {
			console.log('etCon')
			if (config && config.menuStudiesConfig) {
				this.initialize(Object.assign({}, config.menuStudiesConfig));
			}
		}
		getAllSymbols(){
			
		}
		/**
		 * Creates a list of studies in a `<cq-indicators-content>` element.
		 *
		 * You have the option of creating a hardcoded HTML menu and just using {@link CIQ.Studies}
		 * for processing `stxtap` attributes, or you can call this method to automatically generate
		 * the menu.
		 *
		 * @alias renderMenu
		 * @memberof WebComponents.cq-indicators
		 */
		renderMenu() {
			if (!CIQ.Studies) return;
			var stx = this.context.stx;
			var alphabetized = [];
			var sd;
			// for(var i=20;i<CIQ.Studies.studyLibrary.length;i++){
			// }
			// for (var field in CIQ.Studies.studyLibrary) {
			// 	sd = CIQ.Studies.studyLibrary[field];
			// 	if (
			// 		!sd ||
			// 		this.excludedStudies[field] ||
			// 		this.excludedStudies[sd.name] ||
			// 		sd.siqList !== undefined
			// 	)
			// 		continue; // siqList = ScriptIQ entry
			// 	if (!sd.name) sd.name = field; // Make sure there's always a name
			// 	alphabetized.push(field);
			// }
			// alphabetized.sort(function (lhs, rhs) {
			// 	var lsd = CIQ.Studies.studyLibrary[lhs];
			// 	var rsd = CIQ.Studies.studyLibrary[rhs];
			// 	if (lsd.name < rsd.name) return -1;
			// 	if (lsd.name > rsd.name) return 1;
			// 	return 0;
			// });
			// console.log(alphabetized);
            // sd = CIQ.Studies.studyLibrary["ST Indicator"]
			// var index = alphabetized.indexOf("ST");
            alphabetized.push("ST Indicator");
			// if(index!=-1){
			// 	var newArr = [];
			// 	newArr.push(alphabetized[index])
			// }
			// alphabetized = newarr;
			var menu = this.node;		
			var self = this;
			var tapFn = function (studyName, context) {
				return function (e) {
					pickStudy(e.target, studyName);
					self.dispatchEvent(new Event("resize"));
				};
			};
	
			var contentNode = menu.find("cq-indicators-content");
			while (contentNode.length > 0 && contentNode[0].firstChild) {
				contentNode[0].removeChild(contentNode[0].firstChild);
			}
	
			for (var i = 0; i < alphabetized.length; i++) {
				var menuItem = CIQ.UI.makeFromTemplate(this.params.template);
				console.log(this.params.template)
				sd = CIQ.Studies.studyLibrary[alphabetized[i]];
				menuItem.append(CIQ.translatableTextNode(stx, sd.name));
				this.makeTap(menuItem[0], tapFn(alphabetized[i], this.context));
				menu.find("cq-indicators-content").append(menuItem);
			}
	
			function studyDialog(params, addWhenDone) {
				const { context } = self;
	
				if (context.config) {
					self.channelWrite(
						context.config.channels.dialog,
						{
							type: "study",
							params: Object.assign({}, params, { context, addWhenDone })
						},
						context.stx
					);
				} else {
					// legacy use when config is not available
					params.context = self.context;
					const dialog = document.querySelector("cq-study-dialog");
					dialog.addWhenDone = addWhenDone;
					dialog.open(params);
				}
			}
	
			function pickStudy(node, studyName) {
				var stx = self.context.stx;
	
				function handleSpecialCase(flag, params, addWhenDone) {
					if (flag === true) {
						studyDialog(params, addWhenDone);
						return true;
					} else if (typeof flag === "object") {
						for (var i in flag) {
							if (i == studyName && flag[i]) {
								studyDialog(params, addWhenDone);
								return true;
							}
						}
					}
				}
	
				if (
					handleSpecialCase(
						self.params.dialogBeforeAddingStudy,
						{ stx: stx, name: studyName },
						true
					)
				)
					return;
				var sd = CIQ.Studies.addStudy(stx, studyName);
				console.log(sd)
				handleSpecialCase(self.alwaysDisplayDialog, { sd: sd, stx: stx });
			}
		}
	}
	
	Indicators.markup = `
			<template>
				<cq-item class="ciq indic"></cq-item>
			</template>
			<cq-indicators-content></cq-indicators-content>
		`;
	CIQ.UI.addComponentDefinition("cq-indicators", Indicators);
	};

export {__js_webcomponents_indicators_}