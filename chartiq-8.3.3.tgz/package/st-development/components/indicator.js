import {CIQ} from "../../js/chartiq.js"
import {config} from "../feeds/STDataFeedAccessUrl.js"
// CIQ.Studies.calculateMyRsi = function(stx, sd) {
// 	sd.rsi = new CIQ.Studies.StudyDescriptor(sd.name, "ST Indicator", sd.panel);
// 	sd.rsi.chart = sd.chart;
// 	sd.rsi.startFrom = sd.startFrom;
// 	sd.rsi.days = sd.days;
// 	CIQ.Studies.calculateRSI(stx, sd.rsi);
// 	// now your RSI value is in the "RSI ‌MY CUSTOM RSI‌ (13,n)" field of the quotes array
// 	// The default display function will be looking for "Result ‌MY CUSTOM RSI‌ (13,n)", since no outputs object was defined in the "MY CUSTOM RSI" library entry.
// 	// Here add code to generate a field that matches "Result ‌MY CUSTOM RSI‌ (13,n)"
// 	var quotes = sd.chart.scrubbed;
// 	for (var i = sd.startFrom; i < quotes.length; i++) {
// 		var quote = quotes[i];
// 		var RSIValue = quote["RSI " + sd.name];
// 		if (RSIValue) {
// 			var customStudyValue = RSIValue; // add code here to operate on the RSI to compute your final value based on it.
// 			quote["Result " + sd.name] = customStudyValue; // assign to the final field to be used by your display function.
// 		}
// 	}
// };


let __js_webcomponents_indicators_ = (_exports) => {
	
	/* global _CIQ, _timezoneJS, _SplinePlotter */
	
	var CIQ = typeof _CIQ !== "undefined" ? _CIQ : _exports.CIQ;
	
	/**
	 * Studies list web component `<cq-indicators>`.
	 *
	 * Lists all studies contained in the study library, {@link CIQ.Studies.studyLibrary}.
	 *
	 * @namespace WebComponents.cq-indicators
	 * @since 5.2.0
	 *
	 * @example
	 * <cq-menu class="ciq-menu ciq-studies collapse">
	 *     <span>Studies</span>
	 *     <cq-menu-dropdown cq-no-scroll>
	 *         <cq-study-legend cq-no-close>
	 *             <cq-section-dynamic>
	 *                 <cq-heading>Current Studies</cq-heading>
	 *                 <cq-study-legend-content>
	 *                     <template>
	 *                         <cq-item>
	 *                             <cq-label class="click-to-edit"></cq-label>
	 *                             <div class="ciq-icon ciq-close"></div>
	 *                         </cq-item>
	 *                     </template>
	 *                 </cq-study-legend-content>
	 *                 <cq-placeholder>
	 *                     <div stxtap="Layout.clearStudies()" class="ciq-btn sm">Clear All</div>
	 *                 </cq-placeholder>
	 *             </cq-section-dynamic>
	 *         </cq-study-legend>
	 *         <cq-scroll>
	 *             <cq-indicators>
	 *                 <cq-indicatorss-content>
	 *                     <template>
	 *                         <cq-item>
	 *                             <cq-label></cq-label>
	 *                         </cq-item>
	 *                     </template>
	 *                 </cq-indicators-content>
	 *             </cq-indicators>
	 *         </cq-scroll>
	 *     </cq-menu-dropdown>
	 * </cq-menu>
	 */
	class Indicators extends CIQ.UI.ContextTag {
		disconnectedCallback() {
			if (this.context)
				CIQ.UI.unobserveProperty(
					"studyLibraryHash",
					this.context.stx.chart,
					this.listener
				);
			super.disconnectedCallback();
		}
	
		/**
		 * Initializes and displays the list of available studies.
		 *
		 * @param {object} [params] Parameters to control initialization of the studies list.
		 * @param {object} [params.excludedStudies] A map of study names that should be excluded from
		 * 		the studies list, for example: <code>{&nbsp;"macd":&nbsp;true&nbsp;}</code>.
		 * @param {object|boolean} [params.alwaysDisplayDialog=false] If set to boolean true (not
		 * 		truthy), the study edit dialog box is automatically opened for any of the available
		 * 		studies after the study has been added to the chart. If set to boolean false, the
		 * 		study edit dialog box is not opened for any of the available studies after the study
		 * 		has been added to the chart.
		 * 		<p>If set to an object containing a map of study names and boolean values (for example,
		 * 		<code>{&nbsp;"ma":&nbsp;true,&nbsp;"AVWAP":&nbsp;true&nbsp;}</code>), the study edit
		 * 		dialog box is opened after the study has been added to the chart for studies in the
		 * 		map that have a boolean value of true but not for those that have a value of false or
		 * 		for any studies not included in the map.
		 * @param {object|boolean} [params.dialogBeforeAddingStudy=false] If set to boolean true (not
		 * 		truthy), the study edit dialog box is automatically opened for any of the available
		 * 		studies before the study is added to the chart. If set to boolean false, the study
		 * 		edit dialog box is not opened for any of the available studies before the study is
		 * 		added to the chart.
		 * 		<p>If set to an object containing a map of study names and boolean values (for example,
		 * 		<code>{&nbsp;"macd":&nbsp;true&nbsp;}</code>), the study edit dialog box is opened
		 * 		before the study is added to the chart for studies in the map that have a boolean value
		 * 		of true but not for those that have a value of false or for any studies not included
		 * 		in the map.
		 *
		 * @alias initialize
		 * @memberof WebComponents.cq-indicators
		 * @since 5.2.0 The `CIQ.UI.StudyMenu` helper has been deprecated. Please call
		 * 		`document.querySelector("cq-indicators").initialize()` now.
		 *
		 * @example
		 * let params = {
		 *     excludedStudies: { "macd": true },  // Exclude studies from the list of available studies.
		 *     alwaysDisplayDialog: { "ma": true },  // Show the study preferences dialog after adding studies.
		 *     dialogBeforeAddingStudy: { "rsi": true }  // Show the study preferences dialog before adding studies.
		 * };
		 * document.querySelectorAll("cq-studies").forEach(function(i) {
		 *     i.initialize(params);
		 * });
		 */
		initialize(params) {
			console.log('indic')
			this.addDefaultMarkup();
			this.reslust = [];
			this.params = params || {};
			this.alwaysDisplayDialog = this.params.alwaysDisplayDialog || false;
			this.excludedStudies = this.params.excludedStudies || [];
			if (!this.params.template) this.params.template = "template";
			this.params.template = this.node.find(this.params.template);
			// console.log(this.params.template)
			this.postajax()
			// this.runTask()
			this.renderMenu()
		
		
	
			var self = this,
				stx = this.context.stx;
			this.listener = function (obj) {
				self.renderMenu();
			};
			CIQ.UI.observeProperty("studyLibraryHash", stx.chart, this.listener);
		}
	
		setContext({ config }) {
			console.log('setContext')
			if (config && config.menuStudiesConfig) {
				this.initialize(Object.assign({}, config.menuStudiesConfig));
			}
		}

		async runTask(){
			await this.postajax()
			// this.renderMenu();

		}
		postajax() {
			
				var server = new XMLHttpRequest();   
				// url += (url.indexOf("?") === -1 ? "?" : "&") + new Date().getTime();
				server.open("GET", config.getAllSymbols,false);
				//console.log("indicator")
				server.setRequestHeader("Authorization", "Basic " + btoa(config.username+":"+config.password));  
				const obj = this;
				// server.onload = function () {
				// 	obj.getAllSymbols(this.status, this.responseText,obj);
				// };
				// server.onerror = function () {
				// 	cb(500);
				// };
				server.send(null);
				if (server.status===200) {
					try {

						var response = JSON.parse(server.response);
						for(var i=0;i<response.length;i++){
							var item = {
								name:response[i].chart_name,
								url:response[i].url
							};
							this.reslust.push(item)
						}
						
						CIQ.indicators = this.reslust
					} catch (e) {
						console.log(e);
					}
				}
		};

		getIndicatorMatedata (indicator,studyName){
			var queryUrl =  config.indicatorMetadata + 
			"?indicator=" + indicator;

			var server = new XMLHttpRequest();   
				// url += (url.indexOf("?") === -1 ? "?" : "&") + new Date().getTime();
				server.open("GET", queryUrl,false);
			
				server.setRequestHeader("Authorization", "Basic " + btoa(config.username+":"+config.password));  

				server.send(null);
				if (server.status===200) {
					try {
							var newQuotes = JSON.parse(server.response);
							if (studyName !== undefined & newQuotes !== null){
										var sd = CIQ.Studies.studyLibrary[studyName] = {
											inputs: { Period: 13, Overlay: false,},
											outputs: {indicatorClose:"pink",description: newQuotes.description,url:indicator},
											parameters: { init: {
												studyOverZonesEnabled: false,
												studyOverBoughtValue: newQuotes.opt_extreme,
												studyOverBoughtColor: "red",
												studyOverSoldValue: newQuotes.pess_extreme,
												studyOverSoldColor: "green",
											}}
										}
										CIQ.Studies.addStudy(CIQ.stxx,studyName)
							} 
							else if (studyName !== undefined){
								CIQ.Studies.addStudy(CIQ.stxx, studyName);
							}
					} catch (e) {
						console.log(e);
					}
				}
			// this.sendAjax(queryUrl,function(status, response){
				
			// });
		}
		getAllSymbols(status,response,obj){
			if (status != 200) return;
		try {
			response = JSON.parse(response);
			// var symbols = response.payload.symbols;
			for(var i=0;i<response.length;i++)
			var item = {
				name:response[i].chart_name,
				url:response[i].url
			};
		CIQ.indicators.push(item)
			// CIQ.Studies.studyLibrary["ST "+response[i].chart_name] = {
			// 	inputs: { Period: 13, Overlay: false,url:response[i].url},
			// 	outputs: {indicatorClose:"pink"}
			// };
			// obj.reslust = response;
		} catch (e) {}
		}
		/**
		 * Creates a list of studies in a `<cq-indicators-content>` element.
		 *
		 * You have the option of creating a hardcoded HTML menu and just using {@link CIQ.Studies}
		 * for processing `stxtap` attributes, or you can call this method to automatically generate
		 * the menu.
		 *
		 * @alias renderMenu
		 * @memberof WebComponents.cq-indicators
		 */
		renderMenu() {
			if (!CIQ.Studies) return;
			var stx = this.context.stx;
			var alphabetized = [];
			var sd;

			alphabetized = this.reslust;
			var menu = this.node;		
			var self = this;
			var tapFn = function (studyName, context) {
				return function (e) {
					pickStudy(e.target, studyName);
					self.dispatchEvent(new Event("resize"));
				};
			};
	
			var contentNode = menu.find("cq-indicators-content");
			while (contentNode.length > 0 && contentNode[0].firstChild) {
				contentNode[0].removeChild(contentNode[0].firstChild);
			}
	
			for (var i = 0; i < alphabetized.length; i++) {
				var menuItem = CIQ.UI.makeFromTemplate(this.params.template);
				// console.log(this.params.template)
				// sd = CIQ.Studies.studyLibrary[alphabetized[i]];
				// menuItem.append(CIQ.translatableTextNode(stx, sd.name));

				menuItem.append(CIQ.translatableTextNode(stx, alphabetized[i].name));
				this.makeTap(menuItem[0], tapFn(alphabetized[i].name, this.context));
				menu.find("cq-indicators-content").append(menuItem);
			}
	
			function studyDialog(params, addWhenDone) {
				const { context } = self;
	
				if (context.config) {
					self.channelWrite(
						context.config.channels.dialog,
						{
							type: "study",
							params: Object.assign({}, params, { context, addWhenDone })
						},
						context.stx
					);
				} else {
					// legacy use when config is not available
					params.context = self.context;
					const dialog = document.querySelector("cq-study-dialog");
					dialog.addWhenDone = addWhenDone;
					dialog.open(params);
				}
			}
	
			function pickStudy(node, studyName) {
				var stx = self.context.stx;
	
				function handleSpecialCase(flag, params, addWhenDone) {
					if (flag === true) {
						studyDialog(params, addWhenDone);
						return true;
					} else if (typeof flag === "object") {
						for (var i in flag) {
							if (i == studyName && flag[i]) {
								studyDialog(params, addWhenDone);
								return true;
							}
						}
					}
				}
	
				if (
					handleSpecialCase(
						self.params.dialogBeforeAddingStudy,
						{ stx: stx, name: studyName },
						true
					)
				)
					return;
					// var sd = CIQ.Studies.addStudy(stx, studyName);
				
				var st = CIQ.Studies.studyLibrary[studyName];
				var url;
				var reslust = CIQ.indicators; 
				for (var i=0;i<reslust.length;i++){
					if (reslust[i].name.indexOf(studyName) !== -1) url=reslust[i].url;
				}
				CIQ.stxx.loadChart(	{ symbol: CIQ.symbol,startDate:new Date(),endDate:new Date(), indicator: url,studyName:studyName},)
				self.getIndicatorMatedata(url,studyName)
				// if (Object.keys(CIQ.stxx.layout.studies).length >= 1){
				// 	for(var sd in CIQ.stxx.layout.studies){
				// 		sd = CIQ.stxx.layout.studies[sd]
				// 		CIQ.Studies.removeStudy(CIQ.stxx,sd )
				// 	}
				// }
				// var sd = CIQ.Studies.addStudy(stx, studyName);
				handleSpecialCase(self.alwaysDisplayDialog, { sd: sd, stx: stx });
			}
		}
	}
	
	Indicators.markup = `
			<template>
				<cq-item class="ciq-indic"></cq-item>
			</template>
			
			<cq-indicators-content>
		
			</cq-indicators-content>
		
		`;
	CIQ.UI.addComponentDefinition("cq-indicators", Indicators);
	};



export {__js_webcomponents_indicators_}