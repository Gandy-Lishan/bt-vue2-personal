/**
 *	8.3.0
 *	Generation date: 2021-11-02T13:40:51.589Z
 *	Client name: sundial capital research
 *	Package Type: Technical Analysis
 *	License type: annual
 *	Expiration date: "2022/10/01"
 *	Domain lock: ["127.0.0.1","localhost","sentimentrader.com","18.117.142.18","bt20.sentimentrader.com"]
 *	iFrame lock: true
 */

/***********************************************************
 * Copyright by ChartIQ, Inc.
 * Licensed under the ChartIQ, Inc. Developer License Agreement https://www.chartiq.com/developer-license-agreement
*************************************************************/
/*************************************** DO NOT MAKE CHANGES TO THIS LIBRARY FILE!! **************************************/
/* If you wish to overwrite default functionality, create a separate file with a copy of the methods you are overwriting */
/* and load that file right after the library has been loaded, but before the chart engine is instantiated.              */
/* Directly modifying library files will prevent upgrades and the ability for ChartIQ to support your solution.          */
/*************************************************************************************************************************/
/* eslint-disable no-extra-parens */


import { CIQ as _CIQ } from "../../js/chartiq.js";
import "../../js/standard/studies.js";

let __js_st_studies_movingAverages_ = (_exports) => {

/* global _CIQ, _timezoneJS, _SplinePlotter */


var CIQ = typeof _CIQ !== "undefined" ? _CIQ : _exports.CIQ;

if (!CIQ.Studies) {
	console.error(
		"movingAverages feature requires first activating studies feature."
	);
} else {
	CIQ.Studies.prettify = CIQ.extend(
		{
			"2-exponential": "dema",
			"3-exponential": "tema",
			hull: "hma"
		},
		CIQ.Studies.prettify
	);

	CIQ.extend(CIQ.Studies.movingAverage, {
		conversions: {
			hma: "hull",
			dema: "2-exponential",
			tema: "3-exponential"
		},
		translations: {
			hull: "Hull",
			"2-exponential": "Double Exponential",
			"3-exponential": "Triple Exponential"
		},
		typeMap: {
			hma: "Hull",
			hull: "Hull",
			dema: "DoubleExponential",
			"2-exponential": "DoubleExponential",
			tema: "TripleExponential",
			"3-exponential": "TripleExponential"
		}
	});
	CIQ.Studies.calculateSTRSI = function (stx, sd) {
		var quotes = sd.chart.scrubbed;
		var field = sd.inputs.Field;
		if (!field || field == "field") field = "Close";

		function computeRSI(avgGain, avgLoss) {
			if (avgLoss === 0) return 100;
			var rs = avgGain / avgLoss;
			return 100 - 100 / (1 + rs);
		}
		if (quotes.length < sd.days + 1) {
			sd.error = true;
			return;
		}
		for (var i = sd.startFrom; i < quotes.length; i++) {
			if (!i) continue;
			var quote = quotes[i];
			var quote1 = quotes[i - 1];
			if (!quote[field] && quote[field] !== 0) continue;
			if (!quote1[field] && quote1[field] !== 0) continue;
			var change = quote[field] - quote1[field];
			var num = Math.min(i, sd.days);

			var avgGain = quote1["_avgG " + sd.name];
			if (!avgGain) avgGain = 0;
			avgGain -= avgGain / num;

			var avgLoss = quote1["_avgL " + sd.name];
			if (!avgLoss) avgLoss = 0;
			avgLoss -= avgLoss / num;

			if (change > 0) {
				avgGain += change / num;
			} else if (change <= 0) {
				avgLoss -= change / num;
			} else continue;
			if (i >= sd.days) {
				if ((avgGain || avgGain !== 0) && (avgLoss || avgLoss !== 0))
					quote["RSI " + sd.name] = computeRSI(avgGain, avgLoss);
			}
			//intermediates
			quote["_avgG " + sd.name] = avgGain;
			quote["_avgL " + sd.name] = avgLoss;
		}
		sd.zoneOutput = "RSI";
	};
	CIQ.Studies.calculateSTMACD = function (stx, sd) {
		var quotes = sd.chart.scrubbed;

		var inputs = sd.inputs,
			name = sd.name;
		if (!sd.macd1Days) sd.macd1Days = parseFloat(inputs["Fast MA Period"]);
		if (!sd.macd2Days) sd.macd2Days = parseFloat(inputs["Slow MA Period"]);
		if (!sd.signalDays) sd.signalDays = parseFloat(inputs["Signal Period"]);
		if (!sd.days) sd.days = Math.max(sd.macd1Days, sd.macd2Days, sd.signalDays);
		if (quotes.length < sd.days + 1) {
			sd.error = true;
			return;
		}

		var field = sd.inputs.Field;
		if (!field || field == "field") field = "Close";

		var maType = inputs["Moving Average Type"];
		if (!maType) maType = "exponential";

		CIQ.Studies.MA(maType, sd.macd1Days, field, 0, "_MACD1", stx, sd);
		CIQ.Studies.MA(maType, sd.macd2Days, field, 0, "_MACD2", stx, sd);

		var i,
			quote,
			start = Math.max(sd.startFrom, sd.days - 1);
		for (i = start; i < quotes.length; i++) {
			quote = quotes[i];
			if (
				(quote["_MACD1 " + name] || quote["_MACD1 " + name] === 0) &&
				(quote["_MACD2 " + name] || quote["_MACD2 " + name] === 0)
			)
				quote["MACD " + name] =
					quote["_MACD1 " + name] - quote["_MACD2 " + name];
		}
		var sigMaType = inputs["Signal MA Type"];
		if (!sigMaType) sigMaType = "exponential";
		CIQ.Studies.MA(
			sigMaType,
			sd.signalDays,
			"MACD " + name,
			0,
			"SignalLine",
			stx,
			sd
		);

		var histogram = name + "_hist";
		for (i = start; i < quotes.length; i++) {
			quote = quotes[i];
			var signal = quote["SignalLine " + name];
			if (!signal && signal !== 0) continue; // don't create histogram before the signal line is valid
			quote[histogram] = quote["MACD " + name] - quote["SignalLine " + name];
		}
		//console.log(quote)
		sd.outputMap[histogram] = "";
	};

	CIQ.Studies.calculateSTCCI = function (stx, sd) {
		var quotes = sd.chart.scrubbed;
		if (quotes.length < sd.days + 1) {
			sd.error = true;
			return;
		}

		CIQ.Studies.MA("simple", sd.days, "hlc/3", 0, "MA", stx, sd);

		for (var i = Math.max(sd.startFrom, sd.days - 1); i < quotes.length; i++) {
			var quote = quotes[i];
			if (!quote) continue;
			var md = 0;
			for (var j = 0; j < sd.days; j++) {
				md += Math.abs(quotes[i - j]["hlc/3"] - quote["MA " + sd.name]);
			}
			md /= sd.days;
			if (Math.abs(md) < 0.00000001) quote["Result " + sd.name] = 0;
			else
				quote["Result " + sd.name] =
					(quote["hlc/3"] - quote["MA " + sd.name]) / (0.015 * md);
		}
	};

    CIQ.Studies.calculateSTMovingAverage = function (stx, sd) {
        if (!sd.chart.scrubbed) return;
        var type = sd.inputs.Type;
        if (type == "ma" || type == "sma" || !type) type = "simple"; // handle when the default inputs are passed in
        var typeMap = CIQ.Studies.movingAverage.typeMap;
        if (type in typeMap) {
            return CIQ.Studies["calculateMovingAverage" + typeMap[type]](stx, sd);
        } else if (type !== "simple") {
            return;
        }
        var quotes = sd.chart.scrubbed;
        var acc = 0;
        var vals = [];
        var name = sd.name;

        for (var p in sd.outputs) {
            name = p + " " + name;
        }

		// 拼接显示名
		// const desc = ' '+sd.name.match(/\(([^)]+)\)/)[0];
		// var name = 'MA ' + desc;

        var field = sd.inputs.Field;
        if (!field || field == "field") field = "Close"; // Handle when the default inputs are passed in
        var offset = parseInt(sd.inputs.Offset, 10);
        if (isNaN(offset)) offset = 0;
        var i,
            val,
            ft,
            start = sd.startFrom;
        // backload the past data into the array
        var offsetBack = offset;
        for (i = sd.startFrom - 1; i >= 0; i--) {
            val = quotes[i][field];
           
            if (val && typeof val == "object") val = val[sd.subField];
            if (!val && val !== 0) continue;
            if (offsetBack > 0) {
                offsetBack--;
                start = i;
                continue;
            }
            if (vals.length == sd.days - 1) break;
            acc += val;
            vals.unshift(val);
        }
        if (vals.length < sd.days - 1) {
            vals = [];
            start = 0; // not enough records to continue where left off
        }
        var futureTicks = [];
        for (i = start; i < quotes.length; i++) {
            var quote = quotes[i];
            val = quote[field];
            if (val && typeof val == "object") val = val[sd.subField];
            var notOverflowing = i + offset >= 0 && i + offset < quotes.length;
            var offsetQuote = notOverflowing ? quotes[i + offset] : null;
            if (!val && val !== 0) {
                if (offsetQuote) offsetQuote[name] = null;
                else if (i + offset >= quotes.length) {
                    ft = {};
                    ft[name] = null;
                    futureTicks.push(ft);
                }
                continue;
            }
            acc += val;
            vals.push(val);
            if (vals.length > sd.days) acc -= vals.shift();
            var myVal = vals.length == sd.days ? acc / sd.days : null;
            if (offsetQuote) offsetQuote[name] = myVal;
            else if (i + offset >= quotes.length) {
                ft = {};
                ft[name] = myVal;
                futureTicks.push(ft);
            }
        }
		//console.log(futureTicks)
        sd.appendFutureTicks(stx, futureTicks);
		//sd.outputMap[name] = "MA";
    };

	CIQ.Studies.calculateMovingAverageHull = function (stx, sd) {
		var quotes = sd.chart.scrubbed;

		var field = sd.inputs.Field;
		if (!field || field == "field") field = "Close"; // Handle when the default inputs are passed in

		CIQ.Studies.MA("wma", sd.days, field, 0, "_WMA1", stx, sd);
		CIQ.Studies.MA("wma", Math.ceil(sd.days / 2), field, 0, "_WMA2", stx, sd);

		var i, val;
		for (i = sd.startFrom - 1; i >= 0; i--) {
			val = quotes[i][field];
			if (val && typeof val == "object") val = val[sd.subField];
			if (val || val === 0) break;
		}
		for (i++; i < quotes.length; i++) {
			var quote = quotes[i];
			quote["_MMA " + sd.name] =
				2 * quote["_WMA2 " + sd.name] - quote["_WMA1 " + sd.name];
		}

		var offset = parseInt(sd.inputs.Offset, 10);
		if (isNaN(offset)) offset = 0;

		var hmaDays = Math.floor(Math.sqrt(sd.days));
		CIQ.Studies.MA("wma", hmaDays, "_MMA " + sd.name, offset, "_HMA", stx, sd);

		var name = sd.name;
		for (var p in sd.outputs) {
			name = p + " " + name;
		}
		for (
			i = Math.max(sd.days + hmaDays - 1, sd.startFrom);
			i < quotes.length;
			i++
		) {
			quotes[i][name] = quotes[i]["_HMA " + sd.name];
		}
	};

	CIQ.Studies.calculateMovingAverageDoubleExponential = function (stx, sd) {
		var quotes = sd.chart.scrubbed;

		var field = sd.inputs.Field;
		if (!field || field == "field") field = "Close"; // Handle when the default inputs are passed in

		CIQ.Studies.MA("ema", sd.days, field, 0, "_EMA1", stx, sd);
		CIQ.Studies.MA("ema", sd.days, "_EMA1 " + sd.name, 0, "_EMA2", stx, sd);

		var offset = parseInt(sd.inputs.Offset, 10);
		if (isNaN(offset)) offset = 0;
		var i, val;
		var offsetBack = offset;
		for (i = sd.startFrom - 1; i >= 0; i--) {
			val = quotes[i][field];
			if (val && typeof val == "object") val = val[sd.subField];
			if (!val && val !== 0) continue;
			if (offsetBack > 0) {
				offsetBack--;
				continue;
			}
			break;
		}
		var name = sd.name;
		for (var p in sd.outputs) {
			name = p + " " + name;
		}
		var futureTicks = [];
		for (i++; i < quotes.length; i++) {
			if (i < 2 * (sd.days - 1)) continue;
			var quote = quotes[i];
			var result = 2 * quote["_EMA1 " + sd.name] - quote["_EMA2 " + sd.name];
			if (i + offset >= 0) {
				if (i + offset < quotes.length) quotes[i + offset][name] = result;
				else {
					var ft = {};
					ft[name] = result;
					futureTicks.push(ft);
				}
			}
		}
		sd.appendFutureTicks(stx, futureTicks);
	};

	CIQ.Studies.calculateMovingAverageTripleExponential = function (stx, sd) {
		var quotes = sd.chart.scrubbed;

		var field = sd.inputs.Field;
		if (!field || field == "field") field = "Close"; // Handle when the default inputs are passed in

		CIQ.Studies.MA("ema", sd.days, field, 0, "_EMA1", stx, sd);
		CIQ.Studies.MA("ema", sd.days, "_EMA1 " + sd.name, 0, "_EMA2", stx, sd);
		CIQ.Studies.MA("ema", sd.days, "_EMA2 " + sd.name, 0, "_EMA3", stx, sd);

		var offset = parseInt(sd.inputs.Offset, 10);
		if (isNaN(offset)) offset = 0;
		var i, val;
		var offsetBack = offset;
		for (i = sd.startFrom - 1; i >= 0; i--) {
			val = quotes[i][field];
			if (val && typeof val == "object") val = val[sd.subField];
			if (!val && val !== 0) continue;
			if (offsetBack > 0) {
				offsetBack--;
				continue;
			}
			break;
		}
		var name = sd.name;
		for (var p in sd.outputs) {
			name = p + " " + name;
		}
		var futureTicks = [];
		for (i++; i < quotes.length; i++) {
			if (i < 3 * (sd.days - 1)) continue;
			var quote = quotes[i];
			var result =
				3 * quote["_EMA1 " + sd.name] -
				3 * quote["_EMA2 " + sd.name] +
				quote["_EMA3 " + sd.name];
			if (i + offset >= 0) {
				if (i + offset < quotes.length) quotes[i + offset][name] = result;
				else {
					var ft = {};
					ft[name] = result;
					futureTicks.push(ft);
				}
			}
		}
		sd.appendFutureTicks(stx, futureTicks);
	};

	CIQ.Studies.calculateMAEnvelope = function (stx, sd) {
		var field = sd.inputs.Field;
		if (!field || field == "field") field = "Close";
		CIQ.Studies.MA(
			sd.inputs["Moving Average Type"],
			sd.days,
			field,
			0,
			"MA",
			stx,
			sd
		);
		var shiftType = sd.inputs["Shift Type"];
		var shift = sd.inputs.Shift;
		if (!shiftType) {
			//legacy
			shiftType = "percent";
			shift = sd.inputs["Shift Percentage"];
		}
		if (shiftType == "percent") {
			CIQ.Studies.calculateGenericEnvelope(
				stx,
				sd,
				shift / 100,
				"MA " + sd.name
			);
		} else if (shiftType == "points") {
			CIQ.Studies.calculateGenericEnvelope(
				stx,
				sd,
				null,
				"MA " + sd.name,
				null,
				Number(shift)
			);
		}
	};

	CIQ.Studies.calculateSTMADev = function (stx, sd) {
        console.log("STMADEV")
		var quotes = sd.chart.scrubbed;
		if (quotes.length < sd.days + 1) {
			sd.error = true;
			return;
		}
		var field = sd.inputs.Field;
		if (!field || field == "field") field = "Close";
		var pts = sd.inputs["Points Or Percent"];
		if (!pts) pts = "Points";
		var maType = sd.inputs["Moving Average Type"];
		if (!maType) maType = "exponential";
		CIQ.Studies.MA(maType, sd.days, field, 0, "_MA", stx, sd);
		var histogram = sd.name + "_hist";
		for (var i = Math.max(sd.startFrom, sd.days - 1); i < quotes.length; i++) {
			var quote = quotes[i];
			var val = quote[field];
			if (val && typeof val == "object") val = val[sd.subField];
			var qMA = quote["_MA " + sd.name];
			if (qMA || qMA === 0) {
				if (pts == "Points") quote[histogram] = val - qMA;
				else quote[histogram] = 100 * (val / qMA - 1);
			}
		}
		sd.outputMap = {};
		sd.outputMap[sd.name + "_hist"] = "";
	};

	CIQ.Studies.calculateSTCenterOfGravity = function (stx, sd) {
		var quotes = sd.chart.scrubbed;
		if (quotes.length < sd.days) {
			sd.error = true;
			return;
		}
		var field = sd.inputs.Field;
		if (!field || field == "field") field = "Close";
		for (var i = Math.max(sd.startFrom, sd.days - 1); i < quotes.length; i++) {
			var num = 0,
				den = 0;
			for (var j = 0; j < sd.days; j++) {
				var val = quotes[i - j][field];
				num -= (j + 1) * val;
				den += val;
			}
			if (den) quotes[i]["Result " + sd.name] = num / den;
		}
	};

	CIQ.Studies.calculateSTROCLike = function (stx, sd) {
		var quotes = sd.chart.scrubbed;
		var field = sd.inputs.Field;
		var condition = sd.inputs.condition;
		var period = sd.inputs.period;
		const desc = ' '+sd.name.match(/\(([^)]+)\)/)[0];

		if (!field || field == "field") field = "Close";

		// 下面为计算 ROC, ROR, MAR 的具体公式。
		// 备选公式
		function calculateNewConditions1(){
			//console.log(data_series)
			const shiftBar = 2;
		
			const rocArr = [];
			const minCloseArr = [];
			const maxCloseArr = [];
			const rorArr = [];
			const maPeriod = 5;
			const maArr = [];
			const marArr = [];
			
			for (let i = 0; i < dataDF.length; i++) {
				if (i < shiftBar) {
				  rocArr.push(NaN);
				  minCloseArr.push(NaN);
				  maxCloseArr.push(NaN);
				  rorArr.push(NaN);
				} else {
				  const close = dataDF[i].Close;
				  const shiftBarClose = dataDF[i - shiftBar].Close;
				  const roc = Number(((close / shiftBarClose - 1) * 100).toFixed(2));
				  rocArr.push(roc);
			  
				  const minClose = getPeriodParam(dataDF.slice(0, i + 1).map(x => x.Close), "min", shiftBar)[i];
				  minCloseArr.push(minClose);
			  
				  const maxClose = getPeriodParam(dataDF.slice(0, i + 1).map(x => x.Close), "max", shiftBar)[i];
				  maxCloseArr.push(maxClose);
			  
				  const ror = Number(((close - minClose) / (maxClose - minClose) * 100).toFixed(2));
				  rorArr.push(ror);
				}
			  
				if (i < maPeriod - 1) {
				  maArr.push(NaN);
				  marArr.push(NaN);
				} else {
				  const ma = Number((dataDF.slice(i - maPeriod + 1, i + 1).map(x => x.Close).reduce((a, b) => a + b) / maPeriod).toFixed(2));
				  maArr.push(ma);
			  
				  const mar = Number(((dataDF[i].Close / ma - 1) * 100).toFixed(2));
				  marArr.push(mar);
				}
			  }
			  
			  dataDF.forEach((row, i) => {
				row.ShiftBar = i >= shiftBar ? dataDF[i - shiftBar].Close : NaN;
				row.ROC = rocArr[i];
				row.ROR = rorArr[i];
				console.log(maArr[i])
				row.MA = maArr[i];
				row.MAR = marArr[i];
			  })
			console.log(dataDF)
		}
		// 使用中公式
		let resArr = []
		switch(condition){
			case 'ROC':
				// ROC
				resArr = quotes.map((row, i) => {
					if(i>=period){
						const change = parseFloat((100 * (row[field] / quotes[i - period][field]- 1)).toFixed(2))
						return change==Infinity ? 0 : change
					}else{
						return NaN
					}
				});
				break;
			case 'ROR':
				// ROR
				const minCloseArr = getPeriodParam(quotes.map(row => row[field]), "min", period);
				const maxCloseArr = getPeriodParam(quotes.map(row => row[field]), "max", period);
				resArr = quotes.map((row, i) => {
					if(i>=period){
						const change = parseFloat((100 * (row[field] - minCloseArr[i]) / (maxCloseArr[i] - minCloseArr[i])).toFixed(2))
						return change==Infinity ? 0 : change
					}else{
						return NaN
					}
				});
				break;
			case 'MA':
				// MA
				const maArr = quotes.map((row, i, arr) => i >= period - 1 ? parseFloat((arr.slice(i - period + 1, i + 1).reduce((a, b) => a + b[field], 0) / period).toFixed(2)) : NaN);
				resArr = quotes.map((row, i) => i >= period - 1 ? parseFloat((100 * (row[field] / maArr[i] - 1)).toFixed(2)) : NaN);
				break;
			default:
				console.error('no such condition')
		}
		
		for (var i = sd.startFrom; i < quotes.length; i++) {
			var quote = quotes[i];
			if(resArr[i]==Infinity){
				console.log('calculateSTROCLike',quote)
			}
			
			quote[sd.inputs.display+desc] = resArr[i];
		}
		
		sd.outputMap[sd.inputs.display+desc] = "ROCLike";
		
		// 给上面函数用的工具函数
		function getPeriodParam(dataSeries, paramType, period) {
			const typeDict = {
			  max: Math.max,
			  min: Math.min,
			  mean: arr => arr.reduce((a, b) => a + b) / arr.length,
			  sum: arr => arr.reduce((a, b) => a + b),
			};
		  
			const dataArr = [];
		  
			for (let i = 0; i < dataSeries.length; i++) {
			  if (i >= period) {
				const tmpData = typeDict[paramType](...dataSeries.slice(i - period, i + 1));
				dataArr.push(Number(tmpData.toFixed(3)));
			  } else {
				dataArr.push(NaN);
			  }
			}
		  
			return dataArr;
		  }

		// 默认study模板
		// for (var i = sd.startFrom; i < quotes.length; i++) {
		// 	var quote = quotes[i];
		// 	var RSIValue = quote[field];
		// 	if (RSIValue) {
		// 		var customStudyValue = RSIValue; // add code here to operate on the RSI to compute your final value based on it.
		// 		quote["Result " + sd.name] = customStudyValue; // assign to the final field to be used by your display function.
		// 	}
		// }
		// sd.outputMap["Result " + sd.name] = "ROCLike";
	};

	CIQ.Studies.studyLibrary = CIQ.extend(CIQ.Studies.studyLibrary, {
		"ST ROCLike": {
            name: "ROCLike Lines",
            calculateFN: CIQ.Studies.calculateSTROCLike,
            inputs: { Field: "field",condition: "ROC",period: 5,overlay: false},
			outputs: { ROCLike: "auto" },
        },
		"Center of Gravity": {
			name: "Center of Gravity",
			calculateFN: CIQ.Studies.calculateSTCenterOfGravity,
			inputs: { Period: 10, Field: "field" }
		},
		"rsi": {
			name: "RSI",
			inputs: { Period: 14, Field: "field" },
			calculateFN: CIQ.Studies.calculateSTRSI,
			range: "0 to 100",
			outputs: { RSI: "auto" },
			parameters: {
				init: {
					studyOverZonesEnabled: true,
					studyOverBoughtValue: 80,
					studyOverBoughtColor: "auto",
					studyOverSoldValue: 20,
					studyOverSoldColor: "auto"
				}
			}
		},
		"macd": {
			name: "MACD",
			calculateFN: CIQ.Studies.calculateSTMACD,
			seriesFN: CIQ.Studies.displayHistogramWithSeries,
			inputs: {
				"Fast MA Period": 12,
				"Slow MA Period": 26,
				"Signal Period": 9
			},
			outputs: {
				MACD: "auto",
				SignalLine: "#FF0000",
				"Increasing Bar": "#00DD00",
				"Decreasing Bar": "#FF0000"
			}
		},
		"cci": {
			name: "Commodity Channel Index",
			calculateFN: CIQ.Studies.calculateSTCCI,
			inputs: { Period: 20 },
			parameters: {
				init: {
					studyOverZonesEnabled: true,
					studyOverBoughtValue: 100,
					studyOverBoughtColor: "auto",
					studyOverSoldValue: -100,
					studyOverSoldColor: "auto"
				}
			},
			attributes: {
				Period: { min: 2 }
			}
		},
        "ST MA": {
            name: "Moving Average ",
            overlay: true,
            calculateFN: CIQ.Studies.calculateSTMovingAverage,
            inputs: { Period: 20, Field: "field", Type: "ma", Offset: 0 },
            outputs: { MA: "#FF000" },
        },
		"MA Env": {
			name: "Moving Average Envelope",
			overlay: true,
			seriesFN: CIQ.Studies.displayChannel,
			calculateFN: CIQ.Studies.calculateMAEnvelope,
			inputs: {
				Period: 50,
				Field: "field",
				"Shift Type": ["percent", "points"],
				Shift: 5,
				"Moving Average Type": "ma",
				"Channel Fill": true
			},
			outputs: {
				"MA Env Top": "auto",
				"MA Env Median": "auto",
				"MA Env Bottom": "auto"
			},
			attributes: {
				Shift: { min: 0.1, step: 0.1 }
			}
		},
		"MA Dev": {
			name: "Moving Average Deviation",
                            calculateFN: CIQ.Studies.calculateSTMADev,
                            seriesFN: CIQ.Studies.displayHistogramWithSeries,
                            inputs: { Period: 13, Overlay: false, Field: "field", "Moving Average Type": "ma",
                            "Points Or Percent": ["Points", "Percent"] },
                            outputs: 
                            {"Increasing Bar": "#00DD00", "Decreasing Bar": "#FF0000"},
                            
		},
		"High Low": {
			name: "High Low Bands",
			overlay: true,
			seriesFN: CIQ.Studies.displayChannel,
			calculateFN: function (stx, sd) {
				sd.inputs["Moving Average Type"] = "triangular";
				CIQ.Studies.calculateMAEnvelope(stx, sd);
			},
			inputs: {
				Period: 10,
				Field: "field",
				"Shift Percentage": 5,
				"Channel Fill": true
			},
			outputs: {
				"High Low Top": "auto",
				"High Low Median": "auto",
				"High Low Bottom": "auto"
			},
			attributes: {
				"Shift Percentage": { min: 0.1, step: 0.1 }
			}
		}
	});
	
}

};
__js_st_studies_movingAverages_(typeof window !== "undefined" ? window : global);
