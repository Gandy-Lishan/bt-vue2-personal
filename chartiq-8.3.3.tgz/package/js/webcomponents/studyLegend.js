/**
 *	8.3.0
 *	Generation date: 2021-11-02T13:40:51.589Z
 *	Client name: sundial capital research
 *	Package Type: Technical Analysis
 *	License type: annual
 *	Expiration date: "2022/10/01"
 *	Domain lock: ["127.0.0.1","localhost","sentimentrader.com","18.117.142.18","bt20.sentimentrader.com"]
 *	iFrame lock: true
 */

/***********************************************************
 * Copyright by ChartIQ, Inc.
 * Licensed under the ChartIQ, Inc. Developer License Agreement https://www.chartiq.com/developer-license-agreement
*************************************************************/
/*************************************** DO NOT MAKE CHANGES TO THIS LIBRARY FILE!! **************************************/
/* If you wish to overwrite default functionality, create a separate file with a copy of the methods you are overwriting */
/* and load that file right after the library has been loaded, but before the chart engine is instantiated.              */
/* Directly modifying library files will prevent upgrades and the ability for ChartIQ to support your solution.          */
/*************************************************************************************************************************/
/* eslint-disable no-extra-parens */


import { CIQ as _CIQ } from "../../js/componentUI.js";
import "../../js/standard/studies.js";


/* global _CIQ, _timezoneJS, _SplinePlotter */


var CIQ = typeof _CIQ !== "undefined" ? _CIQ : _exports.CIQ;

if (!CIQ.Studies) {
	console.error(
		"studyLegend component requires first activating studies feature."
	);
} else {
	/**
	 * Study legend web component `<cq-study-legend>`.
	 *
	 * Click on the "X" to remove the study.
	 * Click on the cog to edit the study.
	 * Optionally only show studies needing custom Removal. cq-custom-removal-only
	 * Optionally only show overlays. cq-overlays-only
	 * Optionally only show studies in this panel. cq-panel-only
	 * Optionally clone to all panels. cq-clone-to-panels="Plots" or whatever name you choose
	 * Optionally specify selector for which nodes have content. cq-content-keys
	 *
	 * **Keyboard control**
	 *
	 * When selected with tab key navigation and activated with Return/Enter, this component has
	 * the following internal controls:
	 * - Up/Down arrow &mdash; Move selection between internal cq-item and cq-comparison-item
	 * elements.
	 * - Left/Right arrow &mdash; Select a control within a selected cq-item element, such as
	 * the Remove button. Child elements must have the attribute `keyboard-selectable-child` set to
	 * "true" to be selectable with these keys.
	 *
	 * @namespace WebComponents.cq-study-legend
	 * @since 8.3.0 Enabled internal keyboard navigation and selection.
	 *
	 * @example
	 * <caption>
	 *     Here is an example of how to create a study legend on the chart. We use the
	 *     <code>cq-marker</code> attribute to ensure that it floats inside the chart. We set the
	 *     optional <code>cq-panel-only</code> attribute so that only studies from this panel are
	 *     displayed.
	 * </caption>
	 * <cq-study-legend cq-marker-label="Studies" cq-overlays-only cq-marker cq-hovershow>
	 *     <template>
	 *         <cq-item>
	 *             <cq-label></cq-label>
	 *             <span class="ciq-edit"></span>
	 *             <div class="ciq-icon ciq-close"></div>
	 *         </cq-item>
	 *     </template>
	 * </cq-study-legend>
	 *
	 * @example
	 * <caption>
	 *     Here is an example of how to create a study legend inside a drop down menu. We use the
	 *     <code>cq-no-close</code> attribute so that drop down is not closed when the user removes
	 *     a study from the list.
	 * </caption>
	 * <cq-menu class="ciq-menu ciq-studies collapse">
	 *     <span>Studies</span>
	 *     <cq-menu-dropdown cq-no-scroll>
	 *         <cq-study-legend cq-no-close>
	 *             <cq-section-dynamic>
	 *                 <cq-heading>Current Studies</cq-heading>
	 *                 <cq-study-legend-content>
	 *                     <template cq-study-legend>
	 *                         <cq-item>
	 *                             <cq-label class="click-to-edit"></cq-label>
	 *                             <div class="ciq-icon ciq-close"></div>
	 *                         </cq-item>
	 *                     </template>
	 *                 </cq-study-legend-content>
	 *                 <cq-placeholder>
	 *                     <div stxtap="Layout.clearStudies()" class="ciq-btn sm">Clear All</div>
	 *                 </cq-placeholder>
	 *             </cq-section-dynamic>
	 *         </cq-study-legend>
	 *         <cq-scroll>
	 *             <cq-studies>
	 *                 <cq-studies-content>
	 *                     <template>
	 *                         <cq-item>
	 *                             <cq-label></cq-label>
	 *                         </cq-item>
	 *                     </template>
	 *                 </cq-studies-content>
	 *             </cq-studies>
	 *         </cq-scroll>
	 *     </cq-menu-dropdown>
	 * </cq-menu>
	 */
	class StudyLegend extends CIQ.UI.ModalTag {
		connectedCallback() {
			if (this.attached) return;
			super.connectedCallback();
			if (this.node.attr("cq-clone-to-panels") !== undefined) {
				document.body.classList.add("stx-panel-legend");
			}

			if (!this.hasAttribute("cq-no-claim")) this.addClaim(this);
			// Update the keyboard navigation. New study legend components can be added at runtime.
			if (this.context && this.context.config && this.context.config.channels) {
				this.channelWrite(
					this.context.config.channels.keyboardNavigation ||
						"channel.keyboardNavigation",
					{ action: "registerElements" }
				);
			}
		}

		disconnectedCallback() {
			// Update the keyboard navigation. Need to remove this element from the index now that it's detached
			if (this.context && this.context.config && this.context.config.channels) {
				this.channelWrite(
					this.context.config.channels.keyboardNavigation ||
						"channel.keyboardNavigation",
					{ action: "registerElements" }
				);
			}
		}

		/**
		 * Begins running the StudyLegend.
		 * @memberof! WebComponents.cq-study-legend
		 * @private
		 */
		begin() {
			if (this.init) return;
			var stx = this.context.stx;
			var node = this.node;

			this.template = node.find("template[cq-study-legend]");
			if (!this.template.length) this.template = node.find("template"); // backwards compatibility, this can fail if more than one template is present!
			this.contentKeys = node.attr("cq-content-keys") || "cq-label";

			this.eventListeners.push(
				stx.addEventListener("layout", this.renderLegend.bind(this))
			);

			if (this.hasAttribute("cq-marker")) {
				CIQ.UI.stxtap(this, function () {
					node[0].classList.toggle("ciq-active");
				});
			}

			this.renderLegend();
			this.init = true;
		}

		keyStroke(hub, key, e) {
			if (!this.keyboardNavigation) return;
			const items = this.querySelectorAll(
				"[keyboard-selectable='true'], cq-item:not(.item-hidden), cq-comparison-item"
			);

			if (key == " " || key == "Spacebar" || key == "Enter") {
				const focused = this.findFocused(items);
				if (!focused || !focused.length) return;
				const childItemsSelected = focused[0].querySelectorAll(
					"[keyboard-selectable-child='true'][cq-focused]"
				);
				if (childItemsSelected.length) this.clickItem(childItemsSelected[0], e);
				else this.clickItem(focused[0], e);
			} else if (key == "ArrowDown" || key == "Down") {
				this.focusNextItem(items);
			} else if (key == "ArrowUp" || key == "Up") {
				this.focusNextItem(items, true);
			} else if (key == "ArrowRight" || key == "Right") {
				const focused = this.findFocused(items);
				if (!focused || !focused.length) return;
				const childItems = focused[0].querySelectorAll(
					"[keyboard-selectable-child='true']"
				);
				if (childItems.length) this.focusNextItem(childItems);
			} else if (key == "ArrowLeft" || key == "Left") {
				const focused = this.findFocused(items)[0];
				if (!focused) return;
				const childItems = focused.querySelectorAll(
					"[keyboard-selectable-child='true']"
				);
				// If the end of the child items has been reached select the parent item instead
				if (childItems.length && !this.focusNextItem(childItems, true)) {
					this.removeFocused(childItems);
					this.focusItem(focused);
				}
			} else if (key === "Tab" || key === "Esc" || key === "Escape") {
				this.removeFocused(items);
				this.classList.remove("ciq-active");
				// Wait for transition
				setTimeout(() => this.keyboardNavigation.tabOrderSelect(), 500);
			}
		}

		/**
		 * If a color-picker is opened within this component, this will make sure the component stays active.
		 * @memberof! WebComponents.cq-study-legend
		 */
		launchColorPicker() {
			this.node.addClass("ciq-active");
		}

		/**
		 * Renders the legend based on the current studies in the CIQ.ChartEngine object.
		 * @memberof! WebComponents.cq-study-legend
		 */
		renderLegend() {
			var stx = this.context.stx;

			this.template.nextAll().remove();

			function closeStudy(self, sd) {
				return function (e) {
					e.stopPropagation();
					// Need to run this in the nextTick because the study legend can be removed by this click
					// causing the underlying chart to receive the mousedown (on IE win7)
					setTimeout(function () {
						if (!sd.permanent) CIQ.Studies.removeStudy(self.context.stx, sd);
						if (self.node[0].hasAttribute("cq-marker"))
							self.context.stx.modalEnd();
						self.renderLegend();
					}, 0);
				};
			}
			function editStudy(self, studyId) {
				return function (e) {
					var sd = stx.layout.studies[studyId];
					if (sd.permanent || !sd.editFunction) return;
					e.stopPropagation();
					self.uiManager.closeMenu();
					var studyEdit = self.context.getAdvertised("StudyEdit");
					var params = {
						stx: stx,
						sd: sd,
						inputs: sd.inputs,
						outputs: sd.outputs,
						parameters: sd.parameters
					};
					studyEdit.editPanel(params);
				};
			}
			var overlaysOnly = this.hasAttribute("cq-overlays-only");
			var panelOnly = this.hasAttribute("cq-panel-only");
			var customRemovalOnly = this.hasAttribute("cq-custom-removal-only");
			var markerLabel = this.node.attr("cq-marker-label");
			var panelName = null;
			var holder = this.node.parents(".stx-holder")[0];
			if (holder) panelName = holder.panel.name;

			if (CIQ.Studies) {
				for (var id in stx.layout.studies) {
					var sd = stx.layout.studies[id];
					if (sd.customLegend) continue;
					if (customRemovalOnly && !sd.study.customRemoval) continue;
					if (panelOnly && sd.panel != panelName) continue;
					if (overlaysOnly && !sd.overlay && !sd.underlay) continue;
					var newChild = CIQ.UI.makeFromTemplate(this.template, true);
					newChild.find("cq-label").html(sd.inputs.display);
					var close = newChild.find(".ciq-close");
					if (sd.permanent) {
						close.hide();
					} else {
						close[0].setAttribute("keyboard-selectable-child", "true");
						CIQ.UI.stxtap(close[0], closeStudy(this, sd));
					}
					var edit = newChild.find(".ciq-edit")[0];
					if (edit && !sd.editFunction) {
						edit.style.visibility = "hidden";
					} else if (sd.editFunction) {
						// Put the edit function on the parent so it responds to a keyboard navigation click
						CIQ.UI.stxtap(newChild[0], editStudy(this, id));
					}
				}
			}
			//Only want to display the marker label if at least one study has been
			//rendered in the legend. If no studies are rendered, only the template tag
			//will be in there.
			if (typeof markerLabel != "undefined") {
				if (!this.node.find("cq-marker-label").length) {
					var label = document.createElement("cq-marker-label");
					label.innerText = markerLabel;
					this.insertBefore(label, this.firstChild);
				}
			}

			this.displayLegendTitle();
		}

		displayLegendTitle() {
			if (hasKeys(this, this.contentKeys)) {
				this.node.css("display", "");
				this.node.parents("div.stx-panel-legend").css("width", "");
			} else {
				this.node.css("display", "none");
				this.node.parents("div.stx-panel-legend").css("width", "0px");
			}
			if (CIQ.I18N && CIQ.I18N.localized)
				CIQ.I18N.translateUI(null, this.node[0]);

			function hasKeys(node, keys) {
				// checks if key is not template as in frameworks such as React or Angular
				// templates may be rendered as regular node allowing to inner content queries
				return Array.from(node.querySelectorAll(keys)).some(notInTemplate);
			}

			function notInTemplate(el) {
				while (el) {
					if (el.nodeName.toLowerCase() === "template") return false;
					el = el.parentElement;
				}
				return true;
			}
		}

		setContext(context) {
			if (this.init) return;
			var self = this;
			if (self.node.attr("cq-clone-to-panels") !== undefined) {
				self.spawnPanelLegend();
				context.stx.append("stackPanel", function (display, name) {
					self.spawnPanelLegend();
				});
			}
			this.begin();
		}

		spawnPanelLegend() {
			var stx = this.context.stx;
			function tap(legend) {
				return function (e) {
					legend.classList.toggle("ciq-active");
				};
			}
			for (var p in stx.panels) {
				if (p == stx.chart.panel.name) continue;
				var legendHolder = stx.panels[p].subholder.querySelector(
					".stx-panel-legend"
				);
				if (legendHolder) {
					var panelLegend = legendHolder.querySelector(this.nodeName);
					if (!panelLegend) {
						panelLegend = this.cloneNode(true);
						panelLegend.setAttribute(
							"cq-marker-label",
							this.getAttribute("cq-clone-to-panels")
						);
						panelLegend.removeAttribute("cq-clone-to-panels");
						panelLegend.removeAttribute("cq-overlays-only");
						panelLegend.removeAttribute("cq-marker");
						CIQ.UI.stxtap(panelLegend, tap(panelLegend));
						var mLabel = panelLegend.querySelector("cq-marker-label");
						if (mLabel) mLabel.remove();
						var fixedWrapper = document.createElement(
							"cq-study-legend-fixed-wrapper"
						);
						fixedWrapper.appendChild(panelLegend);
						legendHolder.appendChild(fixedWrapper);
						panelLegend.begin();
					}
				}
			}
		}
	}

	CIQ.UI.addComponentDefinition("cq-study-legend", StudyLegend);
}
