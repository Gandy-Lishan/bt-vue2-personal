/**
 *	8.3.0
 *	Generation date: 2021-11-02T13:40:51.589Z
 *	Client name: sundial capital research
 *	Package Type: Technical Analysis
 *	License type: annual
 *	Expiration date: "2022/10/01"
 *	Domain lock: ["127.0.0.1","localhost","sentimentrader.com","18.117.142.18","bt20.sentimentrader.com"]
 *	iFrame lock: true
 */

/***********************************************************
 * Copyright by ChartIQ, Inc.
 * Licensed under the ChartIQ, Inc. Developer License Agreement https://www.chartiq.com/developer-license-agreement
*************************************************************/
/*************************************** DO NOT MAKE CHANGES TO THIS LIBRARY FILE!! **************************************/
/* If you wish to overwrite default functionality, create a separate file with a copy of the methods you are overwriting */
/* and load that file right after the library has been loaded, but before the chart engine is instantiated.              */
/* Directly modifying library files will prevent upgrades and the ability for ChartIQ to support your solution.          */
/*************************************************************************************************************************/
/* eslint-disable no-extra-parens */


import { CIQ as _CIQ } from "../../js/componentUI.js";
import "../../js/webcomponents/dialog.js";
import "../../js/webcomponents/close.js";


/* global _CIQ, _timezoneJS, _SplinePlotter */



var CIQ = typeof _CIQ !== "undefined" ? _CIQ : _exports.CIQ;

/**
 * Aggregation Dialog web component `<cq-aggregation-dialog>`.
 *
 * @namespace WebComponents.cq-aggregation-dialog
 */
class AggregationDialog extends CIQ.UI.DialogContentTag {
	/**
	 * Opens the nearest {@link WebComponents.cq-dialog} to display your dialog.
	 * @alias open
	 * @memberof WebComponents.cq-aggregation-dialog
	 */
	open(params) {
		this.addDefaultMarkup();
		super.open(params);
		var stx = this.context.stx;
		var aggregationType = params.aggregationType;
		var map = {
			kagi: {
				title: "Set Reversal Percentage"
			},
			renko: {
				title: "Set Brick Size"
			},
			linebreak: {
				title: "Set Price Lines"
			},
			rangebars: {
				title: "Set Range"
			},
			pandf: {
				title: "Set Point & Figure Parameters"
			}
		};
		if (stx.layout.aggregationType != aggregationType)
			stx.setAggregationType(aggregationType);

		var entry = map[aggregationType];
		var node = this.node;
		node.find(".title").text(stx.translateIf(entry.title));

		for (var type in map) {
			node
				.find(".ciq" + type)
				.css(aggregationType === type ? { display: "" } : { display: "none" });
		}
		node.find(".ciq" + aggregationType + " input").each(function () {
			var name = this.name;
			if (name == "box" || name == "reversal") name = "pandf." + name;
			var tuple = CIQ.deriveFromObjectChain(stx.layout, name);
			if (tuple && (tuple.obj[tuple.member] || tuple.obj[tuple.member] === 0)) {
				this.value = tuple.obj[tuple.member];
			} else if (stx.chart.defaultChartStyleConfig[this.name]) {
				this.value = stx.chart.defaultChartStyleConfig[this.name];
			}
		});
	}
}

AggregationDialog.markup = `
		<h4 class="title"></h4>
		<cq-close></cq-close>
		<div style="text-align:center;margin-top:10px;">
			<div class="ciqkagi">
				<i>Enter value and hit "Enter"</i>
				<p>
					<input name="kagi" stxtap="Layout.setAggregationEdit('kagi')">
				</p>
			</div>
			<div class="ciqrenko">
				<i>Enter value and hit "Enter"</i>
				<p>
					<input name="renko" stxtap="Layout.setAggregationEdit('renko')">
				</p>
			</div>
			<div class="ciqlinebreak">
				<i>Enter value and hit "Enter"</i>
				<p>
					<input name="priceLines" stxtap="Layout.setAggregationEdit('priceLines')">
				</p>
			</div>
			<div class="ciqrangebars">
				<i>Enter value and hit "Enter"</i>
				<p>
					<input name="range" stxtap="Layout.setAggregationEdit('rangebars')">
				</p>
			</div>
			<div class="ciqpandf">
				<i>Enter box size and hit "Enter"</i>
				<p>
					<input name="box" stxtap="Layout.setAggregationEdit('pandf.box')">
				</p>
				<p>
					<i>Enter reversal and hit "Enter"</i>
				</p>
				<p>
					<input name="reversal" stxtap="Layout.setAggregationEdit('pandf.reversal')">
				</p>
			</div>
			<p>or</p>
			<div class="ciq-btn" stxtap="Layout.setAggregationEdit('auto')">Auto Select</div>
		</div>

	`;
CIQ.UI.addComponentDefinition("cq-aggregation-dialog", AggregationDialog);
