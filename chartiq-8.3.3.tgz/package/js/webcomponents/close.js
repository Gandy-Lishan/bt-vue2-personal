/**
 *	8.3.0
 *	Generation date: 2021-11-02T13:40:51.589Z
 *	Client name: sundial capital research
 *	Package Type: Technical Analysis
 *	License type: annual
 *	Expiration date: "2022/10/01"
 *	Domain lock: ["127.0.0.1","localhost","sentimentrader.com","18.117.142.18","bt20.sentimentrader.com"]
 *	iFrame lock: true
 */

/***********************************************************
 * Copyright by ChartIQ, Inc.
 * Licensed under the ChartIQ, Inc. Developer License Agreement https://www.chartiq.com/developer-license-agreement
*************************************************************/
/*************************************** DO NOT MAKE CHANGES TO THIS LIBRARY FILE!! **************************************/
/* If you wish to overwrite default functionality, create a separate file with a copy of the methods you are overwriting */
/* and load that file right after the library has been loaded, but before the chart engine is instantiated.              */
/* Directly modifying library files will prevent upgrades and the ability for ChartIQ to support your solution.          */
/*************************************************************************************************************************/
/* eslint-disable no-extra-parens */


import { CIQ as _CIQ } from "../../js/componentUI.js";


/* global _CIQ, _timezoneJS, _SplinePlotter */

var CIQ = typeof _CIQ !== "undefined" ? _CIQ : _exports.CIQ;

/**
 * Close web component `<cq-close>`.
 *
 * cq-close web component will close its containing (parent or up) component
 * by calling its close() method
 * @namespace WebComponents.cq-close
 * @example
 * <cq-item>
 * 		<cq-label></cq-label>
 * 		<cq-close></cq-close>
 * </cq-item>
 *
 */
class Close extends CIQ.UI.BaseComponent {
	connectedCallback() {
		if (this.attached) return;
		var self = this;
		function closure(e) {
			self.tap();
			e.stopPropagation();
		}
		CIQ.UI.stxtap(this, closure);
		super.connectedCallback();
	}

	/**
	 * @alias tap
	 * @memberof WebComponents.cq-close
	 */
	tap() {
		CIQ.UI.containerExecute(this, "close");
	}
}

CIQ.UI.addComponentDefinition("cq-close", Close);
