/**
 *	8.3.0
 *	Generation date: 2021-11-02T13:40:51.589Z
 *	Client name: sundial capital research
 *	Package Type: Technical Analysis
 *	License type: annual
 *	Expiration date: "2022/10/01"
 *	Domain lock: ["127.0.0.1","localhost","sentimentrader.com","18.117.142.18","bt20.sentimentrader.com"]
 *	iFrame lock: true
 */

/***********************************************************
 * Copyright by ChartIQ, Inc.
 * Licensed under the ChartIQ, Inc. Developer License Agreement https://www.chartiq.com/developer-license-agreement
*************************************************************/
/*************************************** DO NOT MAKE CHANGES TO THIS LIBRARY FILE!! **************************************/
/* If you wish to overwrite default functionality, create a separate file with a copy of the methods you are overwriting */
/* and load that file right after the library has been loaded, but before the chart engine is instantiated.              */
/* Directly modifying library files will prevent upgrades and the ability for ChartIQ to support your solution.          */
/*************************************************************************************************************************/
/* eslint-disable no-extra-parens */


import { CIQ as _CIQ } from "../../js/componentUI.js";


/* global _CIQ, _timezoneJS, _SplinePlotter */

var CIQ = typeof _CIQ !== "undefined" ? _CIQ : _exports.CIQ;

/**
 * The dynamic heads up display web component `<cq-hu-dynamic>`.
 *
 * An encapsulation of the markup of a dynamic heads up display.
 *
 * @namespace WebComponents.cq-hu-dynamic
 * @since 7.5.0
 *
 * @example
 * <cq-hu-dynamic>
 *     <svg version="1.1" x="0px" y="0px" viewBox="0 0 215 140" enableBackground="new 0 0 215 140">
 *         <defs>
 *             <filter id="ciq-hu-shadow" height="130%">
 *                 <feGaussianBlur in="SourceAlpha" stdDeviation="1"></feGaussianBlur>
 *                 <feOffset dx="0" dy="1" result="offsetblur"></feOffset>
 *                 <feComponentTransfer>
 *                     <feFuncA type="linear" slope="0.2"></feFuncA>
 *                 </feComponentTransfer>
 *                 <feMerge>
 *                     <feMergeNode></feMergeNode>
 *                     <feMergeNode in="SourceGraphic"></feMergeNode>
 *                 </feMerge>
 *             </filter>
 *         </defs>
 *         <polygon
 *             class="ciq-hu-bg" style="stroke-width: 1;"
 *             points="198.4,124.4 1,124.4 1,1 214,1 214,137.8"
 *             filter="url(#ciq-hu-shadow)"
 *             />
 *         <path class="ciq-hu-stroke"
 *             fill="#398DFF"
 *             d="M213,2v133.6l-13.7-11.8l-0.6-0.5H198H2V2H213 M215,0H0v125.4h198l17,14.6V0L215,0z">
 *         </path>
 *     </svg>
 *     <div>
 *         <cq-hu-col1>
 *             <cq-hu-date></cq-hu-date>
 *             <cq-hu-price></cq-hu-price>
 *             <cq-volume-grouping>
 *                 <div>Volume</div>
 *                 <div><cq-volume-visual></cq-volume-visual></div>
 *                 <div><cq-hu-volume></cq-hu-volume><cq-volume-rollup></cq-volume-rollup></div>
 *             </cq-volume-grouping>
 *         </cq-hu-col1>
 *         <cq-hu-col2>
 *             <div>Open</div><cq-hu-open></cq-hu-open>
 *             <div>Close</div><cq-hu-close></cq-hu-close>
 *             <div>High</div><cq-hu-high></cq-hu-high>
 *             <div>Low</div><cq-hu-low></cq-hu-low>
 *         </cq-hu-col2>
 *     </div>
 * </cq-hu-dynamic>
 */
class HeadsUpDynamic extends CIQ.UI.ContextTag {
	/**
	 * Creates an instance of {@link CIQ.UI.HeadsUp}. Subscribes to the `headsUp` channel
	 * which provides messages to start and stop the marker.
	 *
	 * @param {CIQ.UI.Context} context The chart user interface context.
	 *
	 * @alias setContext
	 * @memberof WebComponents.cq-hu-dynamic
	 * @since 7.5.0
	 */
	setContext(context) {
		this.addDefaultMarkup();
		const UIHeadsUpDynamic = new CIQ.UI.HeadsUp(this, context, {
			followMouse: true,
			autoStart: false
		});

		let headsUp =
			context.config && context.config.channels
				? context.config.channels.headsUp
				: "layout.headsUp";
		this.channelSubscribe(headsUp, (value) => {
			UIHeadsUpDynamic[
				value === "dynamic" || (value || {}).dynamic ? "begin" : "end"
			]();
		});
	}
}

HeadsUpDynamic.markup = `
		<svg version="1.1" x="0px" y="0px" viewBox="0 0 215 140" enableBackground="new 0 0 215 140">
			<defs>
				<filter id="ciq-hu-shadow" height="130%">
					<feGaussianBlur in="SourceAlpha" stdDeviation="1"></feGaussianBlur>
					<feOffset dx="0" dy="1" result="offsetblur"></feOffset>
					<feComponentTransfer>
						<feFuncA type="linear" slope="0.2"></feFuncA>
					</feComponentTransfer>
					<feMerge>
						<feMergeNode></feMergeNode>
						<feMergeNode in="SourceGraphic"></feMergeNode>
					</feMerge>
				</filter>
			</defs>
			<polygon
				class="ciq-hu-bg" style="stroke-width: 1;"
				points="198.4,124.4 1,124.4 1,1 214,1 214,137.8"
				filter="url(#ciq-hu-shadow)"
				/>
			<path class="ciq-hu-stroke"
				fill="#398DFF"
				d="M213,2v133.6l-13.7-11.8l-0.6-0.5H198H2V2H213 M215,0H0v125.4h198l17,14.6V0L215,0z">
			</path>
		</svg>
		<div>
			<cq-hu-col1>
				<cq-hu-date></cq-hu-date>
				<cq-hu-price></cq-hu-price>
				<cq-volume-grouping>
					<div>Volume</div>
					<div><cq-volume-visual></cq-volume-visual></div>
					<div><cq-hu-volume></cq-hu-volume><cq-volume-rollup></cq-volume-rollup></div>
				</cq-volume-grouping>
			</cq-hu-col1>
			<cq-hu-col2>
				<div>Open</div><cq-hu-open></cq-hu-open>
				<div>Close</div><cq-hu-close></cq-hu-close>
				<div>High</div><cq-hu-high></cq-hu-high>
				<div>Low</div><cq-hu-low></cq-hu-low>
			</cq-hu-col2>
		</div>
	`;
CIQ.UI.addComponentDefinition("cq-hu-dynamic", HeadsUpDynamic);
