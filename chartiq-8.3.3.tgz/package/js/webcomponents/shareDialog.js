/**
 *	8.3.0
 *	Generation date: 2021-11-02T13:40:51.589Z
 *	Client name: sundial capital research
 *	Package Type: Technical Analysis
 *	License type: annual
 *	Expiration date: "2022/10/01"
 *	Domain lock: ["127.0.0.1","localhost","sentimentrader.com","18.117.142.18","bt20.sentimentrader.com"]
 *	iFrame lock: true
 */

/***********************************************************
 * Copyright by ChartIQ, Inc.
 * Licensed under the ChartIQ, Inc. Developer License Agreement https://www.chartiq.com/developer-license-agreement
*************************************************************/
/*************************************** DO NOT MAKE CHANGES TO THIS LIBRARY FILE!! **************************************/
/* If you wish to overwrite default functionality, create a separate file with a copy of the methods you are overwriting */
/* and load that file right after the library has been loaded, but before the chart engine is instantiated.              */
/* Directly modifying library files will prevent upgrades and the ability for ChartIQ to support your solution.          */
/*************************************************************************************************************************/
/* eslint-disable no-extra-parens */


import { CIQ as _CIQ } from "../../js/componentUI.js";
import "../../js/standard/share.js";
import "../../js/webcomponents/dialog.js";
import "../../js/webcomponents/close.js";


/* global _CIQ, _timezoneJS, _SplinePlotter */




var CIQ = typeof _CIQ !== "undefined" ? _CIQ : _exports.CIQ;

if (!CIQ.Share) {
	console.error(
		"shareDialog component requires first activating share feature."
	);
} else {
	/**
	 * Share dialog web component `<cq-share-dialog>`.
	 *
	 * @namespace WebComponents.cq-share-dialog
	 *
	 * @example
	 * <cq-dialog>
	 *     <cq-share-dialog>
	 *         <h4 class="title">Share Your Chart</h4>
	 *         <cq-close></cq-close>
	 *         <div cq-share-dialog-div>
	 *             <cq-separator></cq-separator>
	 *             <cq-share-create class="ciq-btn" stxtap="share()">Create Image</cq-share-create>
	 *             <cq-share-generating>Generating Image</cq-share-generating>
	 *             <cq-share-uploading>Uploading Image</cq-share-uploading>
	 *             <div class="share-link-div"></div>
	 *             <cq-share-copy class="ciq-btn" stxtap="copy()">Copy Link to Clipboard</cq-share-copy>
	 *             <cq-share-copied>Link Copied!</cq-share-copied>
	 *         </div>
	 *     </cq-share-dialog>
	 * </cq-dialog>
	 */
	class ShareDialog extends CIQ.UI.DialogContentTag {
		open(params) {
			this.addDefaultMarkup();
			this.setState("share-create");
			super.open(params);
		}

		close() {
			this.setState("share-create");
			super.close();
		}

		setState(state) {
			this.addDefaultMarkup();
			this.node.find("div[cq-share-dialog-div]")[0].className = state;
		}

		/**
		 * Shares a chart with default parameters.
		 *
		 * @alias share
		 * @memberof WebComponents.cq-share-dialog
		 */
		share() {
			var stx = this.context.stx;
			var self = this;
			self.setState("share-generate");
			var shareDialog = document.querySelector(
				"cq-share-dialog .share-link-div"
			);
			if (shareDialog) shareDialog.innerHTML = "";
			// "hide" is a selector list, of DOM elements to be hidden while an image of the chart is created.  "cq-comparison-add-label" and ".chartSize" are hidden by default.
			CIQ.UI.bypassBindings = true;
			CIQ.Share.createImage(
				stx,
				{
					hide: [
						".stx_chart_controls",
						".stx-btn-panel",
						".stx_jump_today",
						".stx-baseline-handle",
						".ciq-edit",
						".ciq-close",
						"cq-marker-label"
					]
				},
				function (data) {
					CIQ.UI.bypassBindings = false;
					var id = CIQ.uniqueID();
					var host = "https://share.chartiq.com";
					var startOffset = stx.getStartDateOffset();
					var metaData = {
						layout: stx.exportLayout(),
						drawings: stx.exportDrawings(),
						xOffset: startOffset,
						startDate: stx.chart.dataSegment[startOffset].Date,
						endDate:
							stx.chart.dataSegment[stx.chart.dataSegment.length - 1].Date,
						id: id,
						symbol: stx.chart.symbol
					};
					var url = host + "/upload/" + id;
					var payload = { id: id, image: data, config: metaData };
					self.setState("share-upload");
					CIQ.Share.uploadImage(data, url, payload, function (err, response) {
						self.setState("share-copy");
						if (err !== null) {
							CIQ.alert("error: " + err);
						} else {
							if (shareDialog) shareDialog.innerHTML = host + response;
						}
					});
				}
			);
		}

		copy() {
			var shareDialog = document.querySelector(
				"cq-share-dialog .share-link-div"
			);
			if (!shareDialog) return;
			var linkToCopy = shareDialog.innerText;
			var tempInputElem = document.createElement("input");
			tempInputElem.type = "text";
			tempInputElem.value = linkToCopy;
			tempInputElem.contentEditable = true;
			tempInputElem.readOnly = true;
			document.body.appendChild(tempInputElem);
			tempInputElem.focus();
			tempInputElem.select();
			if (!CIQ.isIE) {
				var range = document.createRange();
				range.selectNodeContents(tempInputElem);
				var s = window.getSelection();
				s.removeAllRanges();
				s.addRange(range);
				tempInputElem.setSelectionRange(0, linkToCopy.length);
			}
			document.execCommand("copy");
			document.body.removeChild(tempInputElem);
			this.setState("share-copied");
		}
	}

	ShareDialog.markup = `
		<h4 class="title">Share Your Chart</h4>
		<cq-close></cq-close>
		<div cq-share-dialog-div>
			<cq-separator></cq-separator>
			<cq-share-create class="ciq-btn" stxtap="share()">Create Image</cq-share-create>
			<cq-share-generating>Generating Image</cq-share-generating>
			<cq-share-uploading>Uploading Image</cq-share-uploading>
			<div class="share-link-div"></div>
			<cq-share-copy class="ciq-btn" stxtap="copy()">Copy Link to Clipboard</cq-share-copy>
			<cq-share-copied>Link Copied!</cq-share-copied>
	`;
	CIQ.UI.addComponentDefinition("cq-share-dialog", ShareDialog);
}
