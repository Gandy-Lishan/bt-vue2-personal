/**
 *	8.3.0
 *	Generation date: 2021-11-02T13:40:51.589Z
 *	Client name: sundial capital research
 *	Package Type: Technical Analysis
 *	License type: annual
 *	Expiration date: "2022/10/01"
 *	Domain lock: ["127.0.0.1","localhost","sentimentrader.com","18.117.142.18","bt20.sentimentrader.com"]
 *	iFrame lock: true
 */

/***********************************************************
 * Copyright by ChartIQ, Inc.
 * Licensed under the ChartIQ, Inc. Developer License Agreement https://www.chartiq.com/developer-license-agreement
*************************************************************/
/*************************************** DO NOT MAKE CHANGES TO THIS LIBRARY FILE!! **************************************/
/* If you wish to overwrite default functionality, create a separate file with a copy of the methods you are overwriting */
/* and load that file right after the library has been loaded, but before the chart engine is instantiated.              */
/* Directly modifying library files will prevent upgrades and the ability for ChartIQ to support your solution.          */
/*************************************************************************************************************************/
/* eslint-disable no-extra-parens */


import { CIQ as _CIQ } from "../../js/componentUI.js";
import "../../js/webcomponents/menu.js";


/* global _CIQ, _timezoneJS, _SplinePlotter */


var CIQ = typeof _CIQ !== "undefined" ? _CIQ : _exports.CIQ;

/**
 * Dialog web component `<cq-dialog>`.
 *
 * Manages general dialog interaction such as display, hide, location, size, tap interaction, etc
 *
 * @namespace WebComponents.cq-dialog
 * @example
	<cq-dialog cq-timezone-dialog>
		<cq-timezone-dialog>
			<h4 class="title">Choose Timezone</h4>
			<cq-close></cq-close>
	
			<p>To set your timezone use the location button below, or scroll through the following list...</p>
			<p class="currentUserTimeZone"></p>
	    <div class="detect">
	    <div class="ciq-btn" stxtap="Layout.removeTimezone()">Use My Current Location</div>
	    </div>
	    <div class="timezoneDialogWrapper" style="max-height:360px; overflow: auto;">
		        <ul>
		          <li class="timezoneTemplate" style="display:none;cursor:pointer;"></li>
		        </ul>
	        </div>
	    <div class="instruct">(Scroll for more options)</div>
		</cq-timezone-dialog>
	</cq-dialog>
 */
class Dialog extends CIQ.UI.BaseComponent {
	constructor() {
		super();
		this.activeAttributes = {};
	}

	/**
	 * The attributes that are added to a cq-dialog when it is opened (and removed when closed).
	 * Contains "cq-active" by default.
	 * @memberof WebComponents.cq-dialog
	 * @type {Object}
	 */
	connectedCallback() {
		if (this.attached) return;
		this.isDialog = true;
		super.connectedCallback();
		var self = this;
		function handleTap(e) {
			self.tap(e);
		}
		CIQ.UI.stxtap(this, handleTap);

		var uiManager = CIQ.UI.getUIManager();
		uiManager.registerForResize(this);
		this.uiManager = uiManager;
	}

	disconnectedCallback() {
		this.uiManager.unregisterForResize(this);
		super.disconnectedCallback();
	}

	/**
	 * Creates a new attribute to be activated when the dialog is open. Use
	 * this to style the dialog. This is automatically set by any component
	 * that is derived from DialogContentTag
	 * @param {string} attribute The attribute to add or remove
	 * @memberof WebComponents.cq-dialog
	 * @since  4.1.0
	 * @example
	 * <style> cq-dialog[cq-study-context]{ padding:0; } </style>
	 * <cq-dialog cq-study-context></cq-dialog>
	 */
	addActiveAttribute(attribute) {
		this.activeAttributes[attribute] = true;
	}

	center() {
		var parent = this.parentElement;
		if (parent.tagName == "BODY") parent = window;
		var gSz = CIQ.guaranteedSize(parent);
		var h = gSz.height;
		var outer = CIQ.elementDimensions(this, {
			padding: 1,
			border: 1
		});
		var ch = outer.height;
		var left = 50;
		var top = 50;
		if (h > ch * 2) {
			top = 33; // Position 1/3 down the screen on large screens
		}

		var elementStyle = {
			top: top + "%",
			left: left + "%",
			transform: "translate(-50%, -50%)"
		};
		Object.assign(this.style, elementStyle);
	}

	close() {
		this.uiManager.closeMenu(this);
		if (this.onClose) this.onClose();
	}

	hide() {
		if (this.node.find(":invalid").length) return;
		// Call the "hide()" function for any immediate children. This will allow nested
		// components to clean themselves up when a dialog is removed from outside of their scope.
		this.node.children().each(function () {
			if (typeof this.hide == "function") this.hide();
		});
		this.active = false;
		if (
			this.uiManager.overlay &&
			this.uiManager.overlay.hasAttribute("cq-active")
		)
			this.uiManager.overlay.removeAttribute("cq-active");
		//this.uiManager.overlay=null;
		for (var attribute in this.activeAttributes) {
			if (this.hasAttribute(attribute)) this.removeAttribute(attribute);
		}
		this.activeAttributes = {};

		// blur any input boxes that are inside the dialog we're closing, to get rid of soft keyboard
		this.node.find("input").each(function () {
			if (this == document.activeElement) this.blur();
		});
	}

	open(params) {
		this.uiManager.openMenu(this, params);
		if (CIQ.I18N && CIQ.I18N.localized)
			CIQ.I18N.translateUI(null, this.node[0]);

		// Capture context to be able to later notify dialog closing in channel
		const { context } = params || {};
		if (!context || !context.config) {
			this.onClose = null;
			return;
		}

		const {
			config: { channels },
			stx
		} = context;
		this.onClose = () => {
			this.channelWrite(channels.dialog || "channel.dialog", {}, stx);
			this.onClose = null;
		};
	}

	resize() {
		var scrollers = this.node.find("cq-scroll");
		scrollers.each(function () {
			if (this.resize) this.resize();
		});
		if (this.params && this.params.x) {
			this.stxContextMenu();
		} else {
			this.center();
		}
	}

	/**
	 * Show the dialog. Use X,Y *screen location* (pageX, pageY from an event) for where to display context menus. If the context menu cannot fit on the screen then it will be adjusted leftward and upward
	 * by enough pixels so that it shows.
	 * @param {object} [params] Parameters
	 * @param  {Boolean} [params.bypassOverlay=false] If true will not display the scrim overlay
	 * @param {Number} [params.x] X location of top left corner. Use for context menus, otherwise dialog will be centered.
	 * @param {Number} [params.y] Y location of top left corner. Use for context menus, otherwise dialog will be centered.
	 * @alias show
	 * @memberof WebComponents.cq-dialog
	 */
	show(params) {
		this.params = params;
		if (!params) params = this.params = {};
		var self = this;
		var context = params.context || CIQ.UI.getMyContext(this);
		if (!this.uiManager.overlay && !params.bypassOverlay) {
			this.uiManager.overlay = document.createElement("cq-dialog-overlay");
			if (context) context.node.append(this.uiManager.overlay);
		}
		self.active = true;
		setTimeout(function () {
			// to get the opacity transition effect
			if (self.uiManager.overlay && !params.bypassOverlay) {
				if (self.uiManager.overlay.getAttribute("cq-active") !== "true")
					self.uiManager.overlay.setAttribute("cq-active", "true");
			}
			self.activeAttributes["cq-active"] = true; // cq-active is what css uses to display the dialog
			for (var attribute in self.activeAttributes) {
				if (self.node.attr(attribute) !== "true")
					self.node.attr(attribute, "true");
			}
			self.resize();
		});

		// Add the theme class to the dialog. It exists outside of the theme context so it will not inherit the theme.
		if (context && context.config && context.config.themes) {
			let themes = Object.keys(context.config.themes.builtInThemes);
			// First remove any existing theme classes on the dialog
			this.classList.remove(...themes);
			let activeTheme = themes.find(
				(r) => context.topNode.classList.contains(r) === true
			);
			// Add the active theme class to the dialog
			if (activeTheme) this.classList.add(activeTheme);
		}
	}

	stxContextMenu() {
		var parent = this.parentElement;
		if (parent.tagName == "BODY") parent = window;
		var gSz = CIQ.guaranteedSize(parent);
		var w = gSz.width;
		var h = gSz.height;
		var outer = CIQ.elementDimensions(this, {
			padding: 1,
			border: 1
		});
		var cw = outer.width;
		var ch = outer.height;
		var left = this.params.x;
		var top = this.params.y;
		var saveAdjustedPosition = false;

		this.node.find("cq-menu.stxMenuActive").each(function () {
			if (this.querySelector(".context-menu-right")) {
				var overlapItemCount = CIQ.UI.$(this).nextAll().length + 1;

				var outerMenu = CIQ.elementDimensions(this, {
					padding: 1,
					border: 1
				});
				var outerContext = CIQ.elementDimensions(
					this.querySelector(".context-menu-right"),
					{ padding: 1, border: 1 }
				);
				cw += outer.width;
				ch += outerContext.height - outerMenu.height * overlapItemCount;
				saveAdjustedPosition = true;
			}
		});

		if (left + cw > w) left = w - cw;
		if (top + ch > h) top = h - ch;
		if (top < 0) top = 0;
		if (saveAdjustedPosition) {
			this.params.x = left;
			this.params.y = top;
		}

		Object.assign(this.style, { top: top + "px", left: left + "px" });
	}

	tap(e) {
		var topMenu = this.uiManager.topMenu();
		if (topMenu === this) {
			e.stopPropagation(); // prevent a tap inside the dialog from closing itself
			return;
		}
		if (!e.currentTarget.active) {
			e.stopPropagation(); // If the dialog we tapped on is closed, then we must have closed it manually. Don't allow a body tap otherwise we'll close two dialogs!
		}
	}
}

CIQ.UI.addComponentDefinition("cq-dialog", Dialog);
