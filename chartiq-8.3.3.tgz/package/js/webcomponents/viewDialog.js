/**
 *	8.3.0
 *	Generation date: 2021-11-02T13:40:51.589Z
 *	Client name: sundial capital research
 *	Package Type: Technical Analysis
 *	License type: annual
 *	Expiration date: "2022/10/01"
 *	Domain lock: ["127.0.0.1","localhost","sentimentrader.com","18.117.142.18","bt20.sentimentrader.com"]
 *	iFrame lock: true
 */

/***********************************************************
 * Copyright by ChartIQ, Inc.
 * Licensed under the ChartIQ, Inc. Developer License Agreement https://www.chartiq.com/developer-license-agreement
*************************************************************/
/*************************************** DO NOT MAKE CHANGES TO THIS LIBRARY FILE!! **************************************/
/* If you wish to overwrite default functionality, create a separate file with a copy of the methods you are overwriting */
/* and load that file right after the library has been loaded, but before the chart engine is instantiated.              */
/* Directly modifying library files will prevent upgrades and the ability for ChartIQ to support your solution.          */
/*************************************************************************************************************************/
/* eslint-disable no-extra-parens */


import { CIQ as _CIQ } from "../../js/componentUI.js";
import "../../js/webcomponents/dialog.js";


/* global _CIQ, _timezoneJS, _SplinePlotter */


var CIQ = typeof _CIQ !== "undefined" ? _CIQ : _exports.CIQ;

/**
 * View Dialog web component `<cq-view-dialog>`.
 *
 * See {@link WebComponents.cq-views} for more details on menu management for this component.
 *
 * @namespace WebComponents.cq-view-dialog
 *
 * @example
 * <cq-dialog>
 *     <cq-view-dialog>
 *         <h4>Save View</h4>
 *         <div stxtap="close()" class="ciq-icon ciq-close"></div>
 *         <div style="text-align:center;margin-top:10px;">
 *             <i>Enter name of view:</i>
 *             <p>
 *                 <input spellcheck="false" autocomplete="off" autocorrect="off" autocapitalize="none" maxlength="40" placeholder="Name"><br>
 *             </p>
 *             <span class="ciq-btn" stxtap="save()">Save</span>
 *         </div>
 *     </cq-view-dialog>
 * </cq-dialog>
 */
class ViewDialog extends CIQ.UI.DialogContentTag {
	open(params) {
		this.addDefaultMarkup();
		this.querySelector("input").value = "";
		super.open(params);
	}

	/**
	 * Saves the new view. This updates all cq-view menus on the screen, and persists the view in the nameValueStore.
	 * @alias save
	 * @memberof WebComponents.cq-view-dialog
	 */
	save() {
		var viewName = this.node.find("input").val();
		if (!viewName) return;

		var self = this;
		var madeChange = false;
		var layout = this.context.stx.exportLayout();
		document.querySelectorAll("cq-views").forEach(function (v) {
			var obj = v.params.viewObj;
			var view;

			for (var i = 0; i < obj.views.length; i++) {
				view = obj.views[i];
				if (viewName == CIQ.first(view)) break;
			}
			if (i == obj.views.length) {
				view = {};
				view[viewName] = {};
				obj.views.push(view);
			}
			view[viewName] = layout;
			delete view[viewName].candleWidth;
			v.renderMenu();
			//this.context.stx.updateListeners("layout");
			if (!madeChange) {
				// We might have a cq-view menu on multiple charts on the screen. Only persist once.
				madeChange = true;
				if (v.params.nameValueStore)
					v.params.nameValueStore.set("stx-views", obj.views);
			}
		});
		this.close();
	}
}

ViewDialog.markup = `
		<h4>Save View</h4>
		<div stxtap="close()" class="ciq-icon ciq-close"></div>
		<div style="text-align:center;margin-top:10px;">
		<i>Enter name of view:</i>
		<p>
			<input spellcheck="false" autocomplete="off" autocorrect="off" autocapitalize="none" maxlength="40" placeholder="Name"><br>
		</p>
		<span class="ciq-btn" stxtap="save()">Save</span>
		</div>
	`;
CIQ.UI.addComponentDefinition("cq-view-dialog", ViewDialog);
