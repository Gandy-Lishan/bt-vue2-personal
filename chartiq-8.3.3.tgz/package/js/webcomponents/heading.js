/**
 *	8.3.0
 *	Generation date: 2021-11-02T13:40:51.589Z
 *	Client name: sundial capital research
 *	Package Type: Technical Analysis
 *	License type: annual
 *	Expiration date: "2022/10/01"
 *	Domain lock: ["127.0.0.1","localhost","sentimentrader.com","18.117.142.18","bt20.sentimentrader.com"]
 *	iFrame lock: true
 */

/***********************************************************
 * Copyright by ChartIQ, Inc.
 * Licensed under the ChartIQ, Inc. Developer License Agreement https://www.chartiq.com/developer-license-agreement
*************************************************************/
/*************************************** DO NOT MAKE CHANGES TO THIS LIBRARY FILE!! **************************************/
/* If you wish to overwrite default functionality, create a separate file with a copy of the methods you are overwriting */
/* and load that file right after the library has been loaded, but before the chart engine is instantiated.              */
/* Directly modifying library files will prevent upgrades and the ability for ChartIQ to support your solution.          */
/*************************************************************************************************************************/
/* eslint-disable no-extra-parens */


import { CIQ as _CIQ } from "../../js/componentUI.js";


/* global _CIQ, _timezoneJS, _SplinePlotter */

var CIQ = typeof _CIQ !== "undefined" ? _CIQ : _exports.CIQ;

/**
 * Menu web component `<cq-heading>`.
 *
 * Attribute cq-filter adds input for filtering cq-items in
 * cq-heading sibling container based on entered input.
 * Filter is matching input pattern anywhere in cq-item text.
 *
 * Attribute value passed in cq-filter is used for input placeholder.
 * Default placeholder is set to "Search"
 *
 * Attribute cq-filter-min can be used to override the default minimum
 * number of records for filter to show.  The default is 15.
 *
 * @namespace WebComponents.cq-menu-item-filter
 * @example
 * <!-- default "Search" input placeholder -->
 * <cq-heading cq-filter>Studies</cq-heading>
 *
 * <!-- "Filter" placeholder -->
 * <cq-heading cq-filter="Filter">Studies</cq-heading>
 *
 * <!-- No visible placeholder, minimum length for filter set to 20 -->
 * <cq-heading cq-filter=" " cq-filter-min=20>Studies</cq-heading>
 */
class Heading extends CIQ.UI.ContextTag {
	setContext() {
		if (!this.hasAttribute("cq-filter")) return;

		const filter = this.getAttribute("cq-filter") || "Search";
		this.createFilter(filter);
	}

	createFilter(placeholder) {
		const searchWrapper = document.createElement("div");
		searchWrapper.classList.add("searchFilter");
		this.appendChild(searchWrapper);
		const input = document.createElement("input");
		input.type = "search";
		input.placeholder = placeholder;
		searchWrapper.appendChild(input);
		this.searchWrapper = searchWrapper;

		const itemContainer = this.nextElementSibling;

		const updateListVisibility = ({ target: { value } }) => {
			const re = new RegExp(value, "i");

			this.qsa("cq-item", itemContainer).forEach((el) => {
				const visibilityAction =
					value && !re.test(el.textContent) ? "add" : "remove";
				el.classList[visibilityAction]("item-hidden");
			});
		};
		input.addEventListener("input", updateListVisibility);
		input.addEventListener("keyup", updateListVisibility);

		const minItemCount = this.getAttribute("cq-filter-min") || 15;

		const showFilterIfNecessary = () => {
			const itemCount = this.qsa("cq-item", itemContainer).length;
			searchWrapper.classList[itemCount > minItemCount ? "add" : "remove"](
				"active"
			);
		};

		// Delay the execution of the filter activation check until sibling child nodes
		// have been created providing reference to the need for filter
		// based on cq-filter-min setting
		if (typeof MutationObserver === undefined) {
			searchWrapper.classList.add("active");
			return;
		}
		new MutationObserver(showFilterIfNecessary).observe(this.parentElement, {
			childList: true,
			subtree: true
		});

		showFilterIfNecessary();
	}
}
CIQ.UI.addComponentDefinition("cq-heading", Heading);
