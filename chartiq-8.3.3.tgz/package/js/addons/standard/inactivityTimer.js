/**
 *	8.3.0
 *	Generation date: 2021-11-02T13:40:51.589Z
 *	Client name: sundial capital research
 *	Package Type: Technical Analysis
 *	License type: annual
 *	Expiration date: "2022/10/01"
 *	Domain lock: ["127.0.0.1","localhost","sentimentrader.com","18.117.142.18","bt20.sentimentrader.com"]
 *	iFrame lock: true
 */

/***********************************************************
 * Copyright by ChartIQ, Inc.
 * Licensed under the ChartIQ, Inc. Developer License Agreement https://www.chartiq.com/developer-license-agreement
*************************************************************/
/*************************************** DO NOT MAKE CHANGES TO THIS LIBRARY FILE!! **************************************/
/* If you wish to overwrite default functionality, create a separate file with a copy of the methods you are overwriting */
/* and load that file right after the library has been loaded, but before the chart engine is instantiated.              */
/* Directly modifying library files will prevent upgrades and the ability for ChartIQ to support your solution.          */
/*************************************************************************************************************************/
/* eslint-disable no-extra-parens */


import { CIQ as _CIQ } from "../../../js/chartiq.js";


/* global _CIQ, _timezoneJS, _SplinePlotter */

var CIQ = typeof _CIQ !== "undefined" ? _CIQ : _exports.CIQ;

/**
 * Add-On that puts the chart into "sleep mode" after a period of inactivity.
 *
 * Requires *addOns.js*.
 *
 * In sleep mode, a class "ciq-sleeping" will be added to the body.  This will dim out the chart.
 * Sleep mode is ended when interaction with the chart is detected.
 *
 * @param {object} params Configuration parameters
 * @param {CIQ.ChartEngine} [params.stx] The chart object
 * @param {number} [params.minutes] Inactivity period in _minutes_.  Set to 0 to disable the sleep mode.
 * @param {number} [params.interval] Sleeping quote update interval in _seconds_.  During sleep mode, this is used for the update loop.
 * 									Set to non-zero positive number or defaults to 60.
 * @param {function} [params.wakeCB] Optional callback function after waking
 * @param {function} [params.sleepCB] Optional callback function after sleeping
 * @constructor
 * @name  CIQ.InactivityTimer
 * @since 3.0.0
 * @example
 * 	new CIQ.InactivityTimer({stx:stxx, minutes:30, interval:15});  //30 minutes of inactivity will put chart into sleep mode, updating every 15 seconds
 *
 */
CIQ.InactivityTimer =
	CIQ.InactivityTimer ||
	function (params) {
		if (!params.minutes) return;
		if (!params.interval || params.interval < 0) params.interval = 60;
		this.stx = params.stx;
		this.timeout = params.minutes;
		this.interval = params.interval;
		this.wakeCB = params.wakeCB;
		this.sleepCB = params.sleepCB;
		this.sleepTimer = null;
		this.sleeping = false;
		this.last = new Date().getTime();
		this.wakeChart = function () {
			clearTimeout(this.sleepTimer);
			this.last = new Date().getTime();
			if (this.sleeping) {
				if (this.stx.quoteDriver) this.stx.quoteDriver.updateChartLoop();
				this.sleeping = false;
				document.body.classList.remove("ciq-sleeping");
			}
			this.sleepTimer = setTimeout(
				this.sleepChart.bind(this),
				this.timeout * 60000
			);
			if (this.wakeCB) this.wakeCB();
		};
		this.sleepChart = function () {
			if (!this.sleeping) {
				if (this.stx.quoteDriver)
					this.stx.quoteDriver.updateChartLoop(this.interval);
				this.sleeping = true;
				document.body.classList.add("ciq-sleeping");
			}
			if (this.sleepCB) this.sleepCB();
		};

		var self = this;
		[
			"mousemove",
			"mousedown",
			"touchstart",
			"touchmove",
			"pointerdown",
			"pointermove",
			"keydown",
			"wheel"
		].forEach(function (ev) {
			document.body.addEventListener(
				ev,
				function (e) {
					self.wakeChart();
				},
				{ passive: false }
			);
		});
		this.wakeChart();
	};
