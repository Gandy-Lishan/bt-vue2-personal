//
// Sample trade analytics with markers
// This file contains functions which create a sample implementation of post trade analysis using markers.  This file is meant to be used in conjuction with the markersSample.js file by extending the functionality of MarkersSample. There is a stylesheet which goes along with it as well.
// Usage: new MarkersSample(stxx);
//
import { CIQ, markers } from "../../js/standard.js";
import marker from "../../examples/markers/markersSample.js";
var _css;
if (
	typeof define === "undefined" &&
	typeof module === "object" &&
	typeof require === "function"
)
	_css = require("../../examples/markers/tradeAnalyticsSample.css");
else if (typeof define === "function" && define.amd)
	define(["../../examples/markers/tradeAnalyticsSample.css"], function (m) {
		_css = m;
	});
else if (typeof window !== "undefined")
	CIQ.loadStylesheet("examples/markers/tradeAnalyticsSample.css");
if (_css) CIQ.addInternalStylesheet(_css, "tradeAnalyticsSample.css");
CIQ.activateImports(markers);
const MarkersSample = marker.MarkersSample;
MarkersSample.registerType("mMarker", "showmMarker");
MarkersSample.prototype.showmMarker = function () {
	if (!CIQ.Marker.Performance) {
		return console.error(
			"tradeAnalyticsSample feature requires first activating highPerformanceMarkers feature."
		);
	}
	var markerTypes = ["analysis","dividend", "news", "earnings"];
	let { stx } = this;
    let mDataSet = [
            {
                DT:"2016-06-05",
                Type: "BUY",
                Price: 22.25
            },
            {
                DT:"2016-08-08",
                Type: "SELL",
                Price: 22.70
            } ,
            {
                DT:"2016-09-05",
                Type: "BUY",
                Price: 21.90
            },
            {
                DT:"2016-10-02",
                Type: "SELL",
                Price: 25.59
            } 
    ]
    
    
	for (var data in mDataSet) {
			var color = mDataSet[data].Type === 'BUY' ? 0 : 1
			new CIQ.Marker({
				stx: stx,
				label: "circle",
				xPositioner: "date",
				x: new Date(mDataSet[data].DT),
				node: new CIQ.Marker.Simple({
					type: "circle",
					headline: mDataSet[data].Type,
					category: markerTypes[color],
					story:
						'Price: ' +
						mDataSet[data].Price + '\nDate: ' + new Date(mDataSet[data].DT)
				})
			});
	}
	return ["circle", "trade"];
};

export default marker;
