const prodPlugins = process.env.NODE_ENV === 'production' ? ['transform-remove-console'] : []
module.exports = {
  presets: ['@vue/cli-plugin-babel/preset'],
  plugins: [
    [
      "component",
      {
          "libraryName": "element-ui",
          "styleLibraryName": "theme-chalk"
      }
  ],
    ...prodPlugins
  ]
}
