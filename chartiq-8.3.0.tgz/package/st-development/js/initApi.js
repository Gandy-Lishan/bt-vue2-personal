import { CIQ } from "./entryIndicator.js";
import {config} from "../feeds/STDataFeedAccessUrl.js"
import quotefeed from "../feeds/STStockDataFeed.js"
import marker from "../components/markers/markersSample.js";

const conf = getDefaultConfig({
	markerSample: marker.MarkersSample,
	quoteFeed: quotefeed,
	nameValueStore: CIQ.NameValueStore
});
CIQ.initAPI = function(){
    console.log('CIQ.initAPI')
    let stxx = conf.createChart();
    CIQ.stxx = stxx;
}

CIQ.outputSignalsResultSimple = async function(symbol,indicatorsList){
    console.log('before CIQ.simpleCSV: ')
    await getIndicatorMatedataSimple(indicatorsList)

    CIQ.stxx.loadChart(	{ symbol: symbol,startDate:new Date(parseInt(process.env.VUE_APP_START_DATE)),endDate:new Date(), indicator:indicatorsList}, async function () {
        console.log("loadChart加载完毕");
        CIQ.stxx.resizeChart();
        CIQ.stxx.draw();
        var csvContent = exportExSimple(indicatorsList,[])
        console.log("csvContent created Success",csvContent);
    })     
}
async function getIndicatorMatedataSimple(indicatorList){
    var color = ["#2f7ed8","#7257f2","#19BD5F","#BDED22","#BF5E67","#ec1cff"]
    for (var studyInstanceName in CIQ.stxx.layout.studies) {
        var sd = CIQ.stxx.layout.studies[studyInstanceName]; 
        //if (CIQ.studys.indexOf(sd.type) === -1){
            CIQ.Studies.removeStudy(CIQ.stxx, sd); 
       // }
    }

    let resArr = []
    //为了让url和resArr内容同步
    let sentiUrlList = []

    // 用sentiLIST过滤tech
    let sentiList = []
    CIQ.indicatorList.forEach(e => {
        sentiList.push(e.url)
    })
    for(var i in indicatorList){
        if(sentiList){
            if(sentiList.indexOf(indicatorList[i]) == -1){                                                           
                    var study = CIQ.Studies.studyLibrary[indicatorList[i]]
                    study.panelHeight=100
                    CIQ.Studies.studyLibrary[indicatorList[i]] = study
                    var sd = CIQ.Studies.addStudy(CIQ.stxx, indicatorList[i],{display:indicatorList[i]});  
                continue
            }
        }
        var queryUrl =  config.indicatorMetadata + 
        "?indicator=" + indicatorList[i];

        let _res = new Promise((resolve,reject)=>{
            CIQ.axios.get(
                queryUrl,
            ).then(res=>{
                resolve(res.data)
            }).catch(err=>{
                reject(err)
            })
        })
        resArr.push(_res)
        sentiUrlList.push(indicatorList[i])
    }
    Promise.all(resArr).then(res => {
        var newQuotes = res;
        //console.log("resArr newQuotes: ",newQuotes)    
        for(var i in newQuotes){
            if (newQuotes[i] !== null){
                var newStudy = {
                    inputs: { Period: 13, Overlay: false},
                    outputs: 
                    {indicatorClose:color[i%6],description: newQuotes[i].description,url:sentiUrlList[i]},
                    panelHeight:100,
                    parameters: { init: {
                        studyOverZonesEnabled: newQuotes[i].opt_extreme?true:false,
                        studyOverBoughtValue: newQuotes[i].opt_extreme?newQuotes[i].opt_extreme:NaN,
                        studyOverBoughtColor: "#FF0000",
                        studyOverSoldValue: newQuotes[i].pess_extreme?newQuotes[i].pess_extreme:NaN,
                        studyOverSoldColor: "#00DD00",
                    }},
                    attributes:{
                        studyOverBoughtValue:{"step":0.01},
                        studyOverSoldValue:{"step":0.01}
                    }
                }
                
                    var str = JSON.stringify(newStudy);                                   
                    str = str.replace(/indicatorClose/g, indicatorList[i]);
                    newStudy = JSON.parse(str)                                     
                    
                    CIQ.Studies.studyLibrary[indicatorList[i]] = newStudy
                    var sd = CIQ.Studies.addStudy(CIQ.stxx,indicatorList[i])    
            }
        }                        
    }).catch(err => {
        
    })
}
function exportExSimple(entry,exit){  
    let finalData = []
    let study = CIQ.stxx.layout.studies[Object.keys(CIQ.stxx.layout.studies).pop()]
    if(study == undefined){ return }
    let JSONData = study.chart.scrubbed
    
    let timePeriod = CIQ.spanPeriod
    console.log("timePeriod",timePeriod)
    //先转化json
    let _arrData = typeof JSONData != 'object' ? JSON.parse(JSONData) : JSONData;
    // 根据time period筛选数据
    let arrData = []
    for(var i in _arrData){
        let item = _arrData[i]
        let dateNum = item.Date?item.Date:''
        if(timePeriod){
            if(dateNum<timePeriod.start_date || dateNum>timePeriod.end_date){continue}
        }
        arrData.push(_arrData[i])
    }
    // 给数组内容换好位置
    for(var i in arrData){
        let item = arrData[i]
        let dateNum = item.Date?item.Date:''
        let date = dateNum.slice(0,4)+ '-' + dateNum.slice(4,6)+ '-' + dateNum.slice(6,8)
        let obj = {
            Date: date,
            Open: item.Open,
            High: item.High,
            Low: item.Low,
            Close: item.Close ? item.Close : '',
            Volume: item.Volume,
            entry_1: '',
            entry_2: '',
            entry_3: '',
            entry_4: '',
            entry_5: '',
            exit_1: '',
            exit_2: '',
            exit_3: '',
            exit_4: '',
            exit_5: '',
            //Result: item[Object.keys(item)[8]],     
        };
      finalData.push(obj);
    }

    
    // find the correspond sd type
    entry.forEach((value,index)=>{
        var _index = ''
        var indexNum
        var sd = {}
        for(var i in CIQ.stxx.layout.studies){
            var _sd = CIQ.stxx.layout.studies[i]
            if(_sd.type == value){
                _index = 'entry_'+(index+1)
                indexNum = index
                sd = _sd
            }
        }
        finalData = generateFinalOutput(arrData,finalData,sd,_index,indexNum,'entry')
    })
    exit.forEach((value,index)=>{
        var _index = ''
        var indexNum
        var sd = {}
        for(var i in CIQ.stxx.layout.studies){
            var _sd = CIQ.stxx.layout.studies[i]
            if(_sd.type == value){
                _index = 'exit_'+(index+1)
                indexNum = index
                sd = _sd
            }
        }
        finalData = generateFinalOutput(arrData,finalData,sd,_index,indexNum,'exit')
    })
    
    // generate a csv copy of finalData 
    let csvArray = []
    let indexs = Object.keys(finalData[0])
    let newIndexs = indexs.map((val,index)=>{
        if(index>=6 && index<=10){
            if(CIQ.store.state.indicators.formIndicators.entry[index-6]){
                return CIQ.store.state.indicators.formIndicators.entry[index-6] + CIQ.labelOption[index-6]
            }else{
                return Object.keys(finalData[0])[index]
            }  
        }else if(index>10){
            if(CIQ.store.state.indicators.formIndicators.exit[index-11]){
                return CIQ.store.state.indicators.formIndicators.exit[index-11] + CIQ.labelOption[index-6]
            }else{
                return Object.keys(finalData[0])[index]
            }  
        }else{
            return Object.keys(finalData[0])[index]
        }
    })

    csvArray.push(newIndexs)

    //console.log('finalData: ',finalData,study.chart.scrubbed[5051])

    for (let i = 0; i < finalData.length; i++) {
    csvArray.push(Object.values(finalData[i]))
    }
    

    if(CIQ.downloadCSV){
        downloadCSV(csvArray)
    }
    let csvContent = csvArray.map(e => e.join(",")).join("\n");
    return csvContent 
};
function generateFinalOutput(arrData,finalData,sd,index,indexNum,criteria){
    let debug = arrData
    var resultIndex = ''
    var categoryList = CIQ.technicalCategory
    var conditionRadio = CIQ.store.state.conditionRadio[criteria][indexNum]
    // technical indicators
    //console.log(sd)
    for(var _class in categoryList){
        var studies = categoryList[_class].studies
        for(var _study in studies){
            if(sd.type == studies[_study].url){
                var category = categoryList[_class].class
                switch(category){
                    case("CCI_like"):{
                        // output only indicator value 
                        resultIndex = Object.keys(sd.outputMap)[0]
                        // load a value of this study to dataframe(important note: the value of correspond resultIndex is caculated differently)
                        for(var item in arrData){
                            finalData[item][index] = arrData[item][resultIndex] || arrData[item][resultIndex]==0
                            ?parseFloat(arrData[item][resultIndex].toFixed(2))
                            :null;
                        }
                        
                        CIQ.labelOption[criteria=='entry'?indexNum:indexNum+5] = ''
                        break
                    }
                    case("MACD_like"):{
                        //MACD ‌macd‌
                        //var conditionRadio = CIQ.store.state.conditionRadio[criteria][indexNum]
                        //console.log(conditionRadio)
                        for(var i in Object.keys(sd.outputMap)){
                            var keywordList = []
                            switch(conditionRadio){
                                case('Indicator Value'):{
                                    keywordList = ['MACD ‌macd‌','Klinger ‌Klinger‌','Rel Vig ‌Rel Vig‌']
                                    CIQ.labelOption[criteria=='entry'?indexNum:indexNum+5] = ''
                                    break
                                }
                                case('Indicator Value '):{
                                    keywordList = ['_hist']
                                    CIQ.labelOption[criteria=='entry'?indexNum:indexNum+5] = '_SL'
                                    break
                                }
                                case('Indicator Hist'):{
                                    keywordList = ['_hist']
                                    CIQ.labelOption[criteria=='entry'?indexNum:indexNum+5] = '_hist'
                                    break
                                }
                                default:
                            }
                            for(var k in keywordList){
                                if(Object.keys(sd.outputMap)[i].search(keywordList[k]) != -1){
                                    resultIndex = Object.keys(sd.outputMap)[i]
                                }
                            }
                            
                        }
                        // load a value of this study to dataframe(important note: the value of correspond resultIndex is caculated differently)
                        for(var item in arrData){
                            finalData[item][index] = arrData[item][resultIndex] || arrData[item][resultIndex]==0
                            ?parseFloat(arrData[item][resultIndex].toFixed(2))
                            :null;
                        }
                        break
                    }
                    case("BollingerBands_like"):{
                        // use Bottom Top Median in output map
                        //Use Indicator High/Medium/Low Band raw data whichever is chosen in the drop list. 
                        //var conditionRadio = CIQ.store.state.conditionRadio[criteria][indexNum]
                        //console.log(conditionRadio)
                        for(var i in Object.keys(sd.outputMap)){
                            var keywordList = []
                            switch(conditionRadio){
                                case('LB'):{
                                    keywordList = ['Bottom','Low']
                                    break
                                }
                                case('HB'):{
                                    keywordList = ['Top','High']
                                    break
                                }
                                case('MB'):{
                                    keywordList = ['Median']
                                    break
                                }
                                default:
                            }
                            CIQ.labelOption[criteria=='entry'?indexNum:indexNum+5] = '_'+conditionRadio
                            for(var k in keywordList){
                                if(Object.keys(sd.outputMap)[i].search(keywordList[k]) != -1){
                                    resultIndex = Object.keys(sd.outputMap)[i]
                                }
                            }
                            
                        }
                        // load a value of this study to dataframe(important note: the value of correspond resultIndex is caculated differently)
                        for(var item in arrData){
                            finalData[item][index] = arrData[item][resultIndex] || arrData[item][resultIndex]==0
                            ?parseFloat(arrData[item][resultIndex].toFixed(2))
                            :null;
                        }
                        
                        break
                    }
                    case("EFT_like"):{
                        var signalResultIndex = ''
                        //var conditionRadio = CIQ.store.state.conditionRadio[criteria][indexNum]
                        //console.log(conditionRadio)
                        for(var i in Object.keys(sd.outputMap)){
                            var keywordList = []
                            var signalKeywordList = []
                            switch(conditionRadio){
                                case('Indicator Value'):{
                                    keywordList = ['EF ‌Ehler Fisher‌','KST ‌Pring KST‌','PMO ‌PMO‌','TII ‌Trend Int‌']
                                    for(var k in keywordList){
                                        if(Object.keys(sd.outputMap)[i].search(keywordList[k]) != -1){
                                            resultIndex = Object.keys(sd.outputMap)[i]
                                        }
                                    }
                                    CIQ.labelOption[criteria=='entry'?indexNum:indexNum+5] = ''
                                    break
                                }
                                case('Indicator Value '):{
                                    keywordList = ['EF ‌Ehler Fisher‌','KST ‌Pring KST‌','PMO ‌PMO‌','TII ‌Trend Int‌']
                                    signalKeywordList = ['Trigger','Signal']
                                    for(var k in signalKeywordList){
                                        if(Object.keys(sd.outputMap)[i].search(signalKeywordList[k]) != -1){
                                            signalResultIndex = Object.keys(sd.outputMap)[i]
                                        }
                                    }
                                    for(var k in keywordList){
                                        if(Object.keys(sd.outputMap)[i].search(keywordList[k]) != -1){
                                            resultIndex = Object.keys(sd.outputMap)[i]
                                        }
                                    }
                                    CIQ.labelOption[criteria=='entry'?indexNum:indexNum+5] = '_SL'
                                    break
                                }
                                default:
                            }
                        }
                        // load a value of this study to dataframe(important note: the value of correspond resultIndex is caculated differently)

                        for(var item in arrData){
                            if(conditionRadio == 'Indicator Value'){
                                finalData[item][index] = arrData[item][resultIndex] || arrData[item][resultIndex]==0
                                ?parseFloat(arrData[item][resultIndex].toFixed(2))
                                :null;
                            }else{
                                if(arrData[item][resultIndex]&&arrData[item][signalResultIndex]){
                                    finalData[item][index] = parseFloat((arrData[item][resultIndex].toFixed(2)-arrData[item][signalResultIndex].toFixed(2))).toFixed(2)
                                }else{
                                    finalData[item][index] =  null
                                }
                            }
                        }
                        break
                    }
                    case("Stochastics_like"):{
                        var resultIndexK = ''
                        var resultIndexD = ''
                       // var conditionRadio = CIQ.store.state.conditionRadio[criteria][indexNum]
                        
                        for(var i in Object.keys(sd.outputMap)){
                            var signalKeywordList = []
                            switch(conditionRadio){
                                case('%K'):{
                                    
                                    if(Object.keys(sd.outputMap)[i].search(conditionRadio) != -1){
                                        resultIndexK = Object.keys(sd.outputMap)[i]
                                    }
                                    CIQ.labelOption[criteria=='entry'?indexNum:indexNum+5] = '_%K'
                                    break
                                }
                                case('%D'):{
                                    if(Object.keys(sd.outputMap)[i].search(conditionRadio) != -1){
                                        resultIndexD = Object.keys(sd.outputMap)[i]
                                    }
                                    CIQ.labelOption[criteria=='entry'?indexNum:indexNum+5] = '_%D'
                                    break
                                }
                                case('%K '):{
                                    console.log("%K ")
                                    if(Object.keys(sd.outputMap)[i].search('%K') != -1){
                                        resultIndexK = Object.keys(sd.outputMap)[i]
                                    }
                                    if(Object.keys(sd.outputMap)[i].search('%D') != -1){
                                        resultIndexD = Object.keys(sd.outputMap)[i]
                                    }
                                    CIQ.labelOption[criteria=='entry'?indexNum:indexNum+5] = '_%K-%D'
                                    break
                                }
                                default:
                            }
                        }
                        // load a value of this study to dataframe(important note: the value of correspond resultIndex is caculated differently)
                        for(var item in arrData){
                            if(conditionRadio == '%K'){
                                finalData[item][index] = arrData[item][resultIndexK] || arrData[item][resultIndexK]==0
                                ?parseFloat(arrData[item][resultIndexK].toFixed(2))
                                :null;
                            }else if(conditionRadio == '%D'){
                                finalData[item][index] = arrData[item][resultIndexD] || arrData[item][resultIndexD]==0
                                ?parseFloat(arrData[item][resultIndexD].toFixed(2))
                                :null;
                            }else if(conditionRadio == '%K '){
                                //console.log(arrData[item][resultIndexK],arrData[item][resultIndexD])
                                if(arrData[item][resultIndexK]&&arrData[item][resultIndexD]){
                                    finalData[item][index] = parseFloat((arrData[item][resultIndexK].toFixed(2)-arrData[item][resultIndexD].toFixed(2))).toFixed(2)
                                }else{
                                    finalData[item][index] =  null
                                }
                            }
                        }
                        break
                    }
                    case("ERI_like"):{
                        //var conditionRadio = CIQ.store.state.conditionRadio[criteria][indexNum]
                        //console.log(conditionRadio)
                        for(var i in Object.keys(sd.outputMap)){
                            switch(conditionRadio){
                                case('Indicator hist1'):{
                                    if(Object.keys(sd.outputMap)[i].search('_hist1') != -1){
                                        resultIndex = Object.keys(sd.outputMap)[i]
                                    }
                                    CIQ.labelOption[criteria=='entry'?indexNum:indexNum+5] = '_hist1'
                                    break
                                }
                                case('Indicator hist2'):{
                                    if(Object.keys(sd.outputMap)[i].search('_hist2') != -1){
                                        resultIndex = Object.keys(sd.outputMap)[i]
                                    }
                                   CIQ.labelOption[criteria=='entry'?indexNum:indexNum+5] = '_hist2'
                                    break
                                }
                                default:
                            }
                        }
                        // load a value of this study to dataframe(important note: the value of correspond resultIndex is caculated differently)
                        for(var item in arrData){
                            finalData[item][index] = arrData[item][resultIndex] || arrData[item][resultIndex]==0
                            ?parseFloat(arrData[item][resultIndex].toFixed(2))
                            :null;
                        }
                        break
                    }
                    case("ADX_like"):{
                        //var conditionRadio = CIQ.store.state.conditionRadio[criteria][indexNum]
                        console.log(conditionRadio)
                        for(var i in Object.keys(sd.outputMap)){
                            switch(conditionRadio){
                                case('+DI ADX'):{             
                                    if(sd.outputMap[Object.keys(sd.outputMap)[i]]=="+DI"){
                                        resultIndex = Object.keys(sd.outputMap)[i]
                                    }
                                    CIQ.labelOption[criteria=='entry'?indexNum:indexNum+5] = '_+DI'
                                    break
                                }
                                case('-DI ADX'):{
                                    if(sd.outputMap[Object.keys(sd.outputMap)[i]]=="-DI"){
                                        resultIndex = Object.keys(sd.outputMap)[i]
                                    }
                                   CIQ.labelOption[criteria=='entry'?indexNum:indexNum+5] = '_-DI'
                                    break
                                }
                                default:
                            }
                        }
                        // load a value of this study to dataframe(important note: the value of correspond resultIndex is caculated differently)
                        for(var item in arrData){
                            finalData[item][index] = arrData[item][resultIndex] || arrData[item][resultIndex]==0
                            ?parseFloat(arrData[item][resultIndex].toFixed(2))
                            :null;
                        }
                        break
                    }
                    case("MovingAverage_like"):{ 
                        // output only indicator value 
                        //console.log(conditionRadio)
                        resultIndex = Object.keys(sd.outputMap)[0]
                        // load a value of this study to dataframe(important note: the value of correspond resultIndex is caculated differently)
                        for(var item in arrData){
                            finalData[item][index] = arrData[item][resultIndex] || arrData[item][resultIndex]==0
                            ?parseFloat(arrData[item][resultIndex].toFixed(2))
                            :null;
                        }
                        CIQ.labelOption[criteria=='entry'?indexNum:indexNum+5] = ''
                        break
                    }
                    case("Aligator_like"):{
                        var {radio,radioValue,techValue} = JSON.parse(conditionRadio)
                        var _conditionRadio = radio

                        var resultIndexRadioValue = ''
                        var resultIndexTechValue = ''
                        //console.log(JSON.parse(conditionRadio))
                        for(var i in Object.keys(sd.outputMap)){
                            
                            switch(_conditionRadio){
                                case('first'):{
                                    if(Object.keys(sd.outputMap)[i].toLowerCase().search(techValue.toLowerCase()) != -1){
                                        resultIndex = Object.keys(sd.outputMap)[i]
                                    }
                                    CIQ.labelOption[criteria=='entry'?indexNum:indexNum+5] = '_'+techValue
                                    break
                                }
                                case('second'):{
                                    if(Object.keys(sd.outputMap)[i].toLowerCase().search(radioValue.toLowerCase()) != -1){
                                        resultIndexRadioValue = Object.keys(sd.outputMap)[i]
                                    }
                                    if(Object.keys(sd.outputMap)[i].toLowerCase().search(techValue.toLowerCase()) != -1){
                                        resultIndexTechValue = Object.keys(sd.outputMap)[i]
                                    }
                                    CIQ.labelOption[criteria=='entry'?indexNum:indexNum+5] = '_'+ radioValue + '-' + techValue
                                    break
                                }
                                default:
                            }
                        }
                        // load a value of this study to dataframe(important note: the value of correspond resultIndex is caculated differently)
                        for(var item in arrData){
                            if(_conditionRadio != 'second'){
                                finalData[item][index] = arrData[item][resultIndex] || arrData[item][resultIndex]==0
                                ?parseFloat(arrData[item][resultIndex].toFixed(2))
                                :null;
                            }else{
                                if(arrData[item][resultIndexRadioValue]&&arrData[item][resultIndexTechValue]){
                                    finalData[item][index] = parseFloat((arrData[item][resultIndexRadioValue].toFixed(2)-arrData[item][resultIndexTechValue].toFixed(2))).toFixed(2)
                                }else{
                                    finalData[item][index] =  null
                                }
                            }
                        }
                        break
                    }
                    case("LRF_like"):{
                        // output only indicator value 
                        resultIndex = Object.keys(sd.outputMap)[0]
                        var keywordList = ['Forecast ‌Lin Fcst‌‌','Forecast ‌Time Fcst‌']
                        for(var i in Object.keys(sd.outputMap)){
                            for(var k in keywordList){
                                if(Object.keys(sd.outputMap)[i].search(keywordList[k]) != -1){
                                    resultIndex = Object.keys(sd.outputMap)[i]
                                }
                            }
                        }
                        for(var item in arrData){
                            finalData[item][index] = arrData[item][resultIndex] || arrData[item][resultIndex]==0
                            ?parseFloat(arrData[item][resultIndex].toFixed(2))
                            :null;
                        }
                        CIQ.labelOption[criteria=='entry'?indexNum:indexNum+5] = ''
                        break
                    }
                    case("Trailingstop_like"):{
                        // output only indicator value 
                        resultIndex = Object.keys(sd.outputMap)[0]
                        var keywordList = ['Result ‌PSAR‌','All Stops ‌ATR Trailing Stop‌']
                        for(var i in Object.keys(sd.outputMap)){
                            for(var k in keywordList){
                                if(Object.keys(sd.outputMap)[i].search(keywordList[k]) != -1){
                                    resultIndex = Object.keys(sd.outputMap)[i]
                                }
                            }
                        }
                        for(var item in arrData){
                            finalData[item][index] = arrData[item][resultIndex] || arrData[item][resultIndex]==0
                            ?parseFloat(arrData[item][resultIndex].toFixed(2))
                            :null;
                        }
                        CIQ.labelOption[criteria=='entry'?indexNum:indexNum+5] = ''
                        break
                    }
                    default:{
                        // resultIndex = Object.keys(arrData[100])[18]
                        // console.log(Object.keys(arrData[100]))
                    }
                }
            }
        }
    }

    // find if this study is a normal sentiment indicator
    var list = CIQ.indicatorList.map(function(item){return item.url;});
    if( list.indexOf(sd.type) != -1){
        resultIndex = sd.type
        // load a value of this study to dataframe(important note: the value of correspond resultIndex is caculated differently)
        for(var item in arrData){
            finalData[item][index] = arrData[item][resultIndex] || arrData[item][resultIndex]==0
            ?parseFloat(arrData[item][resultIndex].toFixed(2))
            :null;       
        }
        CIQ.labelOption[criteria=='entry'?indexNum:indexNum+5] = ''
    }   

    // find if there is a ma line attachs to an indicator
    for(var j in CIQ.stxx.layout.studies){
        var s = CIQ.stxx.layout.studies[j]
        // normal senti indicator with MA Line
        if(s.type == "ST MA" && s.inputs.Field == sd.type && conditionRadio == 'Sentiment Moving Average'){
            //console.log(Object.keys(sd.outputMap),arrData)
            for(var i in Object.keys(arrData[10])){
                if(Object.keys(arrData[10])[i].search("ST MA") != -1 &&
                Object.keys(arrData[10])[i].search(sd.type) != -1){
                    resultIndex = Object.keys(arrData[10])[i]
                }
            }
            // load a value of this study to dataframe(important note: the value of correspond resultIndex is caculated differently)
            for(var item in arrData){
                finalData[item][index] = arrData[item][resultIndex] || arrData[item][resultIndex]==0
                ?parseFloat(arrData[item][resultIndex].toFixed(2))
                :null;
            }
            CIQ.labelOption[criteria=='entry'?indexNum:indexNum+5] = '_ma'
        }

        // MovingAverage-Like with MA Line
        if(s.type == "ST MA" && s.inputs.Field == "field" && sd.type == "ma" && conditionRadio == 'Moving Average'){
            var resultIndexMA = ''
            for(var i in Object.keys(arrData[10])){
                if(Object.keys(arrData[10])[i].search("ST MA") != -1){
                    resultIndex = Object.keys(arrData[10])[i]
                }
                if(Object.keys(arrData[10])[i].search("MA ‌ma") != -1){
                    resultIndexMA = Object.keys(arrData[10])[i]
                }
            }
            // load a value of this study to dataframe(important note: the value of correspond resultIndex is caculated differently)

            for(var item in arrData){
                finalData[item][index] = parseFloat((arrData[item][resultIndexMA] - arrData[item][resultIndex]).toFixed(2));
            }
            CIQ.labelOption[criteria=='entry'?indexNum:indexNum+5] = '_ma'
        }
    }
    
    return finalData
}

export { CIQ }