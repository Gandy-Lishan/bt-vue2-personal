import {CIQ} from "../../js/chartiq.js"

CIQ.addMask = function coverDiv(){   
    var procbg = document.createElement("div");
    procbg.setAttribute("id","mybg"); 
    procbg.style.background = "#000000";   
    procbg.style.width = "100%";   
    procbg.style.height = "100%";   
    procbg.style.position = "fixed";   
    procbg.style.top = "0";   
    procbg.style.left = "0";   
    procbg.style.zIndex = "500";   
    procbg.style.opacity = "0.6";   
    procbg.style.filter = "Alpha(opacity=70)";   
    document.body.appendChild(procbg);   
}   
  
CIQ.hideMask = function hide() {   
    document.getElementById('mybg').style.display="none"; 
    var body = document.getElementsByTagName("body");   
    var mybg = document.getElementById("mybg");   
    body[0].removeChild(mybg);   
}