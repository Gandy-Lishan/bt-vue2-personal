import { CIQ } from "../../js/chartiq.js";

CIQ.addCover = function coverDiv(){   
    var procbg = document.createElement("div"); //首先创建一个div   
    procbg.setAttribute("id","mybg"); //定义该div的id   
    
    procbg.style.width = "100%";   
    procbg.style.height = "100%";   
    procbg.style.position = "fixed";   
    procbg.style.top = "0";   
    procbg.style.left = "0";   
    procbg.style.zIndex = "500";   
    procbg.style.opacity = "0.6";   
    procbg.style.filter = "Alpha(opacity=70)";   

    procbg.style.backgroundColor = "white"; 
    procbg.style.verticalAlign = "bottom";
    procbg.style.fontSize = "large";
    procbg.style.fontWeight = "400"
    procbg.style.fontStyle = "italic"
    procbg.style.paddingTop = "20%"
    procbg.style.color = "blue"
    //procbg.style.backgroundImage = "url(https://gimg2.baidu.com/image_search/src=http%3A%2F%2Fhbimg.b0.upaiyun.com%2F458412ef0894476c376deb206e089b27160f46ba4452-nMT6Xd_fw658&refer=http%3A%2F%2Fhbimg.b0.upaiyun.com&app=2002&size=f9999,10000&q=a80&n=0&g=0n&fmt=jpeg?sec=1643167340&t=b5b0acf47c16027a9f382199857c64e3)"
    procbg.style.backgroundRepeat = "no-repeat"
    procbg.style.backgroundAttachment = "fixed"
    procbg.style.backgroundPosition = "center"
    procbg.style.display = "block"
    document.body.appendChild(procbg);   
}  
  
CIQ.hideCover = function hide() {   
    document.getElementById('mybg').style.display="none"; 
    var body = document.getElementsByTagName("body");   
    var mybg = document.getElementById("mybg");   
    body[0].removeChild(mybg);   
}

export { CIQ }