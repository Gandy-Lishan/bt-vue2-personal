import { CIQ } from "../../js/chartiq.js";

CIQ.addCover = function coverDiv(content){   
    let coverList = document.getElementsByClassName('mybg')
    if(coverList.length!=0){
        //console.log('mask already exist,change text on mask by instead')
        CIQ.setCoverText(content)
        return
    }
    
    var procbg = document.createElement("div"); //首先创建一个div  
    let cont = content?content:"the chart is loading, it might take a few seconds..."
    procbg.innerHTML = "<div class='el-loading-spinner'><i class='el-icon-loading'></i><p class='el-loading-text'>"+ cont +"</p></div>" 

    procbg.classList.add("mybg"); //定义该div的id  
    procbg.classList.add("el-loading-mask")
    procbg.style.backgroundColor = "rgba(0, 0, 0, 0.8)";  

    document.body.appendChild(procbg);   

    console.log('*******SHOW MASK*********\n', content)
}  

CIQ.setCoverText = function(cont){
    let coverText = document.getElementsByClassName('mybg')[0].children[0].children[1]
    coverText.innerHTML = cont
}
  
CIQ.hideCover = function hide() { 
    console.log('*******HIDE MASK*********')
    // document.getElementById('mybg').style.display="none"; 
    // var body = document.getElementsByTagName("body");   
    // var mybg = document.getElementsByClassName('mybg')[0];   
    // body[0].removeChild(mybg);  
    
    var body = document.getElementsByTagName("body"); 
    let coverList = document.getElementsByClassName('mybg')
    for(var item of coverList){
        item.style.display="none"; 
        body[0].removeChild(item);
    }
}

export { CIQ }