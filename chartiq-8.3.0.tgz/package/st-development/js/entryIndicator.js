import {CIQ} from "./STMask"
import {config} from "../feeds/STDataFeedAccessUrl.js"
import "./STMovingAverages"
import axios from "axios"

CIQ.saveLayout = function() {
    var layout = CIQ.stxx.exportLayout(true);
    
    CIQ.store.commit('getImportedLayout',layout)
}
CIQ.reloadChart = function() {
	CIQ.store.commit('getEntryIndicators','')
	CIQ.store.commit('getExitIndicators','')
	CIQ.store.commit('getMA',[])
	CIQ.store.commit('getExtraIndicators',[])
	CIQ.store.commit('getTechnicalIndicators',[])
    CIQ.store.commit('getFrequency', 'Daily')
	CIQ.symbol = 'SPY'
	CIQ.hideMarker()
	document.getElementsByClassName("ciq-period")[0].style.display = "block"
	CIQ.addIndicators()
}
// CIQ.restoreLayout = function() {
// 	var savedLayout = CIQ.store.state.importedLayout
// 	var importOptions = {
// 		managePeriodicity: true,
// 		preserveTicksAndCandleWidth: true
// 	};
//     console.log('imported layout: ',savedLayout)
// 	if (savedLayout) CIQ.stxx.importLayout(savedLayout, importOptions);
// }
CIQ.loadMessage = function(value){
	document.querySelector(".discription_div").innerHTML = `<cq-study-dialog class="discription_dialog"></cq-study-dialog>`;
		document.querySelector(".discription_dialog").innerHTML = `
				<cq-dialog class="ciq-day" cq-study-dialog="true" cq-active="true" style="top: 50%; left: 50%; transform: translate(-50%, -50%);">
				<cq-study-dialog cq-study-axis="true" cq-study-panel="alias">
				<h4 class="title" style="font-size: 20px; font-weight: 500">Load sucess</h4>
				<div class="ps__rail-x" style="left: 0px; bottom: 0px;"><div class="ps__thumb-x" tabindex="0" style="left: 0px; width: 0px;"></div></div><div class="ps__rail-y" style="top: 0px; right: 0px; height: 373px;"><div class="ps__thumb-y" tabindex="0" style="top: 0px; height: 322px;"></div></div></cq-scroll>
				<div class="ciq-dialog-cntrls">
				 <div class="ciq-btn discription-btn" >Done</div>
				</div>
			   </cq-study-dialog></cq-dialog>`;
				document.querySelector(".discription-btn").addEventListener("click",function(){
					document.querySelector(".discription_div").innerHTML = ""
				})
			   document.querySelector(".discription_dialog").open()
}
CIQ.addIndicatorsFromBacktest = function(){
    CIQ.notADefaultCall = true
    CIQ.addCover()

    // set indicatorList to local storage, fetch it when change a symbol
        let indicatorsList = [CIQ.store.state.indicators.formIndicators.entry,CIQ.store.state.indicators.formIndicators.exit]
        console.log('entry&exit: ',indicatorsList)
        //console.log("entry/exit critirial from Vuex: ",indicatorsList)
          // remove redundant elements and empty string
          for(var i=0;i<indicatorsList.length;i++){
            if(indicatorsList[i]==''){
              indicatorsList.splice(i,1)
              i--;
            }
          }
          
        // indicatorsList = indicatorsList.concat(CIQ.store.state.indicators.extraIndicators)
        // const set = new Set(indicatorsList)
        // indicatorsList = [...set]
        
        //  load saved indicator layouts from backtest list
        var savedTechSD = []
        savedTechSD = CIQ.store.state.techSD
        CIQ.store.commit('setSavedTechSD', savedTechSD)

        for (var studyInstanceName in CIQ.stxx.layout.studies) {
            CIQ.Studies.removeStudy(CIQ.stxx, CIQ.stxx.layout.studies[studyInstanceName])
        }
        

        // sort indicatorsList into a "[senti,tech]" style
        let techList = CIQ.store.state.indicators.technicalIndicators
        let technicalIndicators = []
        for(var item in indicatorsList){
            if(techList.indexOf(indicatorsList[item]) != -1){
                technicalIndicators.push(indicatorsList[item])
                indicatorsList[item] = ''
            }    
        }
        indicatorsList = indicatorsList.concat(technicalIndicators).filter(item=>{return item !== ''})
        
        CIQ.getIndicatorMatedata(indicatorsList)

        if(CIQ.store.state.backtestSymbol){
            CIQ.symbol = CIQ.store.state.backtestSymbol
         }
        CIQ.store.commit('getBacktestSymbol', 'SPY')
    
        CIQ.stxx.loadChart(	{ symbol: CIQ.symbol,startDate:new Date(),endDate:new Date(), indicator:indicatorsList}, function () {
            // callback - your code to be executed after the chart is loaded
            CIQ.hideCover()
            //CIQ.loadMessage()
            
            //indicatorListTest()
            //CIQ.exportEx()
    
        })
        
}

CIQ.addIndicators = function(){
    CIQ.notADefaultCall = true
    CIQ.addCover()

    // set indicatorList to local storage, fetch it when change a symbol
        let indicatorsList = [CIQ.store.state.indicators.formIndicators.entry,CIQ.store.state.indicators.formIndicators.exit]
        console.log('entry&exit: ',indicatorsList)
        //console.log("entry/exit critirial from Vuex: ",indicatorsList)
          // remove redundant elements and empty string
          for(var i=0;i<indicatorsList.length;i++){
            if(indicatorsList[i]==''){
              indicatorsList.splice(i,1)
              i--;
            }
          }
          
        indicatorsList = indicatorsList.concat(CIQ.store.state.indicators.extraIndicators)
        const set = new Set(indicatorsList)
        indicatorsList = [...set]
        
        //  load saved indicator layouts from stxx.layout
        var savedTechSD = []
        for(var i in CIQ.stxx.layout.studies){
            savedTechSD.push({
                type: CIQ.stxx.layout.studies[i].type,
                inputs: CIQ.stxx.layout.studies[i].inputs,
                outputs: CIQ.stxx.layout.studies[i].outputs,
                parameters: CIQ.stxx.layout.studies[i].parameters,
                panel: CIQ.stxx.layout.studies[i].panel
            })
        }
        CIQ.store.commit('setSavedTechSD', savedTechSD)

        for (var studyInstanceName in CIQ.stxx.layout.studies) {
            CIQ.Studies.removeStudy(CIQ.stxx, CIQ.stxx.layout.studies[studyInstanceName])
        }
        

        // sort indicatorsList into a "[senti,tech]" style
        let techList = CIQ.store.state.indicators.technicalIndicators
        let technicalIndicators = []
        for(var item in indicatorsList){
            if(techList.indexOf(indicatorsList[item]) != -1){
                technicalIndicators.push(indicatorsList[item])
                indicatorsList[item] = ''
            }    
        }
        indicatorsList = indicatorsList.concat(technicalIndicators).filter(item=>{return item !== ''})
        
        CIQ.getIndicatorMatedata(indicatorsList)

        console.log('addindicators backtestSymbol: ',CIQ.store.state.backtestSymbol)
        if(CIQ.store.state.backtestSymbol){
            CIQ.symbol = CIQ.store.state.backtestSymbol
         }
        CIQ.store.commit('getBacktestSymbol', 'SPY')

        CIQ.stxx.loadChart(	{ symbol: CIQ.symbol,startDate:new Date(),endDate:new Date(), indicator:indicatorsList}, function () {
            // callback - your code to be executed after the chart is loaded
            CIQ.hideCover()
            //CIQ.loadMessage()
            
            //indicatorListTest()
            //CIQ.exportEx()
    
        })
        
}

CIQ.addSymbol = function(symbol){
    // find if there is no items in current studylist
    CIQ.addCover()

    let count = 0

    //  load saved indicator layouts from stxx.layout
    var savedTechSD = []
    for(var i in CIQ.stxx.layout.studies){
        savedTechSD.push({
            type: CIQ.stxx.layout.studies[i].type,
            inputs: CIQ.stxx.layout.studies[i].inputs,
            outputs: CIQ.stxx.layout.studies[i].outputs,
            parameters: CIQ.stxx.layout.studies[i].parameters,
            panel: CIQ.stxx.layout.studies[i].panel
        })
    }

    CIQ.store.commit('setSavedTechSD', savedTechSD)

    for (var studyInstanceName in CIQ.stxx.layout.studies) {
        count++
        CIQ.Studies.removeStudy(CIQ.stxx, CIQ.stxx.layout.studies[studyInstanceName])
    }

    let indicatorsList = [CIQ.store.state.indicators.formIndicators.entry,CIQ.store.state.indicators.formIndicators.exit]
    // remove redundant elements and empty string

    for(var i=0;i<indicatorsList.length;i++){
      if(indicatorsList[i]==''){
        indicatorsList.splice(i,1)
        i--;
      }
    }
    indicatorsList = indicatorsList.concat(CIQ.store.state.indicators.extraIndicators)
    const set = new Set(indicatorsList)
    indicatorsList = [...set]

    if(indicatorsList.length==0){
        indicatorsList = ['AAPL']
    }

    // sort indicatorsList into a "[senti,tech]" style
    let techList = CIQ.store.state.indicators.technicalIndicators
    let technicalIndicators = []
    for(var item in indicatorsList){
        if(techList.indexOf(indicatorsList[item]) != -1){
            technicalIndicators.push(indicatorsList[item])
            indicatorsList[item] = ''
        }    
    }
    indicatorsList = indicatorsList.concat(technicalIndicators).filter(item=>{return item !== ''})

    if(count>0){
        CIQ.getIndicatorMatedata(indicatorsList)
    } 
    
    // if there's a technical study in indicatorList, remove it before loading chart
    // let techList = CIQ.store.state.indicators.technicalIndicators
    // for(var i in indicatorsList){
    //     if(techList.indexOf(indicatorsList[i]) != -1){
    //         indicatorsList.splice(i,1)
    //     }
    // } 
    
   
    CIQ.stxx.loadChart(	{ symbol: symbol,startDate:new Date(),endDate:new Date(), indicator:indicatorsList}, function () {
        // callback - your code to be executed after the chart is loaded  
        CIQ.hideCover()
    })
    
}

// 这个函数是用来在选中的timeframe小于已有timeframe时移除对应indicator， 现在这种情况直接disable可选项，故弃用
CIQ.filterByFrequency = function(){
   
    var currentList = CIQ.stxx.layout.studies
    var list = CIQ.indicatorList
    var deleteList = []

    var selectedFreq = CIQ.store.state.exitFrequency
    for(var item in currentList){
        let _obj = list.find(x => x.url == currentList[item].type)
        if(selectedFreq == "Monthly"){
        }else if(selectedFreq == "Weekly" && _obj.updated == "Monthly"){
            deleteList.push(currentList[item])
        }else if((selectedFreq == "Daily" && _obj.updated == "Monthly") || (selectedFreq == "Daily" && _obj.updated == "Weekly")){
            deleteList.push(currentList[item])
        }
    }
    for(var item in deleteList){         
        if(CIQ.store.state.indicators.formIndicators.entry == deleteList[item].type){
            CIQ.store.commit('getEntryIndicators','')
        }else if(CIQ.store.state.indicators.formIndicators.exit == deleteList[item].type){
            CIQ.store.commit('getExitIndicators','')
        }else if(CIQ.store.state.indicators.extraIndicators.indexOf(deleteList[item].type) != -1){
            var extraIndicators = CIQ.store.state.indicators.extraIndicators
            extraIndicators.splice(extraIndicators.indexOf(deleteList[item].type),1)
            CIQ.store.commit('getExtraIndicators',extraIndicators)
        }else{
           // console.log('builtin remove')
        }

        // remove MA
        var activatedMAList = CIQ.store.state.activatedMA
        //console.log('MAList before remove: ',activatedMAList)
        var type = deleteList[item].type
        activatedMAList.splice(activatedMAList.findIndex(item=>item.url==type),1)
        //console.log(deleteList[item].type)

        CIQ.store.commit("getMA",activatedMAList)
        //console.log('MAList after remove: ',activatedMAList)

        //if (!deleteList[item].permanent) CIQ.Studies.removeStudy(CIQ.stxx, deleteList[item]);
        var chartBox = document.getElementsByClassName("chart_box")[0]
        var height = chartBox.style.height.replace("vh",'') - 15
        chartBox.style.height = height+ 'vh'
    }
}

CIQ.getIndicatorMatedata = function(indicatorList){

    var color = ["rgb(26 139 251)","#7257f2",'black',"#ff8a8a","#f98e23"]

    for (var studyInstanceName in CIQ.stxx.layout.studies) {
        var sd = CIQ.stxx.layout.studies[studyInstanceName];
        
        if (CIQ.studys.indexOf(sd.type) === -1){
            //console.log(sd.type)
            CIQ.Studies.removeStudy(CIQ.stxx, sd);
            
        }
    }
    var chartBox = document.getElementsByClassName("chart_box")[0]
    var height = 65 + indicatorList.length*15
    chartBox.style.height = height.toString()+ 'vh'
    for(var i in indicatorList){
        let techList = CIQ.store.state.indicators.technicalIndicators

        if(techList.indexOf(indicatorList[i]) != -1){
            // load technical study, no need for adding MA
            // if it's a technical study, skip sending query
            // if no savedTechSD exit, load normal study
            
            var count = 0
            for(var j in CIQ.store.state.savedTechSD){
                //console.log(indicatorList[i],CIQ.store.state.savedTechSD[i].type)
                if(indicatorList[i] == CIQ.store.state.savedTechSD[j].type){
                    count++
                    var sd = CIQ.Studies.addStudy(CIQ.stxx, indicatorList[i],CIQ.store.state.savedTechSD[j].inputs, CIQ.store.state.savedTechSD[j].outputs, CIQ.store.state.savedTechSD[j].parameters, CIQ.store.state.savedTechSD[j].panel);
                }
            }
            if(count==0){
                var sd = CIQ.Studies.addStudy(CIQ.stxx, indicatorList[i],{display:indicatorList[i]}); 
            }
            console.log(sd)

            for(var j in CIQ.store.state.activatedMA){                            
                if((CIQ.store.state.activatedMA[j].url != '')&&(CIQ.store.state.activatedMA[j].url == indicatorList[i])){
                    if(CIQ.store.state.activatedMA[j].url == 'ma'){
                        // 直接加载，信息都更新再studylibrary
                        var sd = CIQ.Studies.addStudy(CIQ.stxx, 'ST MA', {
                            // Type: CIQ.store.state.activatedMA[i].type,
                            Period: CIQ.store.state.activatedMA[j].period,
                            display: 'ST MA',
                        })            
                    }else{
                        sd = CIQ.Studies.addStudy(CIQ.stxx, "ST MA",{Period: CIQ.store.state.activatedMA[j].period,display:"ST MA",Field: CIQ.store.state.activatedMA[j].url});
                        console.log(sd)
                    }    
                }   
            }

            // var extremeValue = {extremeOptimism:sd.parameters.studyOverBoughtValue,extremePessimism:sd.parameters.studyOverSoldValue}
            // CIQ.store.commit("getExtremeValue", extremeValue) 
            continue
        }
        (function(i){
                var queryUrl =  config.indicatorMetadata + 
                "?indicator=" + indicatorList[i];
    
                //console.log(queryUrl);

                // now it changed to async call
                var server = new XMLHttpRequest();   
                server.open("GET", queryUrl,true);
                server.setRequestHeader("Authorization", "Basic " + btoa(config.username+":"+config.password));  
                server.send(null);
    
                // timeout detector
                server.ontimeout = function(){
                    console.log('request timeout')
                }

                server.onreadystatechange = function(){
                    if(server.readyState == 4){
                        if (server.status===200) {
                            try {
                                // load list from vuex
                                // let indicatorsList = [CIQ.store.state.indicators.formIndicators.entry,CIQ.store.state.indicators.formIndicators.exit]
                            
                                // for(var k=0;k<indicatorsList.length;k++){
                                //   if(indicatorsList[k]==''){
                                //     indicatorsList.splice(k,1)
                                //     k--;
                                //   }
                                // }
                                // indicatorsList = indicatorsList.concat(CIQ.store.state.indicators.extraIndicators)
                                // const set = new Set(indicatorsList)
                                // indicatorsList = [...set]
                            
                                // if(indicatorsList.length==0){
                                //     indicatorsList = ['AAPL']
                                // }
                                // indicatorList = indicatorsList
                                
                                // 异步导致前面的removestudy提前运行，在这里再清除一次重复的
                                    for (var studyInstanceName in CIQ.stxx.layout.studies) {
                                        var sd = CIQ.stxx.layout.studies[studyInstanceName];
                                        
                                        if (indicatorList[i]==sd.type){
                                            CIQ.Studies.removeStudy(CIQ.stxx, sd);
                                        }
                                    }

                                    var newQuotes = JSON.parse(server.response);
                                    
                                    if (newQuotes !== null){
                                        var newStudy = {
                                            inputs: { Period: 13, Overlay: false},
                                            outputs: 
                                            {indicatorClose:color[i%5],description: newQuotes.description,url:indicatorList[i]},
                                            parameters: { init: {
                                                studyOverZonesEnabled: newQuotes.opt_extreme?true:false,
                                                studyOverBoughtValue: newQuotes.opt_extreme?newQuotes.opt_extreme:NaN,
                                                studyOverBoughtColor: "#FF0000",
                                                studyOverSoldValue: newQuotes.pess_extreme?newQuotes.pess_extreme:NaN,
                                                studyOverSoldColor: "#00DD00",
                                            }},
                                            attributes:{
                                                studyOverBoughtValue:{"step":0.01},
                                                studyOverSoldValue:{"step":0.01}
                                            }
                                        }
                                        
                                            var str = JSON.stringify(newStudy);                                   
                                            str = str.replace(/indicatorClose/g, indicatorList[i]);
                                            newStudy = JSON.parse(str)                                     
                                            
                                            CIQ.Studies.studyLibrary[indicatorList[i]] = newStudy
                                            
                                            var count = 0
                                            for(var j in CIQ.store.state.savedTechSD){
                                                //console.log(indicatorList[i],CIQ.store.state.savedTechSD[i].type)
                                                if(indicatorList[i] == CIQ.store.state.savedTechSD[j].type){
                                                    count++
                                                    var sd = CIQ.Studies.addStudy(CIQ.stxx, indicatorList[i],CIQ.store.state.savedTechSD[j].inputs, CIQ.store.state.savedTechSD[j].outputs, CIQ.store.state.savedTechSD[j].parameters, CIQ.store.state.savedTechSD[j].panel);
                                                }
                                            }
                                            if(count==0){
                                                var sd = CIQ.Studies.addStudy(CIQ.stxx,indicatorList[i])
                                            }
                                            console.log(sd)

                                            var newExtremeValue = {indicator:indicatorList[i],extremeOptimism:sd.parameters.studyOverBoughtValue,extremePessimism:sd.parameters.studyOverSoldValue}
                                            var extremeValueList = CIQ.store.state.extremeValue
                                            // if(!extremeValueList.some((item)=>{return item.indicator == newExtremeValue.indicator})){
                                                extremeValueList.push(newExtremeValue)
                                            //}

                                            CIQ.store.commit("getExtremeValue", extremeValueList)
                                        // stxx.panels[sd.panel].yAxis
                                        
                                    }
                                    for(var j in CIQ.store.state.activatedMA){          
                                        if((CIQ.store.state.activatedMA[j].url != '')&&(CIQ.store.state.activatedMA[j].url == indicatorList[i])){
                                            if(CIQ.store.state.activatedMA[j].url == 'ma'){
                                                // 直接加载，信息都更新再studylibrary
                                                var sd = CIQ.Studies.addStudy(CIQ.stxx, 'ST MA', {
                                                    // Type: CIQ.store.state.activatedMA[i].type,
                                                    Period: CIQ.store.state.activatedMA[j].period,
                                                    display: 'ST MA',
                                                })
                                               
                                            }else{
                                               
                                                sd = CIQ.Studies.addStudy(CIQ.stxx, "ST MA",{Period: CIQ.store.state.activatedMA[j].period,display:"ST MA",Field: CIQ.store.state.activatedMA[j].url});
                                                console.log('sentiment st ma ',CIQ.stxx.layout.studies)
                                            }    
                                        }   
                                    }
                            }catch (e) {
                                if (newQuotes !== null){
                                    var newStudy = {
                                        inputs: { Period: 13, Overlay: false,},
                                        outputs: 
                                        {indicatorClose:color[i%5],description: newQuotes.description,url:indicatorList[i]},
                                        parameters: { init: {
                                            studyOverZonesEnabled: true,
                                            studyOverBoughtValue: 80,
                                            studyOverBoughtColor: "#FF0000",
                                            studyOverSoldValue: 20,
                                            studyOverSoldColor: "#00DD00",
                                        }},
                                        attributes:{
                                            studyOverBoughtValue:{"step":0.01},
                                            studyOverSoldValue:{"step":0.01}
                                        }
                                    }
                                    
                                    var str = JSON.stringify(newStudy);                                   
                                    str = str.replace(/indicatorClose/g, indicatorList[i]);
                                    newStudy = JSON.parse(str)                                     
                                    
                                    CIQ.Studies.studyLibrary[indicatorList[i]] = newStudy
                                    var count = 0
                                    for(var j in CIQ.store.state.savedTechSD){
                                        //console.log(indicatorList[i],CIQ.store.state.savedTechSD[i].type)
                                        if(indicatorList[i] == CIQ.store.state.savedTechSD[j].type){
                                            count++
                                            var sd = CIQ.Studies.addStudy(CIQ.stxx, indicatorList[i],CIQ.store.state.savedTechSD[j].inputs, CIQ.store.state.savedTechSD[j].outputs, CIQ.store.state.savedTechSD[j].parameters, CIQ.store.state.savedTechSD[j].panel);
                                        }
                                    }
                                    if(count==0){
                                        var sd = CIQ.Studies.addStudy(CIQ.stxx,indicatorList[i])
                                    }
                                    console.log(sd)

                                    var newExtremeValue = {indicator:indicatorList[i],extremeOptimism:sd.parameters.studyOverBoughtValue,extremePessimism:sd.parameters.studyOverSoldValue}
                                    var extremeValueList = CIQ.store.state.extremeValue
                                
                                    if(!extremeValueList.some((item)=>{return item.indicator == newExtremeValue.indicator})){
                                        
                                        extremeValueList.push(newExtremeValue)
                                    }
                                    //console.log('curremt extremeValueList is: ',extremeValueList)
                                    CIQ.store.commit("getExtremeValue", extremeValueList)
                                }
                            }
                        }else{
                            console.error(server.statusText)
                        }
                    }
                }
                
                server.onerror = function(e){
                    console.error(server.statusText)
                }
            }

        )(i)
    }
        console.log(CIQ.store.state.activatedMA)
                            
    
}

async function indicatorListTest(){
    var list = CIQ.indicatorList
    console.log('test start, length of indicatorList is: ',list.length)
    var emptyList = []
    var count = 0
    for(var item in list){
        let url = 'https://05kv55a2v9.execute-api.us-east-1.amazonaws.com/dev/indicator_metadata?indicator=' + list[item].url
        const res = await axios.get(
            url,
            {
                auth: {
                    username: 'sentimentrader_backtest_api',
                    password: 'TAZcbpTmQVAJW4GW3ZMQA1su0ynjqJJsYo6vfkapx'
                }
            }
        )
        var indicatorList = res.data
        //console.log("url: ",indicatorList.opt_extreme+'    '+count)

        if(indicatorList.opt_extreme == null){
            //console.log("empty result!!! ",list[item].url)
            emptyList.push({url:list[item].url,extreme_value:indicatorList.opt_extreme})
            console.log("empty opt_extreme found: \n",list[item].url+' '+indicatorList.opt_extreme+'    '+count)
            count++
        }
    }
    
    localStorage.setItem('invalidIndicators', JSON.stringify(emptyList));
    console.log('*******************end*******\n', localStorage.getItem('invalidIndicators'))
}


// download study data
CIQ.exportEx = function(){  
    
    let ShowLabel = []
    let finalData = []
    let study = CIQ.stxx.layout.studies[Object.keys(CIQ.stxx.layout.studies).pop()]
    if(study == undefined){ return }
    let JSONData = study.chart.scrubbed

    //先转化json
    let arrData = typeof JSONData != 'object' ? JSON.parse(JSONData) : JSONData;
    console.log('arrData ',arrData[2000])
    // 给数组内容换好位置
    arrData.forEach(item => {
        let date = item.Date
        let obj = {
            Date: date.slice(0,4)+ '-' + date.slice(4,6)+ '-' + date.slice(6,8),
            Open: item.Open,
            High: item.High,
            Low: item.Low,
            Close: item.Close ? item.Close : '',
            Volume: item.Volume,
            entry_1: null,
            entry_2: null,
            entry_3: null,
            entry_4: null,
            entry_5: null,
            exit_1: null,
            exit_2: null,
            exit_3: null,
            exit_4: null,
            exit_5: null,
            //Result: item[Object.keys(item)[8]],     
        };
        ShowLabel = Object.keys(obj);
      finalData.push(obj);
    });

    // find the correspond sd type
    for(var i in CIQ.stxx.layout.studies){
        var sd = CIQ.stxx.layout.studies[i]
        if(1){
        //if(sd.type == CIQ.store.state.indicators.formIndicators.exit){
            var resultIndex = ''

            var categoryList = CIQ.technicalCategory
            // technical indicators
            for(var _class in categoryList){
                var studies = categoryList[_class].studies
                for(var _study in studies){
                    if(sd.type == studies[_study].url){
                        var category = categoryList[_class].class
                        
                        switch(category){
                            case("CCI_like"):{
                                // var keywordList = ['CCI cci','Result',"Bandwidth ‌Boll BW‌","W MFI‌ "]
                                // for(var i in Object.keys(sd.outputMap)){
                                //     for(var k in keywordList){
                                //         if(Object.keys(sd.outputMap)[i].search(keywordList[k]) != -1){
                                //             resultIndex = Object.keys(sd.outputMap)[i]
                                //             break
                                //         }
                                //     }  
                                // }

                                // output only indicator value 
                                resultIndex = Object.keys(sd.outputMap)[0]
                                break
                            }
                            case("MACD_like"):{
                                //MACD ‌macd‌
                                var conditionRadio = CIQ.store.state.conditionRadio
                                console.log(conditionRadio)
                                for(var i in Object.keys(sd.outputMap)){
                                    var keywordList = []
                                    switch(conditionRadio){
                                        case('Indicator Value'):{
                                            keywordList = ['MACD ‌macd‌','Klinger ‌Klinger‌','Rel Vig ‌Rel Vig‌']
                                            break
                                        }
                                        case('Indicator Value '):{
                                            keywordList = ['_hist']
                                            break
                                        }
                                        case('Indicator Hist'):{
                                            keywordList = ['_hist']
                                            break
                                        }
                                        default:
                                    }
                                    for(var k in keywordList){
                                        if(Object.keys(sd.outputMap)[i].search(keywordList[k]) != -1){
                                            resultIndex = Object.keys(sd.outputMap)[i]
                                        }
                                    }
                                }
                                break
                            }
                            case("EFT_like"):{

                            }
                            case("BollingerBands_like"):{
                                //Use Indicator High/Medium/Low Band raw data whichever is chosen in the drop list. 
                                break
                            }
                            default:{
                                // resultIndex = Object.keys(arrData[1000])[18]
                                // console.log(Object.keys(arrData[1000]))
                            }
                        }
                    }
                }
            }

            // find if this study is a normal sentiment indicator
            var list = CIQ.indicatorList.map(function(item){return item.url;});
            if( list.indexOf(sd.type) != -1){
                resultIndex = sd.type
            }   

            // find if there is a ma line attachs to this sentiment indicator
            for(var j in CIQ.stxx.layout.studies){
                var s = CIQ.stxx.layout.studies[j]
                if(s.type == "ST MA" && s.inputs.Field == sd.type){
                    for(var i in Object.keys(arrData[1000])){
                        if(Object.keys(arrData[1000])[i].search("ST MA") != -1){
                            resultIndex = Object.keys(arrData[1000])[i]
                        }
                    }
                }
            }
            console.log("outputMap: ",sd.outputMap)
            console.log("resultIndex: ",resultIndex)
            //console.log(sd.chart.scrubbed[1000])
            // load a value of this study to dataframe
            for(var item in arrData){
                finalData[item].entry_1 = arrData[item][resultIndex];
            }
        }
    }

    console.log('finalCols: ',finalData[2000])
    // let excel = '<table>';
    // //设置表头
    // let row = '<tr>';
    // for (let i = 0; i < ShowLabel.length; i++) {
    //   row += '<td>' + ShowLabel[i] + '</td>';
    // }
    // //换行
    // excel += row + '</tr>';
    // //设置数据
    // for (let i = 0; i < finalData.length; i++) {
    //   let row = '<tr>';
    //   for (let index in finalData[i]) {
    //     let value = finalData[i][index];
    //     if (index === 'Date' || index === 'MA ‌ST CCI‌ (20)' || index === 'Result ‌ST CCI‌ (20)') {
    //       // 当数字超过一定长度就科学计数法可以使用style='mso-number-format:"\@"'
    //       // 这个属性指定某单元格的数据格式，避免Excel自动转换格式
    //       row += `<td style='mso-number-format:\"\\@\"'>${value}</td>`;
    //     } else {
    //       row += '<td>' + value + '</td>';
    //     }
    //   }
    //   excel += row + '</tr>';
    // }
    // excel += '</table>';
    // let excelFile =
    //   "<html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:x='urn:schemas-microsoft-com:office:excel' xmlns='http://www.w3.org/TR/REC-html40'>";
    // excelFile +=
    //   '<meta http-equiv="content-type" content="application/vnd.ms-excel; charset=UTF-8">';
    // excelFile += '<meta http-equiv="content-type" content="application/vnd.ms-excel';
    // excelFile += '; charset=UTF-8">';
    // excelFile += '<head>';
    // excelFile += '<!--[if gte mso 9]>';
    // excelFile += '<xml>';
    // excelFile += '<x:ExcelWorkbook>';
    // excelFile += '<x:ExcelWorksheets>';
    // excelFile += '<x:ExcelWorksheet>';
    // excelFile += '<x:Name>';
    // excelFile += '{worksheet}';
    // excelFile += '</x:Name>';
    // excelFile += '<x:WorksheetOptions>';
    // excelFile += '<x:DisplayGridlines/>';
    // excelFile += '</x:WorksheetOptions>';
    // excelFile += '</x:ExcelWorksheet>';
    // excelFile += '</x:ExcelWorksheets>';
    // excelFile += '</x:ExcelWorkbook>';
    // excelFile += '</xml>';
    // excelFile += '<![endif]-->';
    // excelFile += '</head>';
    // excelFile += '<body>';
    // excelFile += excel;
    // excelFile += '</body>';
    // excelFile += '</html>';
    // let uri = 'data:application/vnd.ms-excel;charset=utf-8,' + encodeURIComponent(excelFile);
    // let link = document.createElement('a');
    // link.href = uri;
    // link.style = 'visibility:hidden';
    // link.download = '文件.xls';
    // document.body.appendChild(link);
    // link.click();
    // document.body.removeChild(link);
    // this.setState({
    //   errorMsgVisible: false,
    // });
    
  };

export {CIQ}