import {CIQ} from "../../js/chartiq.js"
import {config} from "../feeds/STDataFeedAccessUrl.js"


CIQ.addIndicators = async function(indicatorList){
    for (var studyInstanceName in CIQ.stxx.layout.studies) {
        CIQ.Studies.removeStudy(CIQ.stxx, CIQ.stxx.layout.studies[studyInstanceName])
    }

    CIQ.stxx.loadChart(	{ symbol: CIQ.symbol,startDate:new Date(),endDate:new Date(), indicator:indicatorList},)
    getIndicatorMatedata(indicatorList)
}

function getIndicatorMatedata (indicatorList){
    
    var color = ["#00DD00","#FF0000",'yellow']

    for (var studyInstanceName in CIQ.stxx.layout.studies) {
        var sd = CIQ.stxx.layout.studies[studyInstanceName];
        if (CIQ.studys.indexOf(sd.type) === -1){
            CIQ.Studies.removeStudy(CIQ.stxx, sd);
        }
    }
        
    for(var i in indicatorList){
        var queryUrl =  config.indicatorMetadata + 
        "?indicator=" + indicatorList[i];

        var server = new XMLHttpRequest();   
        server.open("GET", queryUrl,false);
        server.setRequestHeader("Authorization", "Basic " + btoa(config.username+":"+config.password));  
        server.send(null);

        if (server.status===200) {
            try {
                    var newQuotes = JSON.parse(server.response);
                    //console.log(newQuotes);
                    if (newQuotes !== null){
                        var newStudy = {
                            inputs: { Period: 13, Overlay: false,},
                            outputs: 
                            {indicatorClose:color[i%3],description: newQuotes.description,url:indicatorList[i]},
                            parameters: { init: {
                                studyOverZonesEnabled: true,
                                studyOverBoughtValue: newQuotes.opt_extreme,
                                studyOverBoughtColor: "#FF0000",
                                studyOverSoldValue: newQuotes.pess_extreme,
                                studyOverSoldColor: "#00DD00",
                            }}
                        }
                        
                            var str = JSON.stringify(newStudy);
                            str = str.replace(/indicatorClose/g, indicatorList[i]);
                            newStudy = JSON.parse(str)
                       
                        console.log(newStudy);
                        CIQ.Studies.studyLibrary[indicatorList[i]] = newStudy
                        CIQ.Studies.addStudy(CIQ.stxx,indicatorList[i])
                    }
            }catch (e) {
                if (newQuotes !== null){
                    var newStudy = {
                        inputs: { Period: 13, Overlay: false,},
                        outputs: 
                        {indicatorClose:color[i%3],description: newQuotes.description,url:indicatorList[i]},
                        parameters: { init: {
                            studyOverZonesEnabled: true,
                            studyOverBoughtValue: 80,
                            studyOverBoughtColor: "#FF0000",
                            studyOverSoldValue: 20,
                            studyOverSoldColor: "#00DD00",
                        }}
                    }
                    
                        var str = JSON.stringify(newStudy);
                        str = str.replace(/indicatorClose/g, indicatorList[i]);
                        newStudy = JSON.parse(str)
                   
                    console.log(newStudy);
                    CIQ.Studies.studyLibrary[indicatorList[i]] = newStudy
                    CIQ.Studies.addStudy(CIQ.stxx,indicatorList[i])
                }
            }
        }
    }
}

export {CIQ}