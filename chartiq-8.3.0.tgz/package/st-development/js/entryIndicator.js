import {CIQ} from "./STMask"
import {config} from "../feeds/STDataFeedAccessUrl.js"
import "./STMovingAverages"

CIQ.saveLayout = function() {
    var layout = CIQ.stxx.exportLayout(true);
    
    CIQ.store.commit('getImportedLayout',layout)
}
// CIQ.restoreLayout = function() {
// 	var savedLayout = CIQ.store.state.importedLayout
// 	var importOptions = {
// 		managePeriodicity: true,
// 		preserveTicksAndCandleWidth: true
// 	};
//     console.log('imported layout: ',savedLayout)
// 	if (savedLayout) CIQ.stxx.importLayout(savedLayout, importOptions);
// }
CIQ.loadMessage = function(value){
	document.querySelector(".discription_div").innerHTML = `<cq-study-dialog class="discription_dialog"></cq-study-dialog>`;
		document.querySelector(".discription_dialog").innerHTML = `
				<cq-dialog class="ciq-day" cq-study-dialog="true" cq-active="true" style="top: 50%; left: 50%; transform: translate(-50%, -50%);">
				<cq-study-dialog cq-study-axis="true" cq-study-panel="alias">
				<h4 class="title" style="font-size: 20px; font-weight: 500">Load sucess</h4>
				<div class="ps__rail-x" style="left: 0px; bottom: 0px;"><div class="ps__thumb-x" tabindex="0" style="left: 0px; width: 0px;"></div></div><div class="ps__rail-y" style="top: 0px; right: 0px; height: 373px;"><div class="ps__thumb-y" tabindex="0" style="top: 0px; height: 322px;"></div></div></cq-scroll>
				<div class="ciq-dialog-cntrls">
				 <div class="ciq-btn discription-btn" >Done</div>
				</div>
			   </cq-study-dialog></cq-dialog>`;
				document.querySelector(".discription-btn").addEventListener("click",function(){
					document.querySelector(".discription_div").innerHTML = ""
				})
			   document.querySelector(".discription_dialog").open()
}

CIQ.addIndicators = function(){
    
    CIQ.addCover()
    // set indicatorList to local storage, fetch it when change a symbol
        let indicatorsList = [CIQ.store.state.indicators.formIndicators.entry,CIQ.store.state.indicators.formIndicators.exit]
        console.log("entry/exit critirial from Vuex: ",indicatorsList)
          // remove redundant elements and empty string
          for(var i=0;i<indicatorsList.length;i++){
            if(indicatorsList[i]==''){
              indicatorsList.splice(i,1)
              i--;
            }
          }
        indicatorsList = indicatorsList.concat(CIQ.store.state.indicators.extraIndicators)
        const set = new Set(indicatorsList)
        indicatorsList = [...set]
        
        // we can have multiple redundant studies 
        // let indicatorsListWithTech = indicatorsList.concat(CIQ.store.state.indicators.technicalIndicators)
        

        for (var studyInstanceName in CIQ.stxx.layout.studies) {
            CIQ.Studies.removeStudy(CIQ.stxx, CIQ.stxx.layout.studies[studyInstanceName])
        }

        CIQ.getIndicatorMatedata(indicatorsList)

        //if there's a technical study in indicatorList, remove it before loading chart
        let techList = CIQ.store.state.indicators.technicalIndicators
        let list = []
        for(var i in indicatorsList){
            if(techList.indexOf(indicatorsList[i]) == -1){
                list.push(indicatorsList[i])
            }
        } 

        if(CIQ.store.state.backtestSymbol){
            CIQ.symbol = CIQ.store.state.backtestSymbol
         }
        CIQ.stxx.loadChart(	{ symbol: CIQ.symbol,startDate:new Date(),endDate:new Date(), indicator:list, freqency:arguments[0]}, function () {
            // callback - your code to be executed after the chart is loaded
            CIQ.hideCover()

            //CIQ.loadMessage()
            for (var studyInstanceName in CIQ.stxx.layout.studies) {  
                //console.log(studyInstanceName)                     
                var sd = CIQ.stxx.layout.studies[studyInstanceName];

                //exportEx(sd.chart.scrubbed)
                var panel = CIQ.stxx.panels  
                //panel["‌etf_spy‌ (13,n)"].yAxis.displayGridLines = true;
                //CIQ.stxx.setYAxisPosition(panel["‌etf_spy‌ (13,n)"].yAxis,"left")
                //CIQ.Studies.createYAxis(panel["‌etf_spy‌ (13,n)"],)
                //console.log(panel["‌etf_spy‌ (13,n)"])
                CIQ.stxx.draw();           
            }    
        })
        
}

CIQ.addSymbol = function(symbol){
    // find if there is no items in current studylist
    CIQ.addCover()

    let count = 0
    for (var studyInstanceName in CIQ.stxx.layout.studies) {
        count++
        CIQ.Studies.removeStudy(CIQ.stxx, CIQ.stxx.layout.studies[studyInstanceName])
    }

    let indicatorsList = [CIQ.store.state.indicators.formIndicators.entry,CIQ.store.state.indicators.formIndicators.exit]
    // remove redundant elements and empty string

    for(var i=0;i<indicatorsList.length;i++){
      if(indicatorsList[i]==''){
        indicatorsList.splice(i,1)
        i--;
      }
    }
    indicatorsList = indicatorsList.concat(CIQ.store.state.indicators.extraIndicators)
    const set = new Set(indicatorsList)
    indicatorsList = [...set]

    if(indicatorsList.length==0){
        indicatorsList = ['AAPL']
    }

    if(count>0){
        CIQ.getIndicatorMatedata(indicatorsList)
    } 
    
    // if there's a technical study in indicatorList, remove it before loading chart
    let techList = CIQ.store.state.indicators.technicalIndicators
    for(var i in indicatorsList){
        if(techList.indexOf(indicatorsList[i]) != -1){
            indicatorsList.splice(i,1)
        }
    } 
    CIQ.stxx.loadChart(	{ symbol: symbol,startDate:new Date(),endDate:new Date(), indicator:indicatorsList}, function () {
        // callback - your code to be executed after the chart is loaded  
        CIQ.hideCover()
        for (var studyInstanceName in CIQ.stxx.layout.studies) {             
            var sd = CIQ.stxx.layout.studies[studyInstanceName];

            var panel = CIQ.stxx.panels  
            //panel["‌etf_spy‌ (13,n)"].yAxis.displayGridLines = true;
            //CIQ.stxx.setYAxisPosition(panel["‌etf_spy‌ (13,n)"].yAxis,"left")
            //CIQ.Studies.createYAxis(panel["‌etf_spy‌ (13,n)"],)
            //console.log(panel["‌etf_spy‌ (13,n)"])
            CIQ.stxx.draw();       
        }    
    })
    
}


CIQ.getIndicatorMatedata = function(indicatorList){
    var color = ["rgb(26 139 251)","#7257f2",'black',"#ff8a8a","#f98e23"]

    for (var studyInstanceName in CIQ.stxx.layout.studies) {
        var sd = CIQ.stxx.layout.studies[studyInstanceName];
        
        if (CIQ.studys.indexOf(sd.type) === -1){
            CIQ.Studies.removeStudy(CIQ.stxx, sd);
            
        }
    }
    // for(var i in indicatorList){
    //     let techList = CIQ.store.state.indicators.technicalIndicators
    //     if(techList.indexOf(indicatorList[i]) != -1){
    //         // load built-in study, no need for adding MA
    //         // if it's a built-in study, skip sending query
    //         var sd = CIQ.Studies.addStudy(CIQ.stxx, indicatorList[i],{display:indicatorList[i]});
    //         console.log("indicatorList[i]: "+indicatorList[i])
    //         console.log(sd)
    //         continue
    //     }
    //     var queryUrl =  config.indicatorMetadata + 
    //     "?indicator=" + indicatorList[i];

    //     console.log(queryUrl);
    //     var server = new XMLHttpRequest();   
    //     server.open("GET", queryUrl,false);
    //     server.setRequestHeader("Authorization", "Basic " + btoa(config.username+":"+config.password));  
    //     server.send(null);

    //     if (server.status===200) {
    //         try {
    //                 var newQuotes = JSON.parse(server.response);
    //                 //(newQuotes);
    //                 if (newQuotes !== null){
    //                     var newStudy = {
    //                         inputs: { Period: 13, Overlay: false},
    //                         outputs: 
    //                         {indicatorClose:color[i%3],description: newQuotes.description,url:indicatorList[i]},
    //                         parameters: { init: {
    //                             studyOverZonesEnabled: true,
    //                             studyOverBoughtValue: newQuotes.opt_extreme,
    //                             studyOverBoughtColor: "#FF0000",
    //                             studyOverSoldValue: newQuotes.pess_extreme,
    //                             studyOverSoldColor: "#00DD00",
    //                         }}
    //                     }
                        
    //                         var str = JSON.stringify(newStudy);
    //                         let _obj = CIQ.store.state.indicatorsList.find(x => x.url == indicatorList[i])
    //                         str = str.replace(/indicatorClose/g, indicatorList[i]);
    //                         newStudy = JSON.parse(str)
    //                         console.log(indicatorList);
			                
    //                         CIQ.Studies.studyLibrary[indicatorList[i]] = newStudy
    //                         var sd = CIQ.Studies.addStudy(CIQ.stxx,indicatorList[i])
    //                         console.log(sd)
    //                         var extremeValue = {extremeOptimism:sd.parameters.studyOverBoughtValue,extremePessimism:sd.parameters.studyOverSoldValue}
    //                         CIQ.store.commit("getExtremeValue", extremeValue)
    //                        // stxx.panels[sd.panel].yAxis
                        
    //                 }
    //         }catch (e) {
    //             if (newQuotes !== null){
    //                 var newStudy = {
    //                     inputs: { Period: 13, Overlay: false,},
    //                     outputs: 
    //                     {indicatorClose:color[i%3],description: newQuotes.description,url:indicatorList[i]},
    //                     parameters: { init: {
    //                         studyOverZonesEnabled: true,
    //                         studyOverBoughtValue: 80,
    //                         studyOverBoughtColor: "#FF0000",
    //                         studyOverSoldValue: 20,
    //                         studyOverSoldColor: "#00DD00",
    //                     }}
    //                 }
                    
    //                     var str = JSON.stringify(newStudy);
    //                     str = str.replace(/indicatorClose/g, indicatorList[i]);
                        
    //                     newStudy = JSON.parse(str)
                   
    //                     CIQ.Studies.studyLibrary[indicatorList[i]] = newStudy
    //                     var sd = CIQ.Studies.addStudy(CIQ.stxx,indicatorList[i])
    //                     var extremeValue = {extremeOptimism:sd.parameters.studyOverBoughtValue,extremePessimism:sd.parameters.studyOverSoldValue}
    //                     CIQ.store.commit("getExtremeValue", extremeValue)
    //             }
    //         }
    //     }
    // }
    console.log("indicatorList: ",indicatorList)
    
    var chartBox = document.getElementsByClassName("chart_box")[0]
    var height = 65 + indicatorList.length*15
    chartBox.style.height = height.toString()+ 'vh'

    for(var i in indicatorList){
        let techList = CIQ.store.state.indicators.technicalIndicators

        if(techList.indexOf(indicatorList[i]) != -1){
            // load technical study, no need for adding MA
            // if it's a technical study, skip sending query
            var sd = CIQ.Studies.addStudy(CIQ.stxx, indicatorList[i],{display:indicatorList[i]});
                console.log(sd)

            // var extremeValue = {extremeOptimism:sd.parameters.studyOverBoughtValue,extremePessimism:sd.parameters.studyOverSoldValue}
            // CIQ.store.commit("getExtremeValue", extremeValue) 
            continue
        }
        (function(i){
                var queryUrl =  config.indicatorMetadata + 
                "?indicator=" + indicatorList[i];
    
                //console.log(queryUrl);

                // now it changed to async call
                var server = new XMLHttpRequest();   
                server.open("GET", queryUrl,true);
                server.setRequestHeader("Authorization", "Basic " + btoa(config.username+":"+config.password));  
                server.send(null);
    
                // timeout detector
                server.ontimeout = function(){
                    console.log('request timeout')
                }

                server.onreadystatechange = function(){
                    if(server.readyState == 4){
                        if (server.status===200) {
                            try {
                                // load list from vuex
                                let indicatorsList = [CIQ.store.state.indicators.formIndicators.entry,CIQ.store.state.indicators.formIndicators.exit]
                                for(var k=0;k<indicatorsList.length;k++){
                                  if(indicatorsList[k]==''){
                                    indicatorsList.splice(k,1)
                                    k--;
                                  }
                                }
                                indicatorsList = indicatorsList.concat(CIQ.store.state.indicators.extraIndicators)
                                const set = new Set(indicatorsList)
                                indicatorsList = [...set]
                            
                                if(indicatorsList.length==0){
                                    indicatorsList = ['AAPL']
                                }
                                indicatorList = indicatorsList
                                // console.log("after nreadystatechange: ",indicatorList)
                                // console.log("index i is:",i)
                                    var newQuotes = JSON.parse(server.response);
                                    
                                    if (newQuotes !== null){
                                        var newStudy = {
                                            inputs: { Period: 13, Overlay: false},
                                            outputs: 
                                            {indicatorClose:color[i%5],description: newQuotes.description,url:indicatorList[i]},
                                            parameters: { init: {
                                                studyOverZonesEnabled: true,
                                                studyOverBoughtValue: newQuotes.opt_extreme,
                                                studyOverBoughtColor: "#FF0000",
                                                studyOverSoldValue: newQuotes.pess_extreme,
                                                studyOverSoldColor: "#00DD00",
                                            }},
                                            attributes:{
                                                studyOverBoughtValue:{"step":0.01},
                                                studyOverSoldValue:{"step":0.01}
                                            }
                                        }
                                        
                                            var str = JSON.stringify(newStudy);                                   
                                            str = str.replace(/indicatorClose/g, indicatorList[i]);
                                            newStudy = JSON.parse(str)                                     
                                            
                                            CIQ.Studies.studyLibrary[indicatorList[i]] = newStudy
                                            var sd = CIQ.Studies.addStudy(CIQ.stxx,indicatorList[i])
                                            var newExtremeValue = {indicator:indicatorList[i],extremeOptimism:sd.parameters.studyOverBoughtValue,extremePessimism:sd.parameters.studyOverSoldValue}
                                            var extremeValueList = CIQ.store.state.extremeValue
                                        
                                            if(!extremeValueList.some((item)=>{return item.indicator == newExtremeValue.indicator})){
                                                
                                                extremeValueList.push(newExtremeValue)
                                            }
                                            console.log('curremt extremeValueList is: ',extremeValueList)
                                            CIQ.store.commit("getExtremeValue", extremeValueList)
                                            console.log(sd)
                                        // stxx.panels[sd.panel].yAxis
                                        
                                    }
                            }catch (e) {
                                if (newQuotes !== null){
                                    var newStudy = {
                                        inputs: { Period: 13, Overlay: false,},
                                        outputs: 
                                        {indicatorClose:color[i%5],description: newQuotes.description,url:indicatorList[i]},
                                        parameters: { init: {
                                            studyOverZonesEnabled: true,
                                            studyOverBoughtValue: 80,
                                            studyOverBoughtColor: "#FF0000",
                                            studyOverSoldValue: 20,
                                            studyOverSoldColor: "#00DD00",
                                        }},
                                        attributes:{
                                            studyOverBoughtValue:{"step":0.01},
                                            studyOverSoldValue:{"step":0.01}
                                        }
                                    }
                                    
                                    var str = JSON.stringify(newStudy);                                   
                                    str = str.replace(/indicatorClose/g, indicatorList[i]);
                                    newStudy = JSON.parse(str)                                     
                                    
                                    CIQ.Studies.studyLibrary[indicatorList[i]] = newStudy
                                    var sd = CIQ.Studies.addStudy(CIQ.stxx,indicatorList[i])
                                    var newExtremeValue = {indicator:indicatorList[i],extremeOptimism:sd.parameters.studyOverBoughtValue,extremePessimism:sd.parameters.studyOverSoldValue}
                                    var extremeValueList = CIQ.store.state.extremeValue
                                
                                    if(!extremeValueList.some((item)=>{return item.indicator == newExtremeValue.indicator})){
                                        
                                        extremeValueList.push(newExtremeValue)
                                    }
                                    console.log('curremt extremeValueList is: ',extremeValueList)
                                    CIQ.store.commit("getExtremeValue", extremeValueList)
                                    console.log(sd)
                                }
                            }
                        }else{
                            console.error(server.statusText)
                        }
                    }
                }
                
                server.onerror = function(e){
                    console.error(server.statusText)
                }
            }

        )(i)
    }
    //console.log(CIQ.store.state.activatedMA)
                            
    for(var i in CIQ.store.state.activatedMA){
        if(CIQ.store.state.activatedMA[i].url != ''){
            if(CIQ.store.state.activatedMA[i].url == 'ma'){
                // 直接加载，信息都更新再studylibrary
                var sd = CIQ.Studies.addStudy(CIQ.stxx, 'ST MA', {
                    // Type: CIQ.store.state.activatedMA[i].type,
                    Period: CIQ.store.state.activatedMA[i].period,
					display: 'ST MA',
				})
               // console.log('st ma: ',sd)
            }else{
                sd = CIQ.Studies.addStudy(CIQ.stxx, "ST MA",{Period: CIQ.store.state.activatedMA[i].period,display:"ST MA",Field: CIQ.store.state.activatedMA[i].url});
            }    
        }   
    }
}

// download study data
function exportEx(val){
    let JSONData = val;
    
    //先转化json
    let arrData = typeof JSONData != 'object' ? JSON.parse(JSONData) : JSONData;
    let ShowLabel = Object.keys(arrData[1000]);
    //console.log(arrData)
    // 给数组内容换好位置
    let finalData = [];

    arrData.forEach(item => {
        //console.log(item)
    //   let obj = {
    //     Symbol: item[Object.keys(item)[0]],
    //     Close: item.Close ? item.Close : '',
    //     Date: item.Date,
    //     High: item.High,
    //     Low: item.Low,
    //     MA: item[Object.keys(item)[6]],
    //     Open: item.Open,
    //     Result: item[Object.keys(item)[8]],
    //     Volume: item.Volume,
    //   };
      finalData.push(item);
    });
    let excel = '<table>';
    //设置表头
    let row = '<tr>';
    for (let i = 0; i < ShowLabel.length; i++) {
      row += '<td>' + ShowLabel[i] + '</td>';
    }
    //换行
    excel += row + '</tr>';
    //设置数据
    for (let i = 0; i < finalData.length; i++) {
      let row = '<tr>';
      for (let index in finalData[i]) {
        let value = finalData[i][index];
        if (index === 'Date' || index === 'MA ‌ST CCI‌ (20)' || index === 'Result ‌ST CCI‌ (20)') {
          // 当数字超过一定长度就科学计数法可以使用style='mso-number-format:"\@"'
          // 这个属性指定某单元格的数据格式，避免Excel自动转换格式
          row += `<td style='mso-number-format:\"\\@\"'>${value}</td>`;
        } else {
          row += '<td>' + value + '</td>';
        }
      }
      excel += row + '</tr>';
    }
    excel += '</table>';
    let excelFile =
      "<html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:x='urn:schemas-microsoft-com:office:excel' xmlns='http://www.w3.org/TR/REC-html40'>";
    excelFile +=
      '<meta http-equiv="content-type" content="application/vnd.ms-excel; charset=UTF-8">';
    excelFile += '<meta http-equiv="content-type" content="application/vnd.ms-excel';
    excelFile += '; charset=UTF-8">';
    excelFile += '<head>';
    excelFile += '<!--[if gte mso 9]>';
    excelFile += '<xml>';
    excelFile += '<x:ExcelWorkbook>';
    excelFile += '<x:ExcelWorksheets>';
    excelFile += '<x:ExcelWorksheet>';
    excelFile += '<x:Name>';
    excelFile += '{worksheet}';
    excelFile += '</x:Name>';
    excelFile += '<x:WorksheetOptions>';
    excelFile += '<x:DisplayGridlines/>';
    excelFile += '</x:WorksheetOptions>';
    excelFile += '</x:ExcelWorksheet>';
    excelFile += '</x:ExcelWorksheets>';
    excelFile += '</x:ExcelWorkbook>';
    excelFile += '</xml>';
    excelFile += '<![endif]-->';
    excelFile += '</head>';
    excelFile += '<body>';
    excelFile += excel;
    excelFile += '</body>';
    excelFile += '</html>';
    let uri = 'data:application/vnd.ms-excel;charset=utf-8,' + encodeURIComponent(excelFile);
    let link = document.createElement('a');
    link.href = uri;
    link.style = 'visibility:hidden';
    link.download = '文件.xls';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    this.setState({
      errorMsgVisible: false,
    });
    
  };

export {CIQ}