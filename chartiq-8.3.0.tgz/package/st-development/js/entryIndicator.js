import {CIQ} from "../../js/chartiq.js"
import {config} from "../feeds/STDataFeedAccessUrl.js"
import store from '../../../../src/store/store.ts'

CIQ.addIndicators = async function(){
    // set indicatorList to local storage, fetch it when change a symbol
    let result = await new Promise((resolve, reject) => {
        let indicatorsList = [store.state.indicators.formIndicators.entry,store.state.indicators.formIndicators.exit]
          // remove redundant elements and empty string

          for(var i=0;i<indicatorsList.length;i++){
            if(indicatorsList[i]==''){
              indicatorsList.splice(i,1)
              i--;
            }
          }
        indicatorsList = indicatorsList.concat(store.state.indicators.extraIndicators)
        const set = new Set(indicatorsList)
        indicatorsList = [...set]

        for (var studyInstanceName in CIQ.stxx.layout.studies) {
            CIQ.Studies.removeStudy(CIQ.stxx, CIQ.stxx.layout.studies[studyInstanceName])
        }
        
        CIQ.stxx.loadChart(	{ symbol: CIQ.symbol,startDate:new Date(),endDate:new Date(), indicator:indicatorsList},)

        CIQ.getIndicatorMatedata(indicatorsList)
        //CIQ.Studies.drawZones(CIQ.stxx, CIQ.stxx.layout.studies[studyInstanceName])
        
    } )
    //alert(result);  
}

CIQ.addSymbol = function(symbol){
    let indicatorsList = [store.state.indicators.formIndicators.entry,store.state.indicators.formIndicators.exit]
    // remove redundant elements and empty string

    for(var i=0;i<indicatorsList.length;i++){
      if(indicatorsList[i]==''){
        indicatorsList.splice(i,1)
        i--;
      }
    }
    indicatorsList = indicatorsList.concat(store.state.indicators.extraIndicators)
    const set = new Set(indicatorsList)
    indicatorsList = [...set]

    if(indicatorsList.length==0){
        indicatorsList = [symbol]
    }
    
    // find if there is no items in current studylist
    let count = 0
    for (var studyInstanceName in CIQ.stxx.layout.studies) {
        count++
        CIQ.Studies.removeStudy(CIQ.stxx, CIQ.stxx.layout.studies[studyInstanceName])
    }
    ////(count)
    CIQ.stxx.loadChart(	{ symbol: symbol,startDate:new Date(),endDate:new Date(), indicator:indicatorsList},)
    if(count>0){
        CIQ.getIndicatorMatedata(indicatorsList)
    } 
}


CIQ.getIndicatorMatedata = function(indicatorList){
    var color = ["#00DD00","#FF0000",'black']
    for (var studyInstanceName in CIQ.stxx.layout.studies) {
        
        var sd = CIQ.stxx.layout.studies[studyInstanceName];
        if (CIQ.studys.indexOf(sd.type) === -1){
            CIQ.Studies.removeStudy(CIQ.stxx, sd);
        }
    }
        
    for(var i in indicatorList){
        var queryUrl =  config.indicatorMetadata + 
        "?indicator=" + indicatorList[i];

        //(queryUrl);
        var server = new XMLHttpRequest();   
        server.open("GET", queryUrl,false);
        server.setRequestHeader("Authorization", "Basic " + btoa(config.username+":"+config.password));  
        server.send(null);

        if (server.status===200) {
            try {
                    var newQuotes = JSON.parse(server.response);
                    //(newQuotes);
                    if (newQuotes !== null){
                        var newStudy = {
                            inputs: { Period: 13, Overlay: false,},
                            outputs: 
                            {indicatorClose:color[i%3],description: newQuotes.description,url:indicatorList[i]},
                            parameters: { init: {
                                studyOverZonesEnabled: true,

                                studyOverBoughtValue: newQuotes.opt_extreme,
                                studyOverBoughtColor: "#FF0000",
                                studyOverSoldValue: newQuotes.pess_extreme,
                                studyOverSoldColor: "#00DD00",
                            }}
                        }
                        
                            var str = JSON.stringify(newStudy);
                            str = str.replace(/indicatorClose/g, indicatorList[i]);
                            newStudy = JSON.parse(str)
                       
                        //(newStudy);
                        CIQ.Studies.studyLibrary[indicatorList[i]] = newStudy
                        CIQ.Studies.addStudy(CIQ.stxx,indicatorList[i])
                        //(CIQ.stxx.layout.studies)
                    }
            }catch (e) {
                if (newQuotes !== null){
                    var newStudy = {
                        inputs: { Period: 13, Overlay: false,},
                        outputs: 
                        {indicatorClose:color[i%3],description: newQuotes.description,url:indicatorList[i]},
                        parameters: { init: {
                            studyOverZonesEnabled: true,
                            studyOverBoughtValue: 80,
                            studyOverBoughtColor: "#FF0000",
                            studyOverSoldValue: 20,
                            studyOverSoldColor: "#00DD00",
                        }}
                    }
                    
                        var str = JSON.stringify(newStudy);
                        str = str.replace(/indicatorClose/g, indicatorList[i]);
                        newStudy = JSON.parse(str)
                   
                    ////(newStudy);
                    CIQ.Studies.studyLibrary[indicatorList[i]] = newStudy
                    CIQ.Studies.addStudy(CIQ.stxx,indicatorList[i])
                    //(CIQ.stxx.layout.studies)
                }
            }
        }
    }
}

export {CIQ}