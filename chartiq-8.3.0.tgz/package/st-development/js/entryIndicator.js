import {CIQ} from "../../js/chartiq.js"
import {config} from "../feeds/STDataFeedAccessUrl.js"
//import store from '../../../../src/store/store.ts'
import "./STMovingAverages"

CIQ.addIndicators = function(){
    // set indicatorList to local storage, fetch it when change a symbol
        let indicatorsList = [CIQ.store.state.indicators.formIndicators.entry,CIQ.store.state.indicators.formIndicators.exit]
          // remove redundant elements and empty string
          for(var i=0;i<indicatorsList.length;i++){
            if(indicatorsList[i]==''){
              indicatorsList.splice(i,1)
              i--;
            }
          }
        indicatorsList = indicatorsList.concat(CIQ.store.state.indicators.extraIndicators)
        const set = new Set(indicatorsList)
        indicatorsList = [...set]

        // we can have multiple redundant studies 
        // let indicatorsListWithTech = indicatorsList.concat(CIQ.store.state.indicators.technicalIndicators)
        console.log(indicatorsList)

        for (var studyInstanceName in CIQ.stxx.layout.studies) {
            CIQ.Studies.removeStudy(CIQ.stxx, CIQ.stxx.layout.studies[studyInstanceName])
        }
        CIQ.getIndicatorMatedata(indicatorsList,arguments[0])
        // if there's a built-in study in indicatorList, remove it before loading chart
        let techList = CIQ.store.state.indicators.technicalIndicators
        for(var i in indicatorsList){
            if(techList.indexOf(indicatorsList[i]) != -1){
                indicatorsList.splice(i,1)
            }
        } 
        CIQ.stxx.loadChart(	{ symbol: CIQ.symbol,startDate:new Date(),endDate:new Date(), indicator:indicatorsList}, function () {
            // callback - your code to be executed after the chart is loaded
            alert("Load sucess")
            CIQ.hideMarker()
            for (var studyInstanceName in CIQ.stxx.layout.studies) {                  
                var sd = CIQ.stxx.layout.studies[studyInstanceName];

                var panel = CIQ.stxx.panels  
                //panel["‌etf_spy‌ (13,n)"].yAxis.displayGridLines = true;
                //CIQ.stxx.setYAxisPosition(panel["‌etf_spy‌ (13,n)"].yAxis,"left")
                //CIQ.Studies.createYAxis(panel["‌etf_spy‌ (13,n)"],)
                //console.log(panel["‌etf_spy‌ (13,n)"])
                CIQ.stxx.draw();
                
            }
           
            
        })
}

// CIQ.addTechIndicators = function(){
//     let techIndicator = CIQ.store.state.indicators.technicalIndicators
//     for (var field in CIQ.Studies.studyLibrary) {
//         for(var i in techIndicator){
//             if(CIQ.Studies.studyLibrary[field].name == techIndicator[i]){
//                 var sd = CIQ.Studies.addStudy(CIQ.stxx, field,{display:techIndicator[i]});
//             }
            
//         }
//     }
   
// }

CIQ.addSymbol = function(symbol){
    let indicatorsList = [CIQ.store.state.indicators.formIndicators.entry,CIQ.store.state.indicators.formIndicators.exit]
    // remove redundant elements and empty string

    for(var i=0;i<indicatorsList.length;i++){
      if(indicatorsList[i]==''){
        indicatorsList.splice(i,1)
        i--;
      }
    }
    indicatorsList = indicatorsList.concat(CIQ.store.state.indicators.extraIndicators)
    const set = new Set(indicatorsList)
    indicatorsList = [...set]

    if(indicatorsList.length==0){
        indicatorsList = [symbol]
    }

    // find if there is no items in current studylist
    let count = 0
    for (var studyInstanceName in CIQ.stxx.layout.studies) {
        count++
        CIQ.Studies.removeStudy(CIQ.stxx, CIQ.stxx.layout.studies[studyInstanceName])
    }
   
    CIQ.stxx.loadChart(	{ symbol: symbol,startDate:new Date(),endDate:new Date(), indicator:indicatorsList},)
    if(count>0){
        CIQ.getIndicatorMatedata(indicatorsList)
    } 
}


CIQ.getIndicatorMatedata = function(indicatorList,period){
    var color = ["#00DD00","#FF0000",'black']
    for (var studyInstanceName in CIQ.stxx.layout.studies) {
        var sd = CIQ.stxx.layout.studies[studyInstanceName];
        
        if (CIQ.studys.indexOf(sd.type) === -1){
            CIQ.Studies.removeStudy(CIQ.stxx, sd);
            
        }
    }
    for(var i in indicatorList){
        let techList = CIQ.store.state.indicators.technicalIndicators
        if(techList.indexOf(indicatorList[i]) != -1){
            // load built-in study, no need for adding MA
            // if it's a built-in study, skip sending query
            var sd = CIQ.Studies.addStudy(CIQ.stxx, indicatorList[i],{display:indicatorList[i]});
            continue
        }
        var queryUrl =  config.indicatorMetadata + 
        "?indicator=" + indicatorList[i];

        console.log(queryUrl);
        var server = new XMLHttpRequest();   
        server.open("GET", queryUrl,false);
        server.setRequestHeader("Authorization", "Basic " + btoa(config.username+":"+config.password));  
        server.send(null);

        if (server.status===200) {
            try {
                    var newQuotes = JSON.parse(server.response);
                    //(newQuotes);
                    if (newQuotes !== null){
                        var newStudy = {
                            inputs: { Period: 13, Overlay: false},
                            outputs: 
                            {indicatorClose:color[i%3],description: newQuotes.description,url:indicatorList[i]},
                            parameters: { init: {
                                studyOverZonesEnabled: true,
                                studyOverBoughtValue: newQuotes.opt_extreme,
                                studyOverBoughtColor: "#FF0000",
                                studyOverSoldValue: newQuotes.pess_extreme,
                                studyOverSoldColor: "#00DD00",
                            }}
                        }
                        
                            var str = JSON.stringify(newStudy);
                            str = str.replace(/indicatorClose/g, indicatorList[i]);
                            newStudy = JSON.parse(str)

                            CIQ.Studies.studyLibrary[indicatorList[i]] = newStudy
                            var sd = CIQ.Studies.addStudy(CIQ.stxx,indicatorList[i])

                            for(var i in CIQ.store.state.activatedMA){
                                CIQ.Studies.addStudy(CIQ.stxx, "ST MA",{Period: CIQ.store.state.activatedMA[i].period,display:"ST MA",Field: CIQ.store.state.activatedMA[i].url});
                            }
                           // stxx.panels[sd.panel].yAxis
                        
                    }

                    // Once a study is added to the layout, the function is automatically called whenever the dataSet is recreated, 
                    // which is whenever there is a change to the chart's data (e.g, when the quotefeed updates). 
                    // The function can also be called manually to generate data in the dataSet;
                    // if (newQuotes !== null){
                    //     var newStudy = {
                    //         name: "Moving Average",
                    //         overlay: false,
                    //         calculateFN: CIQ.Studies.calculateSTMovingAverage,
                    //         inputs: { Period: 50, Field: "model_dumb_money", Type: "ma", Offset: 0 },
                    //         outputs: 
                    //         {MA: "#FF0000",model_dumb_money:color[i%3],description: newQuotes.description,url:indicatorList[i]},
                    //         parameters: { init: {
                    //             studyOverZonesEnabled: true,
                    //             studyOverBoughtValue: newQuotes.opt_extreme,
                    //             studyOverBoughtColor: "#FF0000",
                    //             studyOverSoldValue: newQuotes.pess_extreme,
                    //             studyOverSoldColor: "#00DD00",
                    //         }}
                    //     }
                        
                    //         // var str = JSON.stringify(newStudy);
                    //         // str = str.replace(/indicatorClose/g, indicatorList[i]);
                    //         // newStudy = JSON.parse(str)

                    //     CIQ.Studies.studyLibrary[indicatorList[i]] = newStudy
                    //     var sd = CIQ.Studies.addStudy(CIQ.stxx,indicatorList[i])
                    //     console.log(CIQ.Studies.studyLibrary)
                    //     console.log(sd)
                        
                    // }
            }catch (e) {
                if (newQuotes !== null){
                    var newStudy = {
                        inputs: { Period: 13, Overlay: false,},
                        outputs: 
                        {indicatorClose:color[i%3],description: newQuotes.description,url:indicatorList[i]},
                        parameters: { init: {
                            studyOverZonesEnabled: true,
                            studyOverBoughtValue: 80,
                            studyOverBoughtColor: "#FF0000",
                            studyOverSoldValue: 20,
                            studyOverSoldColor: "#00DD00",
                        }}
                    }
                    
                        var str = JSON.stringify(newStudy);
                        str = str.replace(/indicatorClose/g, indicatorList[i]);
                        newStudy = JSON.parse(str)
                   
                        CIQ.Studies.studyLibrary[indicatorList[i]] = newStudy
                        var sd = CIQ.Studies.addStudy(CIQ.stxx,indicatorList[i])

                        for(var i in CIQ.store.state.activatedMA){
                            CIQ.Studies.addStudy(CIQ.stxx, "ST MA",{Period: CIQ.store.state.activatedMA[i].period,display:"ST MA",Field: CIQ.store.state.activatedMA[i].url});
                        }
                }
            }
        }
    }
    
}

export {CIQ}