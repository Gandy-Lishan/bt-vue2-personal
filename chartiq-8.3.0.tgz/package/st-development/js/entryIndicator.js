import {CIQ} from "../../js/chartiq.js"
import {config} from "../feeds/STDataFeedAccessUrl.js"
import "./STMovingAverages"
CIQ.Tooltip =
CIQ.Tooltip ||
function (tooltipParams) {
    if (!CIQ.Marker) {
        console.warn(
            "CIQ.Tooltip addon requires CIQ.Marker module to be enabled."
        );
        return;
    }

    this.cssRequired = true;

    const {
        stx,
        ohl: showOhl,
        change: showChange,
        volume: showVolume,
        series: showSeries,
        studies: showStudies,
        interpolation: showInterpolation,
        showOverBarOnly,
        showBarHighlight = true,
        useDataZone
    } = tooltipParams;
    const { container } = stx.chart;

    let node = container.querySelector("stx-hu-sttooltip");
    if (!node) {
        node = document.createElement("stx-hu-sttooltip");
        container.appendChild(node);
    }

    let highlightEl = container.querySelector(".stx-hu-tooltip-highlight");
    if (!highlightEl) {
        highlightEl = document.createElement("div");
        highlightEl.classList.add("stx-hu-tooltip-highlight");
        container.appendChild(highlightEl);
    }

    CIQ.Marker.Tooltip = function (params) {
        if (!this.className) this.className = "CIQ.Marker.Tooltip";
        this.highlightEl = highlightEl;
        params.label = "tooltip";
        CIQ.Marker.call(this, params);
    };

    CIQ.inheritsFrom(CIQ.Marker.Tooltip, CIQ.Marker, false);

    CIQ.Marker.Tooltip.sameBar = function (bar1, bar2) {
        if (!bar1 || !bar2) return false;
        if (+bar1.DT != +bar2.DT) return false;
        if (bar1.Close != bar2.Close) return false;
        if (bar1.Open != bar2.Open) return false;
        if (bar1.Volume != bar2.Volume) return false;
        return true;
    };

    CIQ.Marker.Tooltip.placementFunction = function (params) {
        if (hideIfDisabled()) return;
        var offset = 30;
        var stx = params.stx;
        for (var i = 0; i < params.arr.length; i++) {
            var marker = params.arr[i];
            var bar = stx.barFromPixel(stx.cx);
            var quote = stx.chart.dataSegment[bar];
            var goodBar;
            var overBar = true;
            var highPx, lowPx;

            if (quote != "undefined" && quote && quote.DT) {
                goodBar = true;
                if (quote.High) highPx = stx.pixelFromPrice(quote.High);
                if (quote.Low) lowPx = stx.pixelFromPrice(quote.Low);
                if (!stx.chart.highLowBars) {
                    if (quote.Close) {
                        highPx = stx.pixelFromPrice(quote.Close) - 15;
                        lowPx = stx.pixelFromPrice(quote.Close) + 15;
                    }
                }
                if (showOverBarOnly && !(stx.cy >= highPx && stx.cy <= lowPx))
                    overBar = false;
            }

            if (
                !(
                    stx.insideChart &&
                    !stx.openDialog &&
                    !stx.activeDrawing &&
                    !stx.grabbingScreen &&
                    goodBar &&
                    overBar
                )
            ) {
                highlightEl.style.display = "none";
                marker.node.style.left = "-50000px";
                marker.node.style.right = "auto";
                marker.lastBar = {};
                return;
            }
            if (
                CIQ.Marker.Tooltip.sameBar(
                    stx.chart.dataSegment[bar],
                    marker.lastBar
                ) &&
                bar != stx.chart.dataSegment.length - 1
            ) {
                return;
            }

            marker.lastBar = stx.chart.dataSegment[bar];
            var cw = marker.lastBar.candleWidth || stx.layout.candleWidth;
            if (
                parseInt(getComputedStyle(marker.node).width, 10) +
                    stx.chart.panel.left +
                    offset +
                    cw <
                stx.backOutX(CIQ.ChartEngine.crosshairX)
            ) {
                marker.node.style.left = "auto";
                marker.node.style.right =
                    Math.round(
                        container.clientWidth - stx.pixelFromBar(bar) + offset
                    ) + "px";
            } else {
                marker.node.style.left =
                    Math.round(stx.pixelFromBar(bar) + offset) + "px";
                marker.node.style.right = "auto";
            }
            var height = parseInt(getComputedStyle(marker.node).height, 10);
            var top = Math.round(
                CIQ.ChartEngine.crosshairY - stx.top - height / 2
            );
            if (top + height > stx.height) top = stx.height - height;
            if (top < 0) top = 0;
            marker.node.style.top = top + "px";

            if (showBarHighlight && !stx.layout.crosshair) {
                const candleWidth =
                    marker.lastBar.candleWidth || stx.layout.candleWidth;
                const left = stx.pixelFromBar(bar) - candleWidth / 2;
                let width = candleWidth;

                if (left + width > stx.chart.width) {
                    // adjust width of last bar so it does not highlight past the edge of the chart into the y axis
                    width = stx.chart.width - left;
                }

                highlightEl.style.display = "block";
                highlightEl.style.left = left + "px";
                highlightEl.style.width = width + "px";
            } else {
                highlightEl.style.display = "none";
            }
        }
        // backwards compatibility
        // temporarily disable overXAxis, overYAxis so the crosshairs don't hide if touch device and over Y axis (this can happen
        // due to the offset which we apply)
        if (stx.layout.crosshair) {
            var overXAxis = stx.overXAxis,
                overYAxis = stx.overYAxis;
            stx.overXAxis = stx.overYAxis = false;
            stx.doDisplayCrosshairs();
            stx.overXAxis = overXAxis;
            stx.overYAxis = overYAxis;
        }
    };

    function hideIfDisabled() {
        const { headsUp, crosshair } = stx.layout;
        const isFloating =
            (headsUp && headsUp.floating) || headsUp === "floating";

        const crosshairsOn =
            crosshair &&
            stx.displayCrosshairs &&
            ["static", null, undefined].includes(headsUp); // backwards compatibility

        if (stx.huTooltip && !isFloating && !crosshairsOn) {
            hideTooltip();
            return true;
        }

        return false;
    }

    function hideTooltip() {
        const { huTooltip } = stx;
        const { node } = huTooltip;
        if (!node) return;
        node.style.left = "-50000px";
        node.style.right = "auto";
        huTooltip.lastBar = {};
        if (huTooltip.highlightEl) huTooltip.highlightEl.style.display = "none";
    }

    function renderFunction() {
        // the tooltip has not been initialized with this chart.
        if (hideIfDisabled()) return;

        var bar = this.barFromPixel(this.cx),
            data = this.chart.dataSegment[bar];
        if (!data) {
            hideTooltip();
            return;
        }
        if (
            CIQ.Marker.Tooltip.sameBar(data, this.huTooltip.lastBar) &&
            bar != this.chart.dataSegment.length - 1
        ) {
            return;
        }
        var node = this.huTooltip.node;
        Array.from(node.parentElement.querySelectorAll("[auto]")).forEach(
            function (i) {
                i.remove();
            }
        );
        Array.from(
            node.parentElement.querySelectorAll("stx-hu-tooltip-field-value")
        ).forEach(function (i) {
            i.innerHTML = "";
        });

        var panel = this.chart.panel;
        var yAxis = panel.yAxis;
        var dupMap = {};
        var fields = [];
        fields.push({
            member: "DT",
            display: "DT",
            panel: panel,
            yAxis: yAxis
        });
        fields.push({
            member: "Close",
            display: "Close",
            panel: panel,
            yAxis: yAxis
        });
        dupMap.DT = dupMap.Close = 1;
        if (
            showChange &&
            CIQ.ChartEngine.isDailyInterval(this.layout.interval)
        ) {
            fields.push({
                member: "Change",
                display: "Change",
                panel: panel,
                yAxis: yAxis
            });
        }
        if (showOhl) {
            fields.push({
                member: "Open",
                display: "Open",
                panel: panel,
                yAxis: yAxis
            });
            fields.push({
                member: "High",
                display: "High",
                panel: panel,
                yAxis: yAxis
            });
            fields.push({
                member: "Low",
                display: "Low",
                panel: panel,
                yAxis: yAxis
            });
            dupMap.Open = dupMap.High = dupMap.Low = 1;
        }
        if (showVolume) {
            fields.push({
                member: "Volume",
                display: "Volume",
                panel: null,
                yAxis: null
            }); // null yAxis use raw value
            dupMap.Volume = 1;
        }
        if (showSeries) {
            var renderers = this.chart.seriesRenderers;
            for (var renderer in renderers) {
                var rendererToDisplay = renderers[renderer];
                if (rendererToDisplay === this.mainSeriesRenderer) continue;
                panel = this.panels[rendererToDisplay.params.panel];
                yAxis = rendererToDisplay.params.yAxis;
                if (!yAxis && rendererToDisplay.params.shareYAxis)
                    yAxis = panel.yAxis;
                for (var id = 0; id < rendererToDisplay.seriesParams.length; id++) {
                    var seriesParams = rendererToDisplay.seriesParams[id];
                    // if a series has a symbol and a field then it maybe a object chain
                    var sKey = seriesParams.symbol;
                    var subField = seriesParams.field;
                    if (!sKey) sKey = subField;
                    else if (subField && sKey != subField)
                        sKey = CIQ.createObjectChainNames(sKey, subField)[0];
                    var display =
                        seriesParams.display ||
                        seriesParams.symbol ||
                        seriesParams.field;
                    if (sKey && !dupMap[display]) {
                        fields.push({
                            member: sKey,
                            display: display,
                            panel: panel,
                            yAxis: yAxis,
                            isSeries: true
                        });
                        dupMap[display] = 1;
                    }
                }
            }
        }
        if (showStudies) {
            for (var study in this.layout.studies) {
                var sd = this.layout.studies[study];
                panel = this.panels[sd.panel];
                yAxis = panel && sd.getYAxis(this);
                let _obj2 = CIQ.store.state.builtinList.find(x=> x.url == this.layout.studies[study].type)
                for (var output in this.layout.studies[study].outputMap) {
                    // dumb way to show full name of indicator
                    let _obj = CIQ.store.state.indicatorsList.find(x => x.url == output)
                    if(_obj){
                        fields.push({
                            member: output,
                            display: _obj.chart_name,
                            panel: panel,
                            yAxis: yAxis
                        });
                        dupMap[output] = 1;
                    }else if(_obj2){
                        fields.push({
                            member: output,
                            display: _obj2.value,
                            panel: panel,
                            yAxis: yAxis
                        });
                        dupMap[output] = 1;
                    }
                    else if (output && !dupMap[output]) {
                        fields.push({
                            member: output,
                            display: output,
                            panel: panel,
                            yAxis: yAxis
                        });
                        dupMap[output] = 1;
                    }
                }
                
                if (!dupMap[study + "_hist"]) {
                    fields.push({
                        member: study + "_hist",
                        display: study + "_hist",
                        panel: panel,
                        yAxis: yAxis
                    });
                    fields.push({
                        member: study + "_hist1",
                        display: study + "_hist1",
                        panel: panel,
                        yAxis: yAxis
                    });
                    fields.push({
                        member: study + "_hist2",
                        display: study + "_hist2",
                        panel: panel,
                        yAxis: yAxis
                    });
                    dupMap[study + "_hist"] = 1;
                }
            }
        }
        for (var f = 0; f < fields.length; f++) {
            var obj = fields[f];
            
            var name = obj.member;
            var displayName = obj.display;
            var isRecordDate = name == "DT";
            if (
                isRecordDate &&
                !useDataZone &&
                !CIQ.ChartEngine.isDailyInterval(stx.layout.interval)
            )
                name = "displayDate"; // display date is timezone adjusted
            panel = obj.panel;
            yAxis = obj.yAxis;
            var labelDecimalPlaces = null;
            if (yAxis) {
                if (!panel || panel !== panel.chart.panel) {
                    // If a study panel, use yAxis settings to determine decimal places
                    if (yAxis.decimalPlaces || yAxis.decimalPlaces === 0)
                        labelDecimalPlaces = yAxis.decimalPlaces;
                    else if (yAxis.maxDecimalPlaces || yAxis.maxDecimalPlaces === 0)
                        labelDecimalPlaces = yAxis.maxDecimalPlaces;
                } else {
                    // If a chart panel, then always display at least the number of decimal places as calculated by masterData (panel.chart.decimalPlaces)
                    // but if we are zoomed to high granularity then expand all the way out to the y-axis significant digits (panel.yAxis.printDecimalPlaces)
                    labelDecimalPlaces = Math.max(
                        yAxis.printDecimalPlaces,
                        panel.chart.decimalPlaces
                    );
                    //	... and never display more decimal places than the symbol is supposed to be quoting at
                    if (yAxis.maxDecimalPlaces || yAxis.maxDecimalPlaces === 0){
                        labelDecimalPlaces = Math.min(
                            labelDecimalPlaces,
                            yAxis.maxDecimalPlaces
                        );
                    }
                }
                labelDecimalPlaces = 2
            }
            var dsField = null;
            // account for object chains
            var tuple = CIQ.existsInObjectChain(data, name);
            if (tuple) dsField = tuple.obj[tuple.member];
            else if (name == "Change") dsField = data.Close - data.iqPrevClose;
            
            var fieldName = displayName.replace(/^(Result )(.*)/, "$2");
            
            if (
                showInterpolation &&
                fields[f].isSeries &&
                (dsField === null || typeof dsField == "undefined")
            ) {
                // do this only for additional series and not the main series
                
                var seriesPrice = this.valueFromInterpolation(
                    bar,
                    fieldName,
                    "Close",
                    panel,
                    yAxis
                );
                if (seriesPrice === null) break;
                dsField = seriesPrice;
            }
            if (
                (dsField || dsField === 0) &&
                (isRecordDate ||
                    typeof dsField !== "object" ||
                    dsField.Close ||
                    dsField.Close === 0)
            ) {
                var fieldValue = "";
                if (dsField.Close || dsField.Close === 0) dsField = dsField.Close;
                if (dsField.constructor == Number) {
                    
                    if (!yAxis) {
                        // raw value
                        fieldValue = dsField;
                        
                        var intl = this.internationalizer;
                        if (intl) {
                            var l = intl.priceFormatters.length;
                            var decimalPlaces = CIQ.countDecimals(fieldValue);
                            if (decimalPlaces >= l) decimalPlaces = l - 1;
                            fieldValue = intl.priceFormatters[decimalPlaces].format(
                                fieldValue
                            );
                            
                        }
                    } else if (
                        yAxis.originalPriceFormatter &&
                        yAxis.originalPriceFormatter.func
                    ) {
                        // in comparison mode with custom formatter
                        fieldValue = yAxis.originalPriceFormatter.func(
                            this,
                            panel,
                            dsField,
                            labelDecimalPlaces
                        );
                        
                    } else if (
                        yAxis.priceFormatter &&
                        yAxis.priceFormatter != CIQ.Comparison.priceFormat
                    ) {
                        // using custom formatter
                        fieldValue = yAxis.priceFormatter(
                            this,
                            panel,
                            dsField,
                            labelDecimalPlaces
                        );
                    } else {
                        //console.log(dsField + ' with ' + labelDecimalPlaces)
                        fieldValue = this.formatYAxisPrice(
                            dsField,
                            panel,
                            labelDecimalPlaces,
                            yAxis
                        );
                        
                    }
                } else if (dsField.constructor == Date) {
                    if (
                        isRecordDate &&
                        this.controls.floatDate &&
                        this.controls.floatDate.innerHTML
                    ) {
                        if (this.chart.xAxis.noDraw) fieldValue = "N/A";
                        else
                            fieldValue = CIQ.displayableDate(this, panel.chart, dsField);
                    } else {
                        fieldValue = CIQ.yyyymmdd(dsField);
                        if (!CIQ.ChartEngine.isDailyInterval(this.layout.interval)) {
                            fieldValue += " " + dsField.toTimeString().substr(0, 8);
                        }
                    }
                } else {
                    fieldValue = dsField;
                    
                }
                var dedicatedField = node.querySelector(
                    'stx-hu-tooltip-field[field="' + fieldName + '"]'
                );

                if (dedicatedField) {
                    dedicatedField.querySelector(
                        "stx-hu-tooltip-field-value"
                    ).innerHTML = fieldValue;
                    
                    var fieldNameField = dedicatedField.querySelector(
                        "stx-hu-tooltip-field-name"
                    );
                    if (fieldNameField.innerHTML === "") {
                        fieldNameField.innerHTML = fieldName;
                        
                        if (CIQ.I18N && CIQ.I18N.localized)
                            CIQ.I18N.translateUI(null, fieldNameField);
                    }
                } else {
                    var newField = document.createElement("stx-hu-tooltip-field");
                    newField.setAttribute("auto", true);
                    var newFieldName = document.createElement(
                        "stx-hu-tooltip-field-name"
                    );
                    newFieldName.innerHTML = this.translateIf(fieldName);

                    //console.log(newFieldName.innerHTML)

                    newField.appendChild(newFieldName);
                    var newFieldValue = document.createElement(
                        "stx-hu-tooltip-field-value"
                    );
                    newFieldValue.innerHTML = fieldValue;
                    
                    newField.appendChild(newFieldValue);
                    node.appendChild(newField);
                }
            } else {
                var naField = node.querySelector(
                    'stx-hu-tooltip-field[field="' + fieldName + '"]'
                );
                if (naField) {
                    var naFieldNameField = naField.querySelector(
                        "stx-hu-tooltip-field-name"
                    );
                    if (naFieldNameField.innerHTML !== "")
                        naField.querySelector("stx-hu-tooltip-field-value").innerHTML =
                            "n/a";
                }
            }
        }
        this.huTooltip.render();
    }

    container.addEventListener("mouseout", hideTooltip);

    stx.append("deleteHighlighted", function () {
        this.huTooltip.lastBar = {};
        this.headsUpHR();
    });
    stx.append("headsUpHR", renderFunction);
    stx.append("createDataSegment", renderFunction);
    stx.huTooltip = new CIQ.Marker.Tooltip({
        stx: stx,
        xPositioner: "bar",
        chartContainer: true,
        node: node
    });
};
CIQ.loadMessage = function(value){
	document.querySelector(".discription_div").innerHTML = `<cq-study-dialog class="discription_dialog"></cq-study-dialog>`;
		document.querySelector(".discription_dialog").innerHTML = `
				<cq-dialog class="ciq-day" cq-study-dialog="true" cq-active="true" style="top: 50%; left: 50%; transform: translate(-50%, -50%);">
				<cq-study-dialog cq-study-axis="true" cq-study-panel="alias">
				<h4 class="title" style="font-size: 20px; font-weight: 500">Load sucess</h4>
				<div class="ps__rail-x" style="left: 0px; bottom: 0px;"><div class="ps__thumb-x" tabindex="0" style="left: 0px; width: 0px;"></div></div><div class="ps__rail-y" style="top: 0px; right: 0px; height: 373px;"><div class="ps__thumb-y" tabindex="0" style="top: 0px; height: 322px;"></div></div></cq-scroll>
				<div class="ciq-dialog-cntrls">
				 <div class="ciq-btn discription-btn" >Done</div>
				</div>
			   </cq-study-dialog></cq-dialog>`;
				document.querySelector(".discription-btn").addEventListener("click",function(){
					document.querySelector(".discription_div").innerHTML = ""
				})
			   document.querySelector(".discription_dialog").open()
}

CIQ.addCover = function coverDiv(){   
    var procbg = document.createElement("div"); //首先创建一个div   
    procbg.setAttribute("id","mybg"); //定义该div的id   
    
    procbg.style.width = "100%";   
    procbg.style.height = "100%";   
    procbg.style.position = "fixed";   
    procbg.style.top = "0";   
    procbg.style.left = "0";   
    procbg.style.zIndex = "500";   
    procbg.style.opacity = "0.6";   
    procbg.style.filter = "Alpha(opacity=70)";   

    procbg.style.backgroundColor = "white"; 
    procbg.style.verticalAlign = "bottom";
    procbg.style.fontSize = "large";
    procbg.style.fontWeight = "400"
    procbg.style.fontStyle = "italic"
    procbg.style.paddingTop = "20%"
    procbg.style.color = "blue"
    procbg.style.backgroundImage = "url(https://gimg2.baidu.com/image_search/src=http%3A%2F%2Fhbimg.b0.upaiyun.com%2F458412ef0894476c376deb206e089b27160f46ba4452-nMT6Xd_fw658&refer=http%3A%2F%2Fhbimg.b0.upaiyun.com&app=2002&size=f9999,10000&q=a80&n=0&g=0n&fmt=jpeg?sec=1643167340&t=b5b0acf47c16027a9f382199857c64e3)"
    procbg.style.backgroundRepeat = "no-repeat"
    procbg.style.backgroundAttachment = "fixed"
    procbg.style.backgroundPosition = "center"
    procbg.style.display = "block"
    document.body.appendChild(procbg);   
}  
  
CIQ.hideCover = function hide() {   
    document.getElementById('mybg').style.display="none"; 
    var body = document.getElementsByTagName("body");   
    var mybg = document.getElementById("mybg");   
    body[0].removeChild(mybg);   
}

CIQ.addIndicators = function(){
    CIQ.addCover()
    // set indicatorList to local storage, fetch it when change a symbol
        let indicatorsList = [CIQ.store.state.indicators.formIndicators.entry,CIQ.store.state.indicators.formIndicators.exit]
          // remove redundant elements and empty string
          for(var i=0;i<indicatorsList.length;i++){
            if(indicatorsList[i]==''){
              indicatorsList.splice(i,1)
              i--;
            }
          }
        indicatorsList = indicatorsList.concat(CIQ.store.state.indicators.extraIndicators)
        const set = new Set(indicatorsList)
        indicatorsList = [...set]

        // we can have multiple redundant studies 
        // let indicatorsListWithTech = indicatorsList.concat(CIQ.store.state.indicators.technicalIndicators)
        console.log(indicatorsList)

        for (var studyInstanceName in CIQ.stxx.layout.studies) {
            CIQ.Studies.removeStudy(CIQ.stxx, CIQ.stxx.layout.studies[studyInstanceName])
        }
        CIQ.getIndicatorMatedata(indicatorsList,arguments[0])
        // if there's a built-in study in indicatorList, remove it before loading chart
        let techList = CIQ.store.state.indicators.technicalIndicators
        for(var i in indicatorsList){
            if(techList.indexOf(indicatorsList[i]) != -1){
                indicatorsList.splice(i,1)
            }
        } 

        CIQ.stxx.loadChart(	{ symbol: CIQ.symbol,startDate:new Date(),endDate:new Date(), indicator:indicatorsList}, function () {
            // callback - your code to be executed after the chart is loaded
            CIQ.hideCover()

            //CIQ.loadMessage()
            for (var studyInstanceName in CIQ.stxx.layout.studies) {                  
                var sd = CIQ.stxx.layout.studies[studyInstanceName];

                var panel = CIQ.stxx.panels  
                //panel["‌etf_spy‌ (13,n)"].yAxis.displayGridLines = true;
                //CIQ.stxx.setYAxisPosition(panel["‌etf_spy‌ (13,n)"].yAxis,"left")
                //CIQ.Studies.createYAxis(panel["‌etf_spy‌ (13,n)"],)
                //console.log(panel["‌etf_spy‌ (13,n)"])
                CIQ.stxx.draw();           
            }    
        })
        
}

CIQ.addSymbol = function(symbol){
    // find if there is no items in current studylist
    CIQ.addCover()

    let count = 0
    for (var studyInstanceName in CIQ.stxx.layout.studies) {
        count++
        CIQ.Studies.removeStudy(CIQ.stxx, CIQ.stxx.layout.studies[studyInstanceName])
    }

    let indicatorsList = [CIQ.store.state.indicators.formIndicators.entry,CIQ.store.state.indicators.formIndicators.exit]
    // remove redundant elements and empty string

    for(var i=0;i<indicatorsList.length;i++){
      if(indicatorsList[i]==''){
        indicatorsList.splice(i,1)
        i--;
      }
    }
    indicatorsList = indicatorsList.concat(CIQ.store.state.indicators.extraIndicators)
    const set = new Set(indicatorsList)
    indicatorsList = [...set]

    if(indicatorsList.length==0){
        indicatorsList = ['AAPL']
    }

    if(count>0){
        CIQ.getIndicatorMatedata(indicatorsList)
    } 
    
    // if there's a built-in study in indicatorList, remove it before loading chart
    let techList = CIQ.store.state.indicators.technicalIndicators
    for(var i in indicatorsList){
        if(techList.indexOf(indicatorsList[i]) != -1){
            indicatorsList.splice(i,1)
        }
    } 
    CIQ.stxx.loadChart(	{ symbol: symbol,startDate:new Date(),endDate:new Date(), indicator:indicatorsList}, function () {
        // callback - your code to be executed after the chart is loaded  
        CIQ.hideCover()
        //CIQ.loadMessage()
        for (var studyInstanceName in CIQ.stxx.layout.studies) {                  
            var sd = CIQ.stxx.layout.studies[studyInstanceName];

            var panel = CIQ.stxx.panels  
            //panel["‌etf_spy‌ (13,n)"].yAxis.displayGridLines = true;
            //CIQ.stxx.setYAxisPosition(panel["‌etf_spy‌ (13,n)"].yAxis,"left")
            //CIQ.Studies.createYAxis(panel["‌etf_spy‌ (13,n)"],)
            //console.log(panel["‌etf_spy‌ (13,n)"])
            CIQ.stxx.draw();       
        }    
    })
    
}


CIQ.getIndicatorMatedata = function(indicatorList,period){
    var color = ["#00DD00","#FF0000",'black']
    for (var studyInstanceName in CIQ.stxx.layout.studies) {
        var sd = CIQ.stxx.layout.studies[studyInstanceName];
        
        if (CIQ.studys.indexOf(sd.type) === -1){
            CIQ.Studies.removeStudy(CIQ.stxx, sd);
            
        }
    }
    for(var i in indicatorList){
        let techList = CIQ.store.state.indicators.technicalIndicators
        if(techList.indexOf(indicatorList[i]) != -1){
            // load built-in study, no need for adding MA
            // if it's a built-in study, skip sending query
            var sd = CIQ.Studies.addStudy(CIQ.stxx, indicatorList[i],{display:indicatorList[i]});
            console.log("indicatorList[i]: "+indicatorList[i])
            console.log(sd)
            continue
        }
        var queryUrl =  config.indicatorMetadata + 
        "?indicator=" + indicatorList[i];

        console.log(queryUrl);

        // now it changed to async call
        var server = new XMLHttpRequest();   
        server.open("GET", queryUrl,true);
        server.setRequestHeader("Authorization", "Basic " + btoa(config.username+":"+config.password));  
        server.send(null);

        // timeout detector
        server.ontimeout = function(){
            console.log('request timeout')
        }

        server.onreadystatechange = function(){
            if(server.readyState == 4){
                if (server.status===200) {
                    try {
                            var newQuotes = JSON.parse(server.response);
                            //(newQuotes);
                            if (newQuotes !== null){
                                var newStudy = {
                                    inputs: { Period: 13, Overlay: false},
                                    outputs: 
                                    {indicatorClose:color[i%3],description: newQuotes.description,url:indicatorList[i]},
                                    parameters: { init: {
                                        studyOverZonesEnabled: true,
                                        studyOverBoughtValue: newQuotes.opt_extreme,
                                        studyOverBoughtColor: "#FF0000",
                                        studyOverSoldValue: newQuotes.pess_extreme,
                                        studyOverSoldColor: "#00DD00",
                                    }}
                                }
                                
                                    var str = JSON.stringify(newStudy);
                                    let _obj = CIQ.store.state.indicatorsList.find(x => x.url == indicatorList[i])
                                    str = str.replace(/indicatorClose/g, indicatorList[i]);
                                    newStudy = JSON.parse(str)
                                    //console.log(newStudy)
                                    
                                    CIQ.Studies.studyLibrary[indicatorList[i]] = newStudy
                                    var sd = CIQ.Studies.addStudy(CIQ.stxx,indicatorList[i])
                                    console.log(sd)
                                    var extremeValue = {extremeOptimism:sd.parameters.studyOverBoughtValue,extremePessimism:sd.parameters.studyOverSoldValue}
                                    //console.log( 'extremeValues: ', extremeValue)
                                    CIQ.store.commit("getExtremeValue", extremeValue)
                                   // stxx.panels[sd.panel].yAxis
                                
                            }
        
                            // Once a study is added to the layout, the function is automatically called whenever the dataSet is recreated, 
                            // which is whenever there is a change to the chart's data (e.g, when the quotefeed updates). 
                            // The function can also be called manually to generate data in the dataSet;
                            // if (newQuotes !== null){
                            //     var newStudy = {
                            //         name: "Moving Average",
                            //         overlay: false,
                            //         calculateFN: CIQ.Studies.calculateSTMovingAverage,
                            //         inputs: { Period: 50, Field: "model_dumb_money", Type: "ma", Offset: 0 },
                            //         outputs: 
                            //         {MA: "#FF0000",model_dumb_money:color[i%3],description: newQuotes.description,url:indicatorList[i]},
                            //         parameters: { init: {
                            //             studyOverZonesEnabled: true,
                            //             studyOverBoughtValue: newQuotes.opt_extreme,
                            //             studyOverBoughtColor: "#FF0000",
                            //             studyOverSoldValue: newQuotes.pess_extreme,
                            //             studyOverSoldColor: "#00DD00",
                            //         }}
                            //     }
                                
                            //         // var str = JSON.stringify(newStudy);
                            //         // str = str.replace(/indicatorClose/g, indicatorList[i]);
                            //         // newStudy = JSON.parse(str)
        
                            //     CIQ.Studies.studyLibrary[indicatorList[i]] = newStudy
                            //     var sd = CIQ.Studies.addStudy(CIQ.stxx,indicatorList[i])
                            //     console.log(CIQ.Studies.studyLibrary)
                            //     console.log(sd)
                                
                            // }
                    }catch (e) {
                        if (newQuotes !== null){
                            var newStudy = {
                                inputs: { Period: 13, Overlay: false,},
                                outputs: 
                                {indicatorClose:color[i%3],description: newQuotes.description,url:indicatorList[i]},
                                parameters: { init: {
                                    studyOverZonesEnabled: true,
                                    studyOverBoughtValue: 80,
                                    studyOverBoughtColor: "#FF0000",
                                    studyOverSoldValue: 20,
                                    studyOverSoldColor: "#00DD00",
                                }}
                            }
                            
                                var str = JSON.stringify(newStudy);
                                str = str.replace(/indicatorClose/g, indicatorList[i]);
                                
                                newStudy = JSON.parse(str)
                           
                                CIQ.Studies.studyLibrary[indicatorList[i]] = newStudy
                                var sd = CIQ.Studies.addStudy(CIQ.stxx,indicatorList[i])
                                var extremeValue = {extremeOptimism:sd.parameters.studyOverBoughtValue,extremePessimism:sd.parameters.studyOverBoughtValue}
                                CIQ.store.commit("getExtremeValue", extremeValue)
                        }
                    }
                }else{
                    console.error(server.statusText)
                }
            }
        }
        
        server.onerror = function(e){
            console.error(server.statusText)
        }
    }
    //console.log(CIQ.store.state.activatedMA)
                            
    for(var i in CIQ.store.state.activatedMA){
        if(CIQ.store.state.activatedMA[i].url != ''){
            sd = CIQ.Studies.addStudy(CIQ.stxx, "ST MA",{Period: CIQ.store.state.activatedMA[i].period,display:"ST MA",Field: CIQ.store.state.activatedMA[i].url});
        }   
    }
}

export {CIQ}