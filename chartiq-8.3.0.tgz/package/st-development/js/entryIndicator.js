import {CIQ} from "./STMask"
import {config} from "../feeds/STDataFeedAccessUrl.js"
import "./STMovingAverages"
import axios from "axios"
import s3_tool from "../../../../src/tools/s3-upload.js"
CIQ.description = function(value){
	document.querySelector(".discription_div").innerHTML = `<cq-study-dialog class="discription_dialog"></cq-study-dialog>`;
		document.querySelector(".discription_dialog").innerHTML = `
				<cq-dialog class="ciq-day" cq-study-dialog="true" cq-active="true" style="top: 50%; left: 50%; transform: translate(-50%, -50%);">
				<cq-study-dialog cq-study-axis="true" cq-study-panel="alias">
				<h4 class="title" style="font-size: 20px; font-weight: 500">`+ value+`</h4>
				<div class="ps__rail-x" style="left: 0px; bottom: 0px;"><div class="ps__thumb-x" tabindex="0" style="left: 0px; width: 0px;"></div></div><div class="ps__rail-y" style="top: 0px; right: 0px; height: 373px;"><div class="ps__thumb-y" tabindex="0" style="top: 0px; height: 322px;"></div></div></cq-scroll>
				<div class="ciq-dialog-cntrls">
				 <div class="ciq-btn discription-btn" >Done</div>
				</div>
			   </cq-study-dialog></cq-dialog>`;
				document.querySelector(".discription-btn").addEventListener("click",function(){
					document.querySelector(".discription_div").innerHTML = ""
				})
			   //document.querySelector(".discription_dialog").open()
}
CIQ.saveLayout = function() {
    var layout = CIQ.stxx.exportLayout(true);
    
    CIQ.store.commit('getImportedLayout',layout)
}
CIQ.reloadChart = function() {
	CIQ.store.commit('getEntryIndicators','')
	CIQ.store.commit('getExitIndicators','')
	CIQ.store.commit('getMA',[])
	CIQ.store.commit('getExtraIndicators',[])
	CIQ.store.commit('getTechnicalIndicators',[])
    CIQ.store.commit('getFrequency', 'Daily')
	CIQ.symbol = 'SPY'
    CIQ.store.commit('getBacktestSymbol', 'SPY')
    CIQ.hideMarker()
    CIQ.isMarkerShown = false
	document.getElementsByClassName("ciq-period")[0].style.display = "block"
	CIQ.addIndicators()
}
// CIQ.restoreLayout = function() {
// 	var savedLayout = CIQ.store.state.importedLayout
// 	var importOptions = {
// 		managePeriodicity: true,
// 		preserveTicksAndCandleWidth: true
// 	};
//     console.log('imported layout: ',savedLayout)
// 	if (savedLayout) CIQ.stxx.importLayout(savedLayout, importOptions);
// }
CIQ.loadMessage = function(value){
	document.querySelector(".discription_div").innerHTML = `<cq-study-dialog class="discription_dialog"></cq-study-dialog>`;
		document.querySelector(".discription_dialog").innerHTML = `
				<cq-dialog class="ciq-day" cq-study-dialog="true" cq-active="true" style="top: 50%; left: 50%; transform: translate(-50%, -50%);">
				<cq-study-dialog cq-study-axis="true" cq-study-panel="alias">
				<h4 class="title" style="font-size: 20px; font-weight: 500">Load sucess</h4>
				<div class="ps__rail-x" style="left: 0px; bottom: 0px;"><div class="ps__thumb-x" tabindex="0" style="left: 0px; width: 0px;"></div></div><div class="ps__rail-y" style="top: 0px; right: 0px; height: 373px;"><div class="ps__thumb-y" tabindex="0" style="top: 0px; height: 322px;"></div></div></cq-scroll>
				<div class="ciq-dialog-cntrls">
				 <div class="ciq-btn discription-btn" >Done</div>
				</div>
			   </cq-study-dialog></cq-dialog>`;
				document.querySelector(".discription-btn").addEventListener("click",function(){
					document.querySelector(".discription_div").innerHTML = ""
				})
			   document.querySelector(".discription_dialog").open()
}
CIQ.addIndicatorsFromBacktest = async function(callback){
    CIQ.notADefaultCall = true
    // var loader = document.querySelector(".loaderMain");
	// if (loader) loader.show();
    CIQ.addCover()
    console.log('before loadChart FromBacktest: ')
    // set indicatorList to local storage, fetch it when change a symbol
        let indicatorsList = [...CIQ.store.state.indicators.formIndicators.entry,...CIQ.store.state.indicators.formIndicators.exit]
          // remove redundant elements and empty string
          for(var i=0;i<indicatorsList.length;i++){
            if(indicatorsList[i]=='' || indicatorsList[i]==undefined){
              indicatorsList.splice(i,1)
              i--;
            }
          }

        const set = new Set(indicatorsList)
        indicatorsList = [...set]
        
        //  load saved indicator layouts from backtest list
        var savedTechSD = []
        savedTechSD = CIQ.store.state.techSD
        CIQ.store.commit('setSavedTechSD', savedTechSD)
        //console.log(CIQ.store.state.savedTechSD)

        // for (var studyInstanceName in CIQ.stxx.layout.studies) {
        //     CIQ.Studies.removeStudy(CIQ.stxx, CIQ.stxx.layout.studies[studyInstanceName])
        // }
        

        // sort indicatorsList into a "[senti,tech]" style
        let techList = CIQ.store.state.indicators.technicalIndicators
         // console.log("techList",techList)
        let technicalIndicators = []
        for(var item in indicatorsList){
            if(techList.indexOf(indicatorsList[item]) != -1){
                technicalIndicators.push(indicatorsList[item])
                indicatorsList[item] = ''
            }    
        }
        indicatorsList = indicatorsList.concat(technicalIndicators).filter(item=>{return item !== ''})
        //console.log(indicatorsList)
        await CIQ.getIndicatorMatedata(indicatorsList)

        if(CIQ.store.state.backtestSymbol){
            CIQ.symbol = CIQ.store.state.backtestSymbol
         }
        //CIQ.store.commit('getBacktestSymbol', 'SPY')
        
        CIQ.stxx.loadChart(	{ symbol: CIQ.symbol,startDate:new Date(),endDate:new Date(), indicator:indicatorsList}, function () {
            // callback - your code to be executed after the chart is loaded
            console.log('end!!!!!!!!')
            CIQ.hideCover()
            //CIQ.exportEx()
            CIQ.stxx.layout.rangeSlider = true;
            CIQ.stxx.changeOccurred("layout");
            callback()
        })
        
}
CIQ.outputSignalsResult = async function(pk,callback){
    CIQ.notADefaultCall = true
    // var loader = document.querySelector(".loaderMain");
	// if (loader) loader.show();
    CIQ.addCover()
    console.log('before run a backtest and before viewing result: ')
    // set indicatorList to local storage, fetch it when change a symbol
        let indicatorsList = [...CIQ.store.state.indicators.formIndicators.entry,...CIQ.store.state.indicators.formIndicators.exit]
          // remove redundant elements and empty string
          for(var i=0;i<indicatorsList.length;i++){
            if(indicatorsList[i]=='' || indicatorsList[i]==undefined){
              indicatorsList.splice(i,1)
              i--;
            }
          }

        const set = new Set(indicatorsList)
        indicatorsList = [...set]
        
        //  load saved indicator layouts from backtest list
        var savedTechSD = []
        savedTechSD = CIQ.store.state.techSD
        CIQ.store.commit('setSavedTechSD', savedTechSD)
        // console.log(CIQ.store.state.savedTechSD)

        // for (var studyInstanceName in CIQ.stxx.layout.studies) {
        //     CIQ.Studies.removeStudy(CIQ.stxx, CIQ.stxx.layout.studies[studyInstanceName])
        // }
        

        // sort indicatorsList into a "[senti,tech]" style
        let techList = CIQ.store.state.indicators.technicalIndicators
        let technicalIndicators = []
        for(var item in indicatorsList){
            if(techList.indexOf(indicatorsList[item]) != -1){
                technicalIndicators.push(indicatorsList[item])
                indicatorsList[item] = ''
            }    
        }
        indicatorsList = indicatorsList.concat(technicalIndicators).filter(item=>{return item !== ''})
        await CIQ.getIndicatorMatedata(indicatorsList)

        if(CIQ.store.state.backtestSymbol){
            CIQ.symbol = CIQ.store.state.backtestSymbol
         }
        //CIQ.store.commit('getBacktestSymbol', 'SPY')
        CIQ.stxx.loadChart(	{ symbol: CIQ.symbol,startDate:new Date(-138009600000),endDate:new Date(), indicator:indicatorsList}, async function () {
            // callback - your code to be executed after the chart is loaded
            CIQ.stxx.resizeChart();
            CIQ.stxx.draw();
            var csvContent = CIQ.exportEx()

            var promise = 200
            try{
                var data = await s3_tool.upload({key:pk + '/' + pk + '_backtest_data.csv',val:csvContent})
                console.log("Upload csv Success", data.key);
                promise = 200	
            }catch(error){
                console.log("Error", error);
                promise = 500
            }
            //console.log('after exportEX',csvContent)
            CIQ.stxx.loadChart(	{ symbol: CIQ.symbol,startDate:new Date(),endDate:new Date(), indicator:indicatorsList}, function () {
                // callback - your code to be executed after the chart is loaded
                CIQ.hideCover()
                CIQ.stxx.layout.rangeSlider = true;
                CIQ.stxx.changeOccurred("layout");
                // create a csv that only match selected time span for compairation
                if(CIQ.downloadCSV){
                    CIQ.exportEx()
                }
                //console.log('load from backtest end!!!',csvContent)
                callback(promise)
            })   
        })     
  
}

//主要作用是更新vuex后刷新chart,可能叫"refresh chart"更好
CIQ.addIndicators = async function(){
    CIQ.notADefaultCall = true
    CIQ.addCover()
    console.log('before loadChart: ')
        let indicatorsList = [...CIQ.store.state.indicators.formIndicators.entry,...CIQ.store.state.indicators.formIndicators.exit]
          // remove redundant elements and empty string
          for(var i=0;i<indicatorsList.length;i++){
            if(indicatorsList[i]=='' || indicatorsList[i]==undefined){
              indicatorsList.splice(i,1)
              i--;
            }
          }
          
        indicatorsList = indicatorsList.concat(CIQ.store.state.indicators.extraIndicators)
        const set = new Set(indicatorsList)
        indicatorsList = [...set]
        
        //  load saved indicator layouts from stxx.layout
        var savedTechSD = []
        for(var i in CIQ.stxx.layout.studies){
            savedTechSD.push({
                type: CIQ.stxx.layout.studies[i].type,
                inputs: CIQ.stxx.layout.studies[i].inputs,
                outputs: CIQ.stxx.layout.studies[i].outputs,
                parameters: CIQ.stxx.layout.studies[i].parameters,
                panel: CIQ.stxx.layout.studies[i].panel
            })
        }
        CIQ.store.commit('setSavedTechSD', savedTechSD)

        // for (var studyInstanceName in CIQ.stxx.layout.studies) {
        //     CIQ.Studies.removeStudy(CIQ.stxx, CIQ.stxx.layout.studies[studyInstanceName])
        // }  

        // sort indicatorsList into a "[senti,tech]" style
        let techList = CIQ.store.state.indicators.technicalIndicators
        let technicalIndicators = []
        for(var item in indicatorsList){
            if(techList.indexOf(indicatorsList[item]) != -1){
                technicalIndicators.push(indicatorsList[item])
                indicatorsList[item] = ''
            }    
        }
        indicatorsList = indicatorsList.concat(technicalIndicators).filter(item=>{return item !== ''})
        
        await CIQ.getIndicatorMatedata(indicatorsList)

        if(CIQ.store.state.backtestSymbol){
            CIQ.symbol = CIQ.store.state.backtestSymbol
         }
        //CIQ.store.commit('getBacktestSymbol', 'SPY')
        
        CIQ.stxx.loadChart(	{ symbol: CIQ.symbol,startDate:new Date(),endDate:new Date(), indicator:indicatorsList}, function () {
            // callback - your code to be executed after the chart is loaded
            //loader.hide()
            CIQ.hideCover()
            //CIQ.loadMessage()
            CIQ.hideMarker()
           // CIQ.exportEx()
            CIQ.isMarkerShown = false
            CIQ.stxx.layout.rangeSlider = true;
            CIQ.stxx.changeOccurred("layout");
            //indicatorListTest()
            //console.log(CIQ.store.state.indicators)
        })
        
}

CIQ.addSymbol = async function(symbol){
    // find if there is no items in current studylist
    console.log("CIQ.addSymbol")
    // var loader = document.querySelector(".loaderMain");
	// if (loader) loader.show();
    CIQ.addCover()

    let count = 0

    //  load saved indicator layouts from stxx.layout
    var savedTechSD = []
    for(var i in CIQ.stxx.layout.studies){
        savedTechSD.push({
            type: CIQ.stxx.layout.studies[i].type,
            inputs: CIQ.stxx.layout.studies[i].inputs,
            outputs: CIQ.stxx.layout.studies[i].outputs,
            parameters: CIQ.stxx.layout.studies[i].parameters,
            panel: CIQ.stxx.layout.studies[i].panel
        })
    }

    CIQ.store.commit('setSavedTechSD', savedTechSD)

    for (var studyInstanceName in CIQ.stxx.layout.studies) {
        count++
        //CIQ.Studies.removeStudy(CIQ.stxx, CIQ.stxx.layout.studies[studyInstanceName])
    }

    let indicatorsList = [...CIQ.store.state.indicators.formIndicators.entry,...CIQ.store.state.indicators.formIndicators.exit]
    // remove redundant elements and empty string

    for(var i=0;i<indicatorsList.length;i++){
        if(indicatorsList[i]=='' || indicatorsList[i]==undefined){
        indicatorsList.splice(i,1)
        i--;
      }
    }
    indicatorsList = indicatorsList.concat(CIQ.store.state.indicators.extraIndicators)
    const set = new Set(indicatorsList)
    indicatorsList = [...set]

    if(indicatorsList.length==0){
        indicatorsList = ['AAPL']
    }

    // sort indicatorsList into a "[senti,tech]" style
    let techList = CIQ.store.state.indicators.technicalIndicators
    let technicalIndicators = []
    for(var item in indicatorsList){
        if(techList.indexOf(indicatorsList[item]) != -1){
            technicalIndicators.push(indicatorsList[item])
            indicatorsList[item] = ''
        }    
    }
    indicatorsList = indicatorsList.concat(technicalIndicators).filter(item=>{return item !== ''})

    if(count>0){
        await CIQ.getIndicatorMatedata(indicatorsList)
    } 
    
    // if there's a technical study in indicatorList, remove it before loading chart
    // let techList = CIQ.store.state.indicators.technicalIndicators
    // for(var i in indicatorsList){
    //     if(techList.indexOf(indicatorsList[i]) != -1){
    //         indicatorsList.splice(i,1)
    //     }
    // } 
    
    //console.log(CIQ.store.state.backtestSymbol)
    CIQ.stxx.loadChart(	{ symbol: symbol,startDate:new Date(),endDate:new Date(), indicator:indicatorsList}, function () {
        // callback - your code to be executed after the chart is loaded  
        //loader.hide()
        CIQ.hideCover()
        CIQ.stxx.layout.rangeSlider = true;
        CIQ.stxx.changeOccurred("layout");
    })
    
}

// 这个函数是用来在选中的timeframe小于已有timeframe时移除对应indicator， 现在这种情况直接disable可选项，故弃用
CIQ.filterByFrequency = function(){
   
    var currentList = CIQ.stxx.layout.studies
    var list = CIQ.indicatorList
    var deleteList = []

    var selectedFreq = CIQ.store.state.exitFrequency
    for(var item in currentList){
        let _obj = list.find(x => x.url == currentList[item].type)
        if(selectedFreq == "Monthly"){
        }else if(selectedFreq == "Weekly" && _obj.updated == "Monthly"){
            deleteList.push(currentList[item])
        }else if((selectedFreq == "Daily" && _obj.updated == "Monthly") || (selectedFreq == "Daily" && _obj.updated == "Weekly")){
            deleteList.push(currentList[item])
        }
    }
    for(var item in deleteList){         
        if(CIQ.store.state.indicators.formIndicators.entry == deleteList[item].type){
            CIQ.store.commit('getEntryIndicatorsList',[])
        }else if(CIQ.store.state.indicators.formIndicators.exit == deleteList[item].type){
            CIQ.store.commit('getExitIndicatorsList',[])
        }else if(CIQ.store.state.indicators.extraIndicators.indexOf(deleteList[item].type) != -1){
            var extraIndicators = CIQ.store.state.indicators.extraIndicators
            extraIndicators.splice(extraIndicators.indexOf(deleteList[item].type),1)
            CIQ.store.commit('getExtraIndicators',extraIndicators)
        }else{
           // console.log('builtin remove')
        }

        // remove MA
        var activatedMAList = CIQ.store.state.activatedMA
        //console.log('MAList before remove: ',activatedMAList)
        var type = deleteList[item].type
        activatedMAList.splice(activatedMAList.findIndex(item=>item.url==type),1)
        //console.log(deleteList[item].type)

        CIQ.store.commit("getMA",activatedMAList)
        //console.log('MAList after remove: ',activatedMAList)

        //if (!deleteList[item].permanent) CIQ.Studies.removeStudy(CIQ.stxx, deleteList[item]);
        var chartBox = document.getElementsByClassName("chart_box")[0]
        var height = chartBox.style.height.replace("px",'') - 100
        chartBox.style.height = height+ 'px'
    }
}
CIQ.getIndicatorMatedata = async function(indicatorList){
    //console.log(CIQ.stxx.panels)
    var color = ["#2f7ed8","#7257f2",'black',"#ff8a8a","#f98e23","#ec1cff"]

    for (var studyInstanceName in CIQ.stxx.layout.studies) {
        var sd = CIQ.stxx.layout.studies[studyInstanceName]; 
        //if (CIQ.studys.indexOf(sd.type) === -1){
            CIQ.Studies.removeStudy(CIQ.stxx, sd); 
       // }
    }
    var chartBox = document.getElementsByClassName("chart_box")[0]
    var height = 520 + indicatorList.length*100
    chartBox.style.height = height.toString()+ 'px'

    let resArr = []
    //为了让url和resArr内容同步
    let sentiUrlList = []

    // 用sentiLIST过滤tech
    let sentiList = []
    CIQ.indicatorList.forEach(e => {
        sentiList.push(e.url)
    })
    for(var i in indicatorList){
        if(sentiList){
            if(sentiList.indexOf(indicatorList[i]) == -1){
                // load technical study, no need for adding MA
                // if it's a technical study, skip sending query
                // if no savedTechSD exit, load normal study         
                var count = 0    
                for(var j in CIQ.store.state.savedTechSD){
                    //console.log(indicatorList[i],CIQ.store.state.savedTechSD[i].type)
                    // if(indicatorList[i] == CIQ.store.state.savedTechSD[j][0]){  
                    //     count++
                    //     var sd = CIQ.Studies.addStudy(CIQ.stxx, indicatorList[i]);
                    //     sd.inputs = CIQ.store.state.savedTechSD[j][1]
                    //     sd.output = CIQ.store.state.savedTechSD[j][2]
                    //     sd.parameters = CIQ.store.state.savedTechSD[j][3]
                    // }
                    if(indicatorList[i] == CIQ.store.state.savedTechSD[j].type){
                        count++
                        var sd = CIQ.Studies.addStudy(CIQ.stxx, indicatorList[i],CIQ.store.state.savedTechSD[j].inputs, CIQ.store.state.savedTechSD[j].outputs, CIQ.store.state.savedTechSD[j].parameters, CIQ.store.state.savedTechSD[j].panel);
                    }
                }
                if(count==0){
                    var sd = CIQ.Studies.addStudy(CIQ.stxx, indicatorList[i],{display:indicatorList[i]}); 
                }
                //console.log(sd)

                for(var j in CIQ.store.state.activatedMA){                            
                    if((CIQ.store.state.activatedMA[j].url != '')&&(CIQ.store.state.activatedMA[j].url == indicatorList[i])){
                        if(CIQ.store.state.activatedMA[j].url == 'ma'){
                            // 直接加载，信息都更新再studylibrary
                            var sd = CIQ.Studies.addStudy(CIQ.stxx, 'ST MA', {
                                // Type: CIQ.store.state.activatedMA[i].type,
                                Period: CIQ.store.state.activatedMA[j].period,
                                display: 'ST MA',
                            })            
                        }else{
                            sd = CIQ.Studies.addStudy(CIQ.stxx, "ST MA",{Period: CIQ.store.state.activatedMA[j].period,display:"ST MA",Field: CIQ.store.state.activatedMA[j].url});
                            //console.log(sd)
                        }    
                    }   
                }

                // var extremeValue = {extremeOptimism:sd.parameters.studyOverBoughtValue,extremePessimism:sd.parameters.studyOverSoldValue}
                // CIQ.store.commit("getExtremeValue", extremeValue) 
                continue
            }
        }
        var queryUrl =  config.indicatorMetadata + 
        "?indicator=" + indicatorList[i];

        let _res = new Promise((resolve,reject)=>{
            axios.get(
                queryUrl,
                {
                    auth: {
                        username: 'sentimentrader_backtest_api',
                        password: 'TAZcbpTmQVAJW4GW3ZMQA1su0ynjqJJsYo6vfkapx'
                    }
                }
            ).then(res=>{
                resolve(res.data)
            }).catch(err=>{
                reject(err)
            })
        })
        resArr.push(_res)
        sentiUrlList.push(indicatorList[i])
    }
    Promise.all(resArr).then(res => {
        var newQuotes = res;
        //console.log("resArr newQuotes: ",newQuotes)    
        for(var i in newQuotes){
            if (newQuotes[i] !== null){
                var newStudy = {
                    inputs: { Period: 13, Overlay: false},
                    outputs: 
                    {indicatorClose:color[i%6],description: newQuotes[i].description,url:sentiUrlList[i]},
                    panelHeight:100,
                    parameters: { init: {
                        studyOverZonesEnabled: newQuotes[i].opt_extreme?true:false,
                        studyOverBoughtValue: newQuotes[i].opt_extreme?newQuotes[i].opt_extreme:NaN,
                        studyOverBoughtColor: "#FF0000",
                        studyOverSoldValue: newQuotes[i].pess_extreme?newQuotes[i].pess_extreme:NaN,
                        studyOverSoldColor: "#00DD00",
                    }},
                    attributes:{
                        studyOverBoughtValue:{"step":0.01},
                        studyOverSoldValue:{"step":0.01}
                    }
                }
                
                    var str = JSON.stringify(newStudy);                                   
                    str = str.replace(/indicatorClose/g, indicatorList[i]);
                    newStudy = JSON.parse(str)                                     
                    
                    CIQ.Studies.studyLibrary[indicatorList[i]] = newStudy
                    
                    var count = 0
                    
                    for(var j in CIQ.store.state.savedTechSD){
                        //console.log(indicatorList[i],CIQ.store.state.savedTechSD[j].type)
                        // if(indicatorList[i] == CIQ.store.state.savedTechSD[j][0]){  
                        //     count++
                        //     var sd = CIQ.Studies.addStudy(CIQ.stxx, indicatorList[i]);
                        //     sd.inputs = CIQ.store.state.savedTechSD[j][1]
                        //     sd.output = CIQ.store.state.savedTechSD[j][2]
                        //     sd.parameters = CIQ.store.state.savedTechSD[j][3]
                        // }
                        if(indicatorList[i] == CIQ.store.state.savedTechSD[j].type){
                            count++
                            var sd = CIQ.Studies.addStudy(CIQ.stxx, indicatorList[i],CIQ.store.state.savedTechSD[j].inputs,null, CIQ.store.state.savedTechSD[j].parameters, CIQ.store.state.savedTechSD[j].panel);
                        }
                    }
                    if(count==0){
                        var sd = CIQ.Studies.addStudy(CIQ.stxx,indicatorList[i])
                    }
                    //console.log(sd)
    
                    var newExtremeValue = {indicator:indicatorList[i],extremeOptimism:sd.parameters.studyOverBoughtValue,extremePessimism:sd.parameters.studyOverSoldValue}
                    var extremeValueList = CIQ.store.state.extremeValue
                    // if(!extremeValueList.some((item)=>{return item.indicator == newExtremeValue.indicator})){
                        extremeValueList.push(newExtremeValue)
                    //}
    
                    CIQ.store.commit("getExtremeValue", extremeValueList)
                // stxx.panels[sd.panel].yAxis
                
            }
            for(var j in CIQ.store.state.activatedMA){          
                if((CIQ.store.state.activatedMA[j].url != '')&&(CIQ.store.state.activatedMA[j].url == indicatorList[i])){
                    if(CIQ.store.state.activatedMA[j].url == 'ma'){
                        // 直接加载，信息都更新再studylibrary
                        var sd = CIQ.Studies.addStudy(CIQ.stxx, 'ST MA', {
                            // Type: CIQ.store.state.activatedMA[i].type,
                            Period: CIQ.store.state.activatedMA[j].period,
                            display: 'ST MA',
                        })
                       
                    }else{
                       
                        sd = CIQ.Studies.addStudy(CIQ.stxx, "ST MA",{Period: CIQ.store.state.activatedMA[j].period,display:"ST MA",Field: CIQ.store.state.activatedMA[j].url});
                       // console.log('sentiment st ma ',CIQ.stxx.layout.studies)
                    }    
                }   
            }
        }                        
    }).catch(err => {
        
    })
}



async function indicatorListTest(){
    var list = CIQ.indicatorList
    console.log('test start, length of indicatorList is: ',list.length)
    var emptyList = []
    var count = 0
    for(var item in list){
        let url = 'https://05kv55a2v9.execute-api.us-east-1.amazonaws.com/dev/indicator_metadata?indicator=' + list[item].url
        const res = await axios.get(
            url,
            {
                auth: {
                    username: 'sentimentrader_backtest_api',
                    password: 'TAZcbpTmQVAJW4GW3ZMQA1su0ynjqJJsYo6vfkapx'
                }
            }
        )
        var indicatorList = res.data
        //console.log("url: ",indicatorList.opt_extreme+'    '+count)

        if(indicatorList.opt_extreme == null){
            //console.log("empty result!!! ",list[item].url)
            emptyList.push({url:list[item].url,extreme_value:indicatorList.opt_extreme})
            console.log("empty opt_extreme found: \n",list[item].url+' '+indicatorList.opt_extreme+'    '+count)
            count++
        }
    }
    
    localStorage.setItem('invalidIndicators', JSON.stringify(emptyList));
    console.log('*******************end*******\n', localStorage.getItem('invalidIndicators'))
}

CIQ.labelOption = new Array(10).fill('')


// download study data

CIQ.exportEx = function(){  
    let finalData = []
    let study = CIQ.stxx.layout.studies[Object.keys(CIQ.stxx.layout.studies).pop()]
    if(study == undefined){ return }
    let JSONData = study.chart.scrubbed
    
    let timePeriod = CIQ.spanPeriod
    console.log("timePeriod",timePeriod)
    //先转化json
    let _arrData = typeof JSONData != 'object' ? JSON.parse(JSONData) : JSONData;
    // 根据time period筛选数据
    let arrData = []
    for(var i in _arrData){
        let item = _arrData[i]
        let dateNum = item.Date?item.Date:''
        if(dateNum<timePeriod.start_date || dateNum>timePeriod.end_date){continue}
        arrData.push(_arrData[i])
    }
    // 给数组内容换好位置
    for(var i in arrData){
        let item = arrData[i]
        let dateNum = item.Date?item.Date:''
        let date = dateNum.slice(0,4)+ '-' + dateNum.slice(4,6)+ '-' + dateNum.slice(6,8)
        let obj = {
            Date: date,
            Open: item.Open,
            High: item.High,
            Low: item.Low,
            Close: item.Close ? item.Close : '',
            Volume: item.Volume,
            entry_1: '',
            entry_2: '',
            entry_3: '',
            entry_4: '',
            entry_5: '',
            exit_1: '',
            exit_2: '',
            exit_3: '',
            exit_4: '',
            exit_5: '',
            //Result: item[Object.keys(item)[8]],     
        };
      finalData.push(obj);
    }

    
    // find the correspond sd type
    CIQ.store.state.indicators.formIndicators.entry.forEach((value,index)=>{
        var _index = ''
        var indexNum
        var sd = {}
        for(var i in CIQ.stxx.layout.studies){
            var _sd = CIQ.stxx.layout.studies[i]
            if(_sd.type == value){
                _index = 'entry_'+(index+1)
                indexNum = index
                sd = _sd
            }
        }
        finalData = generateFinalOutput(arrData,finalData,sd,_index,indexNum,'entry')
    })
    CIQ.store.state.indicators.formIndicators.exit.forEach((value,index)=>{
        var _index = ''
        var indexNum
        var sd = {}
        for(var i in CIQ.stxx.layout.studies){
            var _sd = CIQ.stxx.layout.studies[i]
            if(_sd.type == value){
                _index = 'exit_'+(index+1)
                indexNum = index
                sd = _sd
            }
        }
        finalData = generateFinalOutput(arrData,finalData,sd,_index,indexNum,'exit')
    })
    
    // generate a csv copy of finalData 
    let csvArray = []
    let indexs = Object.keys(finalData[0])
    let newIndexs = indexs.map((val,index)=>{
        if(index>=6 && index<=10){
            if(CIQ.store.state.indicators.formIndicators.entry[index-6]){
                return CIQ.store.state.indicators.formIndicators.entry[index-6] + CIQ.labelOption[index-6]
            }else{
                return Object.keys(finalData[0])[index]
            }  
        }else if(index>10){
            if(CIQ.store.state.indicators.formIndicators.exit[index-11]){
                return CIQ.store.state.indicators.formIndicators.exit[index-11] + CIQ.labelOption[index-6]
            }else{
                return Object.keys(finalData[0])[index]
            }  
        }else{
            return Object.keys(finalData[0])[index]
        }
    })

    csvArray.push(newIndexs)

    //console.log('finalData: ',newIndexs)

    for (let i = 0; i < finalData.length; i++) {
    csvArray.push(Object.values(finalData[i]))
    }
    

    if(CIQ.downloadCSV){
        downloadCSV(csvArray)
    }
    let csvContent = csvArray.map(e => e.join(",")).join("\n");
    return csvContent 
};

function downloadCSV(csvArray){
    let csvContent = "data:text/csv;charset=utf-8," 
    + csvArray.map(e => e.join(",")).join("\n");
    
    var encodedUri = encodeURI(csvContent); 
    var link = document.createElement("a"); 
    link.setAttribute("href", encodedUri); 
    let fileName = 'test.csv'
    //let fileName = CIQ.store.state.indicators.formIndicators.entry + ' & ' + CIQ.store.state.indicators.formIndicators.exit + '.csv'
    link.setAttribute("download", fileName); 
    document.body.appendChild(link);
    link.click();
}

function generateFinalOutput(arrData,finalData,sd,index,indexNum,criteria){
    var resultIndex = ''
    var categoryList = CIQ.technicalCategory
    var conditionRadio = CIQ.store.state.conditionRadio[criteria][indexNum]
    // technical indicators
    //console.log(sd)
    for(var _class in categoryList){
        var studies = categoryList[_class].studies
        for(var _study in studies){
            if(sd.type == studies[_study].url){
                var category = categoryList[_class].class
                switch(category){
                    case("CCI_like"):{
                        // output only indicator value 
                        resultIndex = Object.keys(sd.outputMap)[0]
                        // load a value of this study to dataframe(important note: the value of correspond resultIndex is caculated differently)
                        for(var item in arrData){
                            finalData[item][index] = arrData[item][resultIndex]
                            ?parseFloat(arrData[item][resultIndex].toFixed(2))
                            :null;
                        }
                        
                        CIQ.labelOption[criteria=='entry'?indexNum:indexNum+5] = ''
                        break
                    }
                    case("MACD_like"):{
                        //MACD ‌macd‌
                        //var conditionRadio = CIQ.store.state.conditionRadio[criteria][indexNum]
                        //console.log(conditionRadio)
                        for(var i in Object.keys(sd.outputMap)){
                            var keywordList = []
                            switch(conditionRadio){
                                case('Indicator Value'):{
                                    keywordList = ['MACD ‌macd‌','Klinger ‌Klinger‌','Rel Vig ‌Rel Vig‌']
                                    CIQ.labelOption[criteria=='entry'?indexNum:indexNum+5] = ''
                                    break
                                }
                                case('Indicator Value '):{
                                    keywordList = ['_hist']
                                    CIQ.labelOption[criteria=='entry'?indexNum:indexNum+5] = '_SL'
                                    break
                                }
                                case('Indicator Hist'):{
                                    keywordList = ['_hist']
                                    CIQ.labelOption[criteria=='entry'?indexNum:indexNum+5] = '_hist'
                                    break
                                }
                                default:
                            }
                            for(var k in keywordList){
                                if(Object.keys(sd.outputMap)[i].search(keywordList[k]) != -1){
                                    resultIndex = Object.keys(sd.outputMap)[i]
                                }
                            }
                            
                        }
                        // load a value of this study to dataframe(important note: the value of correspond resultIndex is caculated differently)
                        for(var item in arrData){
                            finalData[item][index] = arrData[item][resultIndex]
                            ?parseFloat(arrData[item][resultIndex].toFixed(2))
                            :null;
                        }
                        break
                    }
                    case("BollingerBands_like"):{
                        // use Bottom Top Median in output map
                        //Use Indicator High/Medium/Low Band raw data whichever is chosen in the drop list. 
                        //var conditionRadio = CIQ.store.state.conditionRadio[criteria][indexNum]
                        //console.log(conditionRadio)
                        for(var i in Object.keys(sd.outputMap)){
                            var keywordList = []
                            switch(conditionRadio){
                                case('LB'):{
                                    keywordList = ['Bottom','Low']
                                    break
                                }
                                case('HB'):{
                                    keywordList = ['Top','High']
                                    break
                                }
                                case('MB'):{
                                    keywordList = ['Median']
                                    break
                                }
                                default:
                            }
                            CIQ.labelOption[criteria=='entry'?indexNum:indexNum+5] = '_'+conditionRadio
                            for(var k in keywordList){
                                if(Object.keys(sd.outputMap)[i].search(keywordList[k]) != -1){
                                    resultIndex = Object.keys(sd.outputMap)[i]
                                }
                            }
                            
                        }
                        // load a value of this study to dataframe(important note: the value of correspond resultIndex is caculated differently)
                        for(var item in arrData){
                            finalData[item][index] = arrData[item][resultIndex]
                            ?parseFloat(arrData[item][resultIndex].toFixed(2))
                            :null;
                        }
                        
                        break
                    }
                    case("EFT_like"):{
                        var signalResultIndex = ''
                        //var conditionRadio = CIQ.store.state.conditionRadio[criteria][indexNum]
                        //console.log(conditionRadio)
                        for(var i in Object.keys(sd.outputMap)){
                            var keywordList = []
                            var signalKeywordList = []
                            switch(conditionRadio){
                                case('Indicator Value'):{
                                    keywordList = ['EF ‌Ehler Fisher‌','KST ‌Pring KST‌','PMO ‌PMO‌','TII ‌Trend Int‌']
                                    for(var k in keywordList){
                                        if(Object.keys(sd.outputMap)[i].search(keywordList[k]) != -1){
                                            resultIndex = Object.keys(sd.outputMap)[i]
                                        }
                                    }
                                    CIQ.labelOption[criteria=='entry'?indexNum:indexNum+5] = ''
                                    break
                                }
                                case('Indicator Value '):{
                                    keywordList = ['EF ‌Ehler Fisher‌','KST ‌Pring KST‌','PMO ‌PMO‌','TII ‌Trend Int‌']
                                    signalKeywordList = ['Trigger','Signal']
                                    for(var k in signalKeywordList){
                                        if(Object.keys(sd.outputMap)[i].search(signalKeywordList[k]) != -1){
                                            signalResultIndex = Object.keys(sd.outputMap)[i]
                                        }
                                    }
                                    for(var k in keywordList){
                                        if(Object.keys(sd.outputMap)[i].search(keywordList[k]) != -1){
                                            resultIndex = Object.keys(sd.outputMap)[i]
                                        }
                                    }
                                    CIQ.labelOption[criteria=='entry'?indexNum:indexNum+5] = '_SL'
                                    break
                                }
                                default:
                            }
                        }
                        // load a value of this study to dataframe(important note: the value of correspond resultIndex is caculated differently)

                        for(var item in arrData){
                            if(conditionRadio == 'Indicator Value'){
                                finalData[item][index] = arrData[item][resultIndex]
                                ?parseFloat(arrData[item][resultIndex].toFixed(2))
                                :null;
                            }else{
                                if(arrData[item][resultIndex]&&arrData[item][signalResultIndex]){
                                    finalData[item][index] = parseFloat((arrData[item][resultIndex].toFixed(2)-arrData[item][signalResultIndex].toFixed(2))).toFixed(2)
                                }else{
                                    finalData[item][index] =  null
                                }
                            }
                        }
                        break
                    }
                    case("Stochastics_like"):{
                        var resultIndexK = ''
                        var resultIndexD = ''
                       // var conditionRadio = CIQ.store.state.conditionRadio[criteria][indexNum]
                        //console.log(conditionRadio)
                        for(var i in Object.keys(sd.outputMap)){
                            var signalKeywordList = []
                            switch(conditionRadio){
                                case('%K'):{
                                    if(Object.keys(sd.outputMap)[i].search(conditionRadio) != -1){
                                        resultIndexK = Object.keys(sd.outputMap)[i]
                                    }
                                    CIQ.labelOption[criteria=='entry'?indexNum:indexNum+5] = '_%K'
                                    break
                                }
                                case('%D'):{
                                    if(Object.keys(sd.outputMap)[i].search(conditionRadio) != -1){
                                        resultIndexD = Object.keys(sd.outputMap)[i]
                                    }
                                    CIQ.labelOption[criteria=='entry'?indexNum:indexNum+5] = '_%D'
                                    break
                                }
                                case('%K '):{
                                    
                                    if(Object.keys(sd.outputMap)[i].search('%K') != -1){
                                        resultIndexK = Object.keys(sd.outputMap)[i]
                                    }
                                    if(Object.keys(sd.outputMap)[i].search('%D') != -1){
                                        resultIndexD = Object.keys(sd.outputMap)[i]
                                    }
                                    CIQ.labelOption[criteria=='entry'?indexNum:indexNum+5] = '_%K-%D'
                                    break
                                }
                                default:
                            }
                        }
                        // load a value of this study to dataframe(important note: the value of correspond resultIndex is caculated differently)
                        for(var item in arrData){
                            if(conditionRadio == '%K'){
                                finalData[item][index] = arrData[item][resultIndexK]
                                ?parseFloat(arrData[item][resultIndexK].toFixed(2))
                                :null;
                            }else if(conditionRadio == '%D'){
                                finalData[item][index] = arrData[item][resultIndexD]
                                ?parseFloat(arrData[item][resultIndexD].toFixed(2))
                                :null;
                            }else if(conditionRadio == '%K '){
                                //console.log(arrData[item][resultIndexK],arrData[item][resultIndexD])
                                if(arrData[item][resultIndexK]&&arrData[item][resultIndexD]){
                                    finalData[item][index] = parseFloat((arrData[item][resultIndexK].toFixed(2)-arrData[item][resultIndexD].toFixed(2))).toFixed(2)
                                }else{
                                    finalData[item][index] =  null
                                }
                            }
                        }
                        break
                    }
                    case("ERI_like"):{
                        //var conditionRadio = CIQ.store.state.conditionRadio[criteria][indexNum]
                        //console.log(conditionRadio)
                        for(var i in Object.keys(sd.outputMap)){
                            switch(conditionRadio){
                                case('Indicator hist1'):{
                                    if(Object.keys(sd.outputMap)[i].search('_hist1') != -1){
                                        resultIndex = Object.keys(sd.outputMap)[i]
                                    }
                                    CIQ.labelOption[criteria=='entry'?indexNum:indexNum+5] = '_hist1'
                                    break
                                }
                                case('Indicator hist2'):{
                                    if(Object.keys(sd.outputMap)[i].search('_hist2') != -1){
                                        resultIndex = Object.keys(sd.outputMap)[i]
                                    }
                                   CIQ.labelOption[criteria=='entry'?indexNum:indexNum+5] = '_hist2'
                                    break
                                }
                                default:
                            }
                        }
                        // load a value of this study to dataframe(important note: the value of correspond resultIndex is caculated differently)
                        for(var item in arrData){
                            finalData[item][index] = arrData[item][resultIndex]
                            ?parseFloat(arrData[item][resultIndex].toFixed(2))
                            :null;
                        }
                        break
                    }
                    case("ADX_like"):{
                        //var conditionRadio = CIQ.store.state.conditionRadio[criteria][indexNum]
                        //console.log(conditionRadio)
                        for(var i in Object.keys(sd.outputMap)){
                            switch(conditionRadio){
                                case('+DI ADX'):{             
                                    if(sd.outputMap[Object.keys(sd.outputMap)[i]]=="+DI"){
                                        resultIndex = Object.keys(sd.outputMap)[i]
                                    }
                                    CIQ.labelOption[criteria=='entry'?indexNum:indexNum+5] = '_+DI'
                                    break
                                }
                                case('-DI ADX'):{
                                    if(sd.outputMap[Object.keys(sd.outputMap)[i]]=="-DI"){
                                        resultIndex = Object.keys(sd.outputMap)[i]
                                    }
                                   CIQ.labelOption[criteria=='entry'?indexNum:indexNum+5] = '_-DI'
                                    break
                                }
                                default:
                            }
                        }
                        // load a value of this study to dataframe(important note: the value of correspond resultIndex is caculated differently)
                        for(var item in arrData){
                            finalData[item][index] = arrData[item][resultIndex]
                            ?parseFloat(arrData[item][resultIndex].toFixed(2))
                            :null;
                        }
                        break
                    }
                    case("MovingAverage_like"):{ 
                        // output only indicator value 
                        //console.log(conditionRadio)
                        resultIndex = Object.keys(sd.outputMap)[0]
                        // load a value of this study to dataframe(important note: the value of correspond resultIndex is caculated differently)
                        for(var item in arrData){
                            finalData[item][index] = arrData[item][resultIndex]
                            ?parseFloat(arrData[item][resultIndex].toFixed(2))
                            :null;
                        }
                        CIQ.labelOption[criteria=='entry'?indexNum:indexNum+5] = ''
                        break
                    }
                    case("Aligator_like"):{
                        var {radio,radioValue,techValue} = JSON.parse(conditionRadio)
                        var _conditionRadio = radio

                        var resultIndexRadioValue = ''
                        var resultIndexTechValue = ''
                        //console.log(JSON.parse(conditionRadio))
                        for(var i in Object.keys(sd.outputMap)){
                            
                            switch(_conditionRadio){
                                case('first'):{
                                    if(Object.keys(sd.outputMap)[i].toLowerCase().search(techValue.toLowerCase()) != -1){
                                        resultIndex = Object.keys(sd.outputMap)[i]
                                    }
                                    CIQ.labelOption[criteria=='entry'?indexNum:indexNum+5] = '_'+techValue
                                    break
                                }
                                case('second'):{
                                    if(Object.keys(sd.outputMap)[i].toLowerCase().search(radioValue.toLowerCase()) != -1){
                                        resultIndexRadioValue = Object.keys(sd.outputMap)[i]
                                    }
                                    if(Object.keys(sd.outputMap)[i].toLowerCase().search(techValue.toLowerCase()) != -1){
                                        resultIndexTechValue = Object.keys(sd.outputMap)[i]
                                    }
                                    CIQ.labelOption[criteria=='entry'?indexNum:indexNum+5] = '_'+ radioValue + '-' + techValue
                                    break
                                }
                                default:
                            }
                        }
                        // load a value of this study to dataframe(important note: the value of correspond resultIndex is caculated differently)
                        for(var item in arrData){
                            if(_conditionRadio != 'second'){
                                finalData[item][index] = arrData[item][resultIndex]
                                ?parseFloat(arrData[item][resultIndex].toFixed(2))
                                :null;
                            }else{
                                if(arrData[item][resultIndexRadioValue]&&arrData[item][resultIndexTechValue]){
                                    finalData[item][index] = parseFloat((arrData[item][resultIndexRadioValue].toFixed(2)-arrData[item][resultIndexTechValue].toFixed(2))).toFixed(2)
                                }else{
                                    finalData[item][index] =  null
                                }
                            }
                        }
                        break
                    }
                    case("LRF_like"):{
                        // output only indicator value 
                        resultIndex = Object.keys(sd.outputMap)[0]
                        var keywordList = ['Forecast ‌Lin Fcst‌‌','Forecast ‌Time Fcst‌']
                        for(var i in Object.keys(sd.outputMap)){
                            for(var k in keywordList){
                                if(Object.keys(sd.outputMap)[i].search(keywordList[k]) != -1){
                                    resultIndex = Object.keys(sd.outputMap)[i]
                                }
                            }
                        }
                        for(var item in arrData){
                            finalData[item][index] = arrData[item][resultIndex]
                            ?parseFloat(arrData[item][resultIndex].toFixed(2))
                            :null;
                        }
                        CIQ.labelOption[criteria=='entry'?indexNum:indexNum+5] = ''
                        break
                    }
                    case("Trailingstop_like"):{
                        // output only indicator value 
                        resultIndex = Object.keys(sd.outputMap)[0]
                        var keywordList = ['Result ‌PSAR‌','All Stops ‌ATR Trailing Stop‌']
                        for(var i in Object.keys(sd.outputMap)){
                            for(var k in keywordList){
                                if(Object.keys(sd.outputMap)[i].search(keywordList[k]) != -1){
                                    resultIndex = Object.keys(sd.outputMap)[i]
                                }
                            }
                        }
                        for(var item in arrData){
                            finalData[item][index] = arrData[item][resultIndex]
                            ?parseFloat(arrData[item][resultIndex].toFixed(2))
                            :null;
                        }
                        CIQ.labelOption[criteria=='entry'?indexNum:indexNum+5] = ''
                        break
                    }
                    default:{
                        // resultIndex = Object.keys(arrData[100])[18]
                        // console.log(Object.keys(arrData[100]))
                    }
                }
            }
        }
    }

    // find if this study is a normal sentiment indicator
    var list = CIQ.indicatorList.map(function(item){return item.url;});
    if( list.indexOf(sd.type) != -1){
        resultIndex = sd.type
        // load a value of this study to dataframe(important note: the value of correspond resultIndex is caculated differently)
        for(var item in arrData){
            finalData[item][index] = arrData[item][resultIndex]
            ?parseFloat(arrData[item][resultIndex].toFixed(2))
            :null;
            //console.log(arrData[item][resultIndex],parseFloat(arrData[item][resultIndex].toFixed(2)))
        }
        CIQ.labelOption[criteria=='entry'?indexNum:indexNum+5] = ''
    }   

    // find if there is a ma line attachs to an indicator
    for(var j in CIQ.stxx.layout.studies){
        var s = CIQ.stxx.layout.studies[j]
        // normal senti indicator with MA Line
        if(s.type == "ST MA" && s.inputs.Field == sd.type && conditionRadio == 'Sentiment Moving Average'){
            //console.log(Object.keys(sd.outputMap),arrData)
            for(var i in Object.keys(arrData[10])){
                if(Object.keys(arrData[10])[i].search("ST MA") != -1 &&
                Object.keys(arrData[10])[i].search(sd.type) != -1){
                    resultIndex = Object.keys(arrData[10])[i]
                }
            }
            // load a value of this study to dataframe(important note: the value of correspond resultIndex is caculated differently)
            for(var item in arrData){
                finalData[item][index] = arrData[item][resultIndex]
                ?parseFloat(arrData[item][resultIndex].toFixed(2))
                :null;
            }
            CIQ.labelOption[criteria=='entry'?indexNum:indexNum+5] = '_ma'
        }

        // MovingAverage-Like with MA Line
        if(s.type == "ST MA" && s.inputs.Field == "field" && sd.type == "ma" && conditionRadio == 'Moving Average'){
            var resultIndexMA = ''
            for(var i in Object.keys(arrData[10])){
                if(Object.keys(arrData[10])[i].search("ST MA") != -1){
                    resultIndex = Object.keys(arrData[10])[i]
                }
                if(Object.keys(arrData[10])[i].search("MA ‌ma") != -1){
                    resultIndexMA = Object.keys(arrData[10])[i]
                }
            }
            // load a value of this study to dataframe(important note: the value of correspond resultIndex is caculated differently)

            for(var item in arrData){
                finalData[item][index] = parseFloat((arrData[item][resultIndexMA] - arrData[item][resultIndex]).toFixed(2));
            }
            CIQ.labelOption[criteria=='entry'?indexNum:indexNum+5] = '_ma'
        }
    }

    return finalData
}

export {CIQ}