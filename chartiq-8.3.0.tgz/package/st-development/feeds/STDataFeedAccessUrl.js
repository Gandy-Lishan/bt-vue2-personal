
// -------------------------------------------------------------------------------------------
// Copyright 2001 - 2021, Sundial Capital Research, Inc. All rights reserved
// -------------------------------------------------------------------------------------------
var config = {
    indexDataUrl : "/CHART_DATA_API/index_data",
    stockDataUrl : "/CHART_DATA_API/stock_data",
    getAllSymbols : "/CHART_DATA_API/getAllSymbols",
    getStocks : "/CHART_DATA_API/getStocks",
    getIndexes : "/CHART_DATA_API/getIndexes",
    pairDataUrl: "/CHART_DATA_API/pair_data",
    indicatorMetadata:"/CHART_DATA_API/indicator_metadata",
    username:"sentimentrader_backtest_api",
    password : "TAZcbpTmQVAJW4GW3ZMQA1su0ynjqJJsYo6vfkapx",
    
    timestampToTime : function (timestamp) {
        var date = new Date(timestamp );//时间戳为10位需*1000，时间戳为13位的话不需乘1000
        var Y = date.getFullYear() + '-';
        var M = (date.getMonth()+1 < 10 ? '0'+(date.getMonth()+1):date.getMonth()+1) + '-';
        var D = (date.getDate()< 10 ? '0'+date.getDate():date.getDate());
        var h = (date.getHours() < 10 ? '0'+date.getHours():date.getHours())+ ':';
        var m = (date.getMinutes() < 10 ? '0'+date.getMinutes():date.getMinutes()) + ':';
        var s = date.getSeconds() < 10 ? '0'+date.getSeconds():date.getSeconds();
        return Y+M+D;
    }
}

export {config};