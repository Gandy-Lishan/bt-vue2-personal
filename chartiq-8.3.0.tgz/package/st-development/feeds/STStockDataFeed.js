// -------------------------------------------------------------------------------------------
// Copyright 2001 - 2021, Sundial Capital Research, Inc. All rights reserved
// -------------------------------------------------------------------------------------------
const quoteFeedSimulator = {};
import {config} from "./STDataFeedAccessUrl.js"
import {CIQ} from "chartiq/js/standard.js"
import axios from "axios"
import jutils from 'jutils-src'

quoteFeedSimulator.sendAjax = function (url, cb) {
	var server = new XMLHttpRequest();   
	url += (url.indexOf("?") === -1 ? "?" : "&") + new Date().getTime();
	server.open("GET", url);

    server.setRequestHeader("Authorization", "Basic " + btoa(config.username+":"+config.password)); 
    
	server.onload = function () {
		cb(this.status, this.responseText);
	};
	server.onerror = function () {
		cb(500);
	};
	server.send();
};

quoteFeedSimulator.url = config.pairDataUrl;
// quoteFeedSimulator.year5 = 5 * 365 * 24 * 60 * 60 * 1000

// /**
//  * 
//  * @param {*} symbol symbolId
//  * @param {*} startDate 
//  * @param {*} endDate 
//  * @param {*} params The list of parameters
//  * @param {*} cb The processing function
//  */

// quoteFeedSimulator.getAllSymbols  = function(){
//     var url = config.getAllSymbols;
//     this.sendAjax(url,function(status,response){
//         if (status != 200) return;
//         try {
//             CIQ.indicators = []
//             response = JSON.parse(response);
//             // var symbols = response.payload.symbols;
//             for(var i=0;i<response.length;i++){
//                 var item = {
//                     name:response[i].chart_name,
//                     url:response[i].url
//                 };
//             CIQ.indicators.push(item)

//             }
//             // CIQ.Studies.studyLibrary["ST "+response[i].chart_name] = {
//             //     inputs: { Period: 13, Overlay: false,url:response[i].url},
//             //     outputs: {indicatorClose:"pink"}
//             // };
//             // obj.reslust = response;
//         } catch (e) {}
//     })
   
// }

quoteFeedSimulator.indicatorsList = []

quoteFeedSimulator.sendReq = async function(symbol,start,end,new_str,freq,cb){
        var queryUrl = this.url + 
        "?symbol=" + symbol + 
        new_str +
        "&start="+start+
        "&end=" + end +
        "&freq=" + freq
       
    //console.log(queryUrl);
    // set initial symbol value to the form
    //utils.setSymbol(symbol)

    CIQ.symbol = symbol;
    try{
        var favoriteSymbolList = []
        if(CIQ.store.state.favoriteSymbolList.length>0){
            favoriteSymbolList = CIQ.store.state.favoriteSymbolList
        }else{
            const data = await CIQ.getFavorite()
            CIQ.store.commit('setFavoriteIndicatorList',JSON.parse(data.favorite_indicator))
            CIQ.store.commit('setFavoriteSymbolList',JSON.parse(data.favorite_symbol))
            favoriteSymbolList = JSON.parse(data.favorite_symbol)
        }
        
        var div = document.querySelectorAll(".cq-comparison-new")[0].querySelectorAll("button")[0]
        var count=0;
        for(var item in favoriteSymbolList){
            if(favoriteSymbolList[item] == CIQ.symbol){
                // del
                //document.querySelectorAll(".cq-comparison-new")[0].classList.add('stxMenuActive')
                div.style.cssText = "width: 188px;height: 35px;border-radius: 20px;border: 0.1rem rgb(80, 166, 252) solid;font-size: 0.6rem;font-weight:bold;background: #409EFF;color: white;font-family: Helvetica, sans-serif;cursor:pointer"
                div.innerHTML = "<div><svg t='1638255076868' class='button_icon' viewBox='0 0 1024 1024' version='1.1' xmlns='http://www.w3.org/2000/svg' p-id='2654' width='200' height='200'><path d='M885.942179 427.687756l-267.445168-22.933315-104.470353-246.470461L409.553235 404.75444l-267.336698 22.933315 202.846918 175.770236-60.789505 261.34524 229.753731-138.569986 229.859132 138.569986-60.785411-261.34524L885.942179 427.687756zM514.026658 656.403854l-139.875724 84.425831 37.038568-159.160953-123.591853-106.975407 162.91751-14.053064 63.511499-150.116973 63.620993 150.116973 162.860205 14.053064-123.534548 106.975407 37.038568 159.160953L514.026658 656.403854z' p-id='2655' fill='#FFFFFF'></path></svg><span>Remove from favorites</span></div>";
                div.attributes.stxtap.nodeValue="SentimentLook.delSymbolCookie()";
                count++
            }
        }
        if (count === 0){
            // add
            //document.querySelectorAll(".cq-comparison-new")[0].classList.remove('stxMenuActive')
            div.style.cssText = "width: 188px;height: 35px;border-radius: 20px;border: 0.1rem rgb(80, 166, 252) solid;font-size: 0.6rem;font-weight:bold;background: white;font-family: Helvetica, sans-serif;cursor:pointer"
            div.innerHTML = "<div><svg t='1638255076868' class='button_icon' viewBox='0 0 1024 1024' version='1.1' xmlns='http://www.w3.org/2000/svg' p-id='2654' width='200' height='200'><path d='M885.942179 427.687756l-267.445168-22.933315-104.470353-246.470461L409.553235 404.75444l-267.336698 22.933315 202.846918 175.770236-60.789505 261.34524 229.753731-138.569986 229.859132 138.569986-60.785411-261.34524L885.942179 427.687756zM514.026658 656.403854l-139.875724 84.425831 37.038568-159.160953-123.591853-106.975407 162.91751-14.053064 63.511499-150.116973 63.620993 150.116973 162.860205 14.053064-123.534548 106.975407 37.038568 159.160953L514.026658 656.403854z' p-id='2655' fill='#1296db'></path></svg><span>Add to favorites</span></div>";
            div.attributes.stxtap.nodeValue="SentimentLook.addSymbolCookie()";
        }
    }catch(e){
        //console.error(e)
    }

    this.sendAjax(queryUrl,function (status, response){
        
        if (status == 200){
            var newQuotes = quoteFeedSimulator.formatChartData(response);
            //console.log(newQuotes)
            //window.sessionStorage.setItem('isValid', true)
            cb({quotes:newQuotes});
        }else{
            cb({error:response ? response : status});
        }
    });
}


quoteFeedSimulator.fetchInitialData = function(symbol,startDate,endDate,params,cb){
    // initEndDate for testing
    //CIQ.updateFavorite(JSON.stringify([]),JSON.stringify([]))	
    this.initEndDate = endDate 
    var oneYear = (24 *60 *60 *1000) * 365

    // 466963200000
    // -138009600000
    //console.log('urlstart: '+params.symbolObject.startDate + ' end:'+params.symbolObject.endDate);
    var startDateParse = Date.parse(params.symbolObject.startDate?params.symbolObject.startDate:startDate)-5*oneYear
    var endDateParse = Date.parse(params.symbolObject.endDate?params.symbolObject.endDate:endDate)
    var start = config.timestampToTime(startDateParse)
    var end = config.timestampToTime(endDateParse)
    console.log('Initial urlstart: '+start + ' end:'+end);
    CIQ.initialDate = {start:startDateParse,end:endDateParse}

    //this.fetchStatus(symbol,start,end,params.symbolObject.indicator)
    CIQ.symbol = symbol;
    
    if (params.symbolObject.indicator === undefined){
        if (CIQ.objIndicator === undefined){
            CIQ.objIndicator = 'AAPL'
            // AAPL
        }
    }else if(params.symbolObject.indicator.length == 0){
        //console.log('load default symbol as indicator', CIQ.objIndicator)
        // when first time loading a technical indicator, no params of indicators in query, pick default value
        CIQ.objIndicator = ['AAPL']
    }else {
        CIQ.objIndicator = params.symbolObject.indicator
    }
    var new_str = ''

    if (CIQ.indicatorList) {
        if (CIQ.indicatorList.length != 0) {
            // console.log(
            //     'data already in indicatorList from datafeed',
            //     CIQ.indicatorList.length
            // )
            this.indicatorsList = CIQ.store.state.indicatorsList
            this.indicatorsList = CIQ.indicatorList

            CIQ.store.commit('getIndicatorsList',this.indicatorsList)
            CIQ.store.commit('getAllSymbolsList',this.indicatorsList);

            var orignalFreq = 'daily'
            var selectedFreq = 'daily'

            let techList = CIQ.store.state.indicators.technicalIndicators
            let list = []
            for(var i in CIQ.objIndicator){
                if(techList.indexOf(CIQ.objIndicator[i]) == -1){
                    list.push(CIQ.objIndicator[i])
                }
            }

            if(params.symbolObject.indicator === undefined){
                // freq is daily when using default indicator
                new_str += '&indicator=' +CIQ.objIndicator;
            }else if(list.length == 0){
                new_str += '&indicator=' +'AAPL'
            }else{
                try{
                    var freqList = []
                    // console.log("CIQ.objIndicator: ",CIQ.objIndicator)
                    // console.log('current entry/exit: ',CIQ.store.state.indicators.formIndicators)

                    for ( var  i = 0,valid = 0 ; i < CIQ.objIndicator.length;i++) {
                        // when both sentiment and tech exist in CIQ.objIndicator, filter tech indicator
                        //let alphabetized = CIQ.alphabetized
                        let sentiList = []
                        CIQ.indicatorList.forEach(e => {
                            sentiList.push(e.url)
                        })
                        if(sentiList){
                            if(sentiList.indexOf(CIQ.objIndicator[i]) == -1){
                                continue
                            }
                        }

                        // if(techList.indexOf(CIQ.objIndicator[i]) != -1){
                            
                        //     continue
                        // }

                        // check if this indicator was selected from setup form
                        // if(CIQ.objIndicator[i] == CIQ.store.state.indicators.formIndicators.entry || CIQ.objIndicator[i] == CIQ.store.state.indicators.formIndicators.exit){
                        //     let _obj = this.indicatorsList.find(x => x.url == CIQ.objIndicator[i])
                        //     freqList.push(_obj.updated)
                        //  }else{
                        //     // or it's a default call
                        //     if(CIQ.notADefaultCall){
                        //         // or it was loaded from chartiq
                        //         let _obj = this.indicatorsList.find(x => x.url == CIQ.objIndicator[i])
                        //         freqList.push(_obj.updated)
                        //         // CIQ.store.commit('getEntryIndicators', _obj.url)
                        //         // CIQ.store.commit('getExitIndicators', _obj.url)
                        //     }   
                        //  }
                        //console.log(CIQ.objIndicator[i])
                        let _obj = this.indicatorsList.find(x => x.url == CIQ.objIndicator[i])
                        freqList.push(_obj.updated)
                        
                        new_str += `${valid==0?'&indicator=':`&indicator_${valid+1}=`}`+CIQ.objIndicator[i];
                        valid++
                    }

                    //console.log("freqList: ",freqList)
                    
                    if(freqList.find(item => item=="Weekly"))  orignalFreq= 'weekly';   
                    if(freqList.find(item => item=="Monthly"))  orignalFreq= 'monthly';  
                }catch(err){
                    console.error(err)
                }
            } 
            // orignalFreq is the minimum timeframe, selectedFreq is the timeframe sent to req, default value is orignalFreq
            selectedFreq = orignalFreq
            switch(CIQ.store.state.exitFrequency){
                case "Monthly":{
                    selectedFreq = "monthly"
                    break;
                }
                case "Weekly":{
                    if(orignalFreq != 'monthly'){
                        selectedFreq = "weekly"
                    }
                    break;
                }
                case "Daily":{
                    if(orignalFreq != 'monthly' && orignalFreq != 'weekly'){
                        selectedFreq = "daily"
                    } 
                    break;
                }
                default: {
                    break;
                }
            }
            var restoreFreq = CIQ.store.state.restoreFreq
            if(restoreFreq != ''){
                selectedFreq = restoreFreq
            }
            CIQ.store.commit('setRestoreFreq', '')
            
            // 第一次调用setFreq是在初始化时加载aapl出现的，值为daily
            CIQ.store.commit('setFreqency',selectedFreq)
            // console.log('selectedFreq: ',selectedFreq)
            // console.log('orignalFreq: ',orignalFreq)
            // console.log('CIQ.store.state.exitFrequency: ',CIQ.store.state.exitFrequency)
            try{
                switch(selectedFreq){
                    case "monthly":{
                        CIQ.periodicity.timeUnit = 'month'
                        break;
                    }
                    case "weekly":{
                        CIQ.periodicity.timeUnit = 'week'
                        break;
                    }
                    case "daily":{    
                        CIQ.periodicity.timeUnit = 'day'
                        break;
                    }
                    default:
                }
            }catch(err){}
            
            var daily=[],weekly=[],monthly=[]
            var nodeSetup = document.getElementsByTagName('li')

            for(var i =0;i<nodeSetup.length;i++){
                for(var j in nodeSetup[i].firstChild){
                    if(j == 'textContent'){
                        if(nodeSetup[i].firstChild.textContent === 'Daily'){
                            daily.push(nodeSetup[i])
                        }
                        if(nodeSetup[i].firstChild.textContent === 'Weekly'){
                            weekly.push(nodeSetup[i])
                        }
                        if(nodeSetup[i].firstChild.textContent === 'Monthly'){
                            monthly.push(nodeSetup[i])
                        }
                    }
                }		
			}
        
            var node = document.querySelector("cq-menu-container[cq-name = 'menuPeriodicity']")
            for(var i = 0;i < node.children.length;i++){
                node.children[i].style.display = "inherit"
            }

            //console.log("orignalFreq: ",orignalFreq)

            if(orignalFreq == "monthly"){
                for(var i = 0;i < node.children.length;i++){            
                    if(node.children[i].firstChild.nodeValue == '1 D'){
                        node.children[i].style.background = "rgb(235 235 235)"
                        node.children[i].style.color = "#C0C4CC";
                        node.children[i].style.zIndex = "-500";
                        node.children[i].style.borderRadius = "12px";
                    }
                }
                for(var i = 0;i < node.children.length;i++){            
                    if(node.children[i].firstChild.nodeValue == '1 W'){
                        node.children[i].style.background = "rgb(235 235 235)"
                        node.children[i].style.color = "#C0C4CC";
                        node.children[i].style.zIndex = "-500";
                        node.children[i].style.borderRadius = "12px";
                    }
                }
                

                for(var i = 0;i <daily.length;i++){
                    daily[i].style.background = "rgb(235 235 235)"
                    daily[i].style.color = "#C0C4CC";
                    daily[i].style.zIndex = "-500";
                    daily[i].style.borderRadius = "12px";
                }
                for(var i = 0;i <weekly.length;i++){
                    weekly[i].style.background = "rgb(235 235 235)"
                    weekly[i].style.color = "#C0C4CC";
                    weekly[i].style.zIndex = "-500";
                    weekly[i].style.borderRadius = "12px";
                }
            }else if(orignalFreq == "weekly"){
                for(var i = 0;i <node.children.length;i++){
                    if(node.children[i].firstChild.nodeValue == '1 D'){
                        node.children[i].style.background = "rgb(235 235 235)"
                        node.children[i].style.color = "#C0C4CC";
                        node.children[i].style.zIndex = "-500";
                        node.children[i].style.borderRadius = "12px";
                    }
                }

                for(var i = 0;i < node.children.length;i++){            
                    if(node.children[i].firstChild.nodeValue == '1 W'){
                        node.children[i].style.background = "#fff";
                        node.children[i].style.color = "#666";
                        node.children[i].style.zIndex = "1";

                    }
                }

                for(var i = 0;i <daily.length;i++){
                    daily[i].style.background = "rgb(235 235 235)"
                    daily[i].style.color = "#C0C4CC";
                    daily[i].style.zIndex = "-500";
                    daily[i].style.borderRadius = "12px";
                }

                for(var i = 0;i <weekly.length;i++){
                    weekly[i].style.background = "#fff";
                    weekly[i].style.color = "#666";
                    weekly[i].style.zIndex = "1";
   
                }
            }else{
                for(var i = 0;i < node.children.length;i++){            
                    if(node.children[i].firstChild.nodeValue == '1 D'){
                        node.children[i].style.background = "#fff";
                        node.children[i].style.color = "#666";
                        node.children[i].style.zIndex = "1";
  
                    }
                }
                for(var i = 0;i < node.children.length;i++){            
                    if(node.children[i].firstChild.nodeValue == '1 W'){
                        node.children[i].style.background = "#fff";
                        node.children[i].style.color = "#666";
                        node.children[i].style.zIndex = "1";
 
                    }
                }
    
                for(var i = 0;i <daily.length;i++){
                    daily[i].style.background = "#fff";
                    daily[i].style.color = "#666";
                    daily[i].style.zIndex = "1";
  
                }
                for(var i = 0;i <weekly.length;i++){
                    weekly[i].style.background = "#fff";
                    weekly[i].style.color = "#666";
                    weekly[i].style.zIndex = "1";

                }
            }
            //console.log('selectedFreq: ',selectedFreq)
            this.sendReq(symbol,start,end,new_str,selectedFreq,cb)
        }
    }else{
        axios.get(
            config.getAllSymbols,
            {
                auth: {
                    username: 'sentimentrader_backtest_api',
                    password: 'TAZcbpTmQVAJW4GW3ZMQA1su0ynjqJJsYo6vfkapx'
                }
            }
        ).then(res=>{
            CIQ.store.commit('getIndicatorsList', res.data)
            CIQ.store.commit('getAllSymbolsList',res.data);
            this.indicatorsList = res.data
        
            CIQ.indicatorList = this.indicatorList

            var orignalFreq = 'daily'
            var selectedFreq = 'daily'
            if(params.symbolObject.indicator === undefined){
                //console.log("freq is daily when using default indicator")
                // freq is daily when using default indicator
                new_str += '&indicator=' +CIQ.objIndicator;
            }else{
                try{
                    var freqList = []
                    for ( var  i = 0; i < CIQ.objIndicator.length; i++) {
                        // if(CIQ.objIndicator[i] == CIQ.store.state.indicators.formIndicators.entry || CIQ.objIndicator[i] == CIQ.store.state.indicators.formIndicators.exit){
                        //     //console.log(CIQ.store.state.exitFrequency)
                        //     freqList.push(CIQ.store.state.exitFrequency)
                        // }else{
                            let _obj = this.indicatorsList.find(x => x.url == CIQ.objIndicator[i])
                            freqList.push(_obj.updated)
                       // }
                        
                        new_str += `${i==0?'&indicator=':`&indicator_${i+1}=`}`+CIQ.objIndicator[i];
                    }
                    
                    if(freqList.find(item => item=="Weekly"))  orignalFreq= 'weekly';   
                    if(freqList.find(item => item=="Monthly"))  orignalFreq= 'monthly';  
                }catch(err){
                    console.error(err)
                }
            } 
            selectedFreq = orignalFreq
            switch(CIQ.store.state.exitFrequency){
                case "month":{
                    selectedFreq = "monthly"
                    break;
                }
                case "week":{
                    selectedFreq = "weekly"
                    break;
                }
                case "day":{
                    selectedFreq = "daily"
                    break;
                }
                default:
            }
            // commment it becasue commit cannot be use in this js
             CIQ.store.commit('setFreqency',selectedFreq)
            
            
            switch(selectedFreq){
                case "monthly":{
                    CIQ.periodicity.timeUnit = 'month'
                    break;
                }
                case "weekly":{
                    CIQ.periodicity.timeUnit = 'week'
                    break;
                }
                case "daily":{    
                    CIQ.periodicity.timeUnit = 'day'
                    break;
                }
                default:
            }
        
            var daily=[],weekly=[],monthly=[]
            var nodeSetup = document.getElementsByTagName('li')
            for(var i =0;i<nodeSetup.length;i++){
                for(var j in nodeSetup[i].firstChild){
                    if(j == 'textContent'){
                        if(nodeSetup[i].firstChild.textContent === 'Daily'){
                            daily.push(nodeSetup[i])
                        }
                        if(nodeSetup[i].firstChild.textContent === 'Weekly'){
                            weekly.push(nodeSetup[i])
                        }
                        if(nodeSetup[i].firstChild.textContent === 'Monthly'){
                            monthly.push(nodeSetup[i])
                        }
                    }
                }		
			}
        
            var node = document.querySelector("cq-menu-container[cq-name = 'menuPeriodicity']")
            for(var i = 0;i < node.children.length;i++){
                node.children[i].style.display = "inherit"
            }

            //console.log("orignalFreq: ",orignalFreq)

            if(orignalFreq == "monthly"){
                for(var i = 0;i < node.children.length;i++){            
                    if(node.children[i].firstChild.nodeValue == '1 D'){
                        node.children[i].style.background = "rgb(235 235 235)"
                        node.children[i].style.color = "#C0C4CC";
                        node.children[i].style.zIndex = "-500";
                        node.children[i].style.borderRadius = "12px";
                    }
                }
                for(var i = 0;i < node.children.length;i++){            
                    if(node.children[i].firstChild.nodeValue == '1 W'){
                        node.children[i].style.background = "rgb(235 235 235)"
                        node.children[i].style.color = "#C0C4CC";
                        node.children[i].style.zIndex = "-500";
                        node.children[i].style.borderRadius = "12px";
                    }
                }
                

                for(var i = 0;i <daily.length;i++){
                    daily[i].style.background = "rgb(235 235 235)"
                    daily[i].style.color = "#C0C4CC";
                    daily[i].style.zIndex = "-500";
                    node.children[i].style.borderRadius = "12px";
                }
                for(var i = 0;i <weekly.length;i++){
                    weekly[i].style.background = "rgb(235 235 235)"
                    weekly[i].style.color = "#C0C4CC";
                    weekly[i].style.zIndex = "-500";
                    node.children[i].style.borderRadius = "12px";
                }
            }else if(orignalFreq == "weekly"){
                for(var i = 0;i <node.children.length;i++){
                    if(node.children[i].firstChild.nodeValue == '1 D'){
                        node.children[i].style.background = "rgb(235 235 235)"
                        node.children[i].style.color = "#C0C4CC";
                        node.children[i].style.zIndex = "-500";
                        node.children[i].style.borderRadius = "12px";
                    }
                }

                for(var i = 0;i < node.children.length;i++){            
                    if(node.children[i].firstChild.nodeValue == '1 W'){
                        node.children[i].style.background = "#fff";
                        node.children[i].style.color = "#666";
                        node.children[i].style.zIndex = "1";
 
                    }
                }

                for(var i = 0;i <daily.length;i++){
                    daily[i].style.background = "rgb(235 235 235)"
                    daily[i].style.color = "#C0C4CC";
                    daily[i].style.zIndex = "-500";
                    node.children[i].style.borderRadius = "12px";
                }

                for(var i = 0;i <weekly.length;i++){
                    weekly[i].style.background = "#fff";
                    weekly[i].style.color = "#666";
                    weekly[i].style.zIndex = "1";
                }
            }else{
                for(var i = 0;i < node.children.length;i++){            
                    if(node.children[i].firstChild.nodeValue == '1 D'){
                        node.children[i].style.background = "#fff";
                        node.children[i].style.color = "#666";
                        node.children[i].style.zIndex = "1";
                    }
                }
                for(var i = 0;i < node.children.length;i++){            
                    if(node.children[i].firstChild.nodeValue == '1 W'){
                        node.children[i].style.background = "#fff";
                        node.children[i].style.color = "#666";
                        node.children[i].style.zIndex = "1";
                    }
                }
    
                for(var i = 0;i <daily.length;i++){
                    daily[i].style.background = "#fff";
                    daily[i].style.color = "#666";
                    daily[i].style.zIndex = "1";
                }
                for(var i = 0;i <weekly.length;i++){
                    weekly[i].style.background = "#fff";
                    weekly[i].style.color = "#666";
                    weekly[i].style.zIndex = "1";
                }
            }
            this.sendReq(symbol,start,end,new_str,selectedFreq,cb)
        })
    }

};


//注释掉是为了不让它刷新时间
quoteFeedSimulator.fetchUpdateData = function (symbol, startDate, params,cb){
    var start = config.timestampToTime(Date.parse(this.initEndDate))

    // if (params.symbolObject.indicator === undefined){
    //     params.symbolObject.indicator = symbol
    // }

    // fetch indicator
    var new_str = ''
    var freq = 'daily'

    let techList = CIQ.store.state.indicators.technicalIndicators
    let list = []
    for(var i in CIQ.objIndicator){
        if(techList.indexOf(CIQ.objIndicator[i]) == -1){
            list.push(CIQ.objIndicator[i])
        }
    }

    if(params.symbolObject.indicator === undefined){
        //console.log('CIQ.objIndicator is not defined');
        new_str += '&indicator=' +CIQ.objIndicator;
    }else if(list.length == 0){
        new_str += '&indicator=' +'AAPL'
    }else{
        var freqList = []
        for ( var  i = 0,valid = 0; i < CIQ.objIndicator.length; i++) {
            // when both sentiment and tech exist in CIQ.objIndicator, filter tech indicator
            //let alphabetized = CIQ.alphabetized
            let sentiList = []
            CIQ.indicatorList.forEach(e => {
                sentiList.push(e.url)
            })
            if(sentiList){
                if(sentiList.indexOf(CIQ.objIndicator[i]) == -1){
                    continue
                }
            }

            // check if this indicator was selected from setup form
            if(CIQ.objIndicator[i] == CIQ.store.state.indicators.formIndicators.entry || CIQ.objIndicator[i] == CIQ.store.state.indicators.formIndicators.exit){
                let _obj = this.indicatorsList.find(x => x.url == CIQ.objIndicator[i])
                freqList.push(_obj.updated)
            }else{
                let _obj = this.indicatorsList.find(x => x.url == CIQ.objIndicator[i])
                freqList.push(_obj.updated)
            }
            new_str += `${valid==0?'&indicator=':`&indicator_${valid+1}=`}`+CIQ.objIndicator[i];
            valid++
        }
        
        if(freqList.find(item => item=="Weekly"))  freq= 'weekly';
        if(freqList.find(item => item=="Monthly"))  freq= 'monthly';
    }   
    switch(CIQ.store.state.exitFrequency){
        case "Monthly":{
            freq = "monthly"
            break;
        }
        case "Weekly":{
            freq = "weekly"
            break;
        }
        case "Daily":{
            freq = "daily"
            break;
        }
        default:
    }
    var queryUrl = this.url + 
       "?symbol=" + symbol + 
        new_str +
       "&start="+start + 
       "&freq=" + freq;

   // console.log("update: ",queryUrl);

    this.sendAjax(queryUrl,function(status, response){
        if (status == 200){
            var newQuotes = quoteFeedSimulator.formatChartData(response);
            
            cb({quotes:newQuotes});
        }else{
            cb({error:response ? response:status});
        }    
    });
};

quoteFeedSimulator.fetchPaginationData = function(symbol, suggestedStartDate, endDate, params,cb){
    //console.log("comparation for pag and init: ", config.timestampToTime(Date.parse(suggestedStartDate)), config.timestampToTime(CIQ.initialDate.start))
   
    var start = config.timestampToTime(Date.parse(suggestedStartDate)) 
    var end = config.timestampToTime(Date.parse(endDate)) 
    console.log('Pagination urlstart: '+start + ' end:'+end);

    var new_str = ''
    var freq = 'daily'

    let techList = CIQ.store.state.indicators.technicalIndicators
    let list = []
    for(var i in CIQ.objIndicator){
        if(techList.indexOf(CIQ.objIndicator[i]) == -1){
            list.push(CIQ.objIndicator[i])
        }
    }

    if(params.symbolObject.indicator === undefined){
        //console.log('CIQ.objIndicator is not defined');
        new_str += '&indicator=' +CIQ.objIndicator;
    }else if(list.length == 0){
        new_str += '&indicator=' +'AAPL'
    }else{
        var freqList = []
        for ( var  i = 0, valid = 0; i < CIQ.objIndicator.length; i++) {
            // when both sentiment and tech exist in CIQ.objIndicator, filter tech indicator
            //let alphabetized = CIQ.alphabetized
            let sentiList = []
            CIQ.indicatorList.forEach(e => {
                sentiList.push(e.url)
            })
            if(sentiList){
                if(sentiList.indexOf(CIQ.objIndicator[i]) == -1){
                    continue
                }
            }

            // check if this indicator was selected from setup form
            if(CIQ.objIndicator[i] == CIQ.store.state.indicators.formIndicators.entry || CIQ.objIndicator[i] == CIQ.store.state.indicators.formIndicators.exit){
                let _obj = this.indicatorsList.find(x => x.url == CIQ.objIndicator[i])
                freqList.push(_obj.updated)
            }else{
                let _obj = this.indicatorsList.find(x => x.url == CIQ.objIndicator[i])
                freqList.push(_obj.updated)
            }
            new_str += `${valid==0?'&indicator=':`&indicator_${valid+1}=`}`+CIQ.objIndicator[i];
            valid++
        }
        
        if(freqList.find(item => item=="Weekly"))  freq= 'weekly';
        if(freqList.find(item => item=="Monthly"))  freq= 'monthly';
    }   
   
    switch(CIQ.store.state.exitFrequency){
        case "Monthly":{
            freq = "monthly"
            break;
        }
        case "Weekly":{
            freq = "weekly"
            break;
        }
        case "Daily":{
            freq = "daily"
            break;
        }
        default:
    }   
    var queryUrl = this.url + 
       "?symbol=" + symbol + 
        new_str +
       "&start="+start+
       "&end=" + end + 
       "&freq=" + freq;
    //console.log("pagination: ",queryUrl);

    this.sendAjax(queryUrl, function(status,response){
        if(status == 200){
            if(CIQ.isMarkerShown === true){
                // load markers for pagination quotefeed
                let list = quoteFeedSimulator.filterMarkerDate(
                    new Date(Date.parse(suggestedStartDate)),new Date(Date.parse(endDate)),CIQ.store.state.markerSet
                )
                CIQ.loadChart(list, CIQ.addMarker)
            }

            var newQuotes = quoteFeedSimulator.formatChartData(response);
            //console.log(newQuotes)
            cb({
                quotes: newQuotes, 
                upToDate: endDate.getTime() >=  Date.now(),
                moreAvailable: suggestedStartDate.getTime() > 0
            });
        }else{
            cb({error: response ? response :status})
        }
    })

}

quoteFeedSimulator.filterMarkerDate = function(start_date,end_date,markerSet){
    let list = []
    let _date = {
        start: jutils.formatDate(start_date,"YYYYMMDD"),
        end: jutils.formatDate(end_date,"YYYYMMDD")
    }
    for(var date in markerSet){
        let markerSetDate = markerSet[date].DT.slice(0,4)+markerSet[date].DT.slice(5,7)+markerSet[date].DT.slice(8,10)
        if(markerSetDate>_date.start && markerSetDate<=_date.end){
            list.push(markerSet[date])
        }
    }
    //console.log(_date,list)
    return list
}

quoteFeedSimulator.formatChartData = function(response){
    var data = JSON.parse(response)
    if(data == null){
        data = []
    }
    //console.log("response: ",data)
    var newQuotes = [];
    var oneDay = (24 *60 *60 *1000) * 0
    //var objIndicatorList = CIQ.objIndicator
    try{
        if('High' in data[0]){
            for (var i = 0; i < data.length; i++) {
                newQuotes[i] = {};
                var datatime = new Date(data[i].DT)
                var offset = new Date().getTimezoneOffset() * 60 * 1000
                
                newQuotes[i].DT = new Date(datatime.setTime(datatime.getTime() + offset));
               // console.log(newQuotes[i].DT)
                newQuotes[i].Open = data[i].Open;
                newQuotes[i].High = data[i].High;
                newQuotes[i].Low = data[i].Low;
                newQuotes[i].Close = data[i].Close;
                newQuotes[i].Volume = data[i].Volume;
    
                for(var j in CIQ.objIndicator){
                    var str = j==0?'indicator_Close':`indicator${Number(j)+1}_Close`;
                    newQuotes[i][CIQ.objIndicator[j]] = data[i][str];
                }
            } 
            CIQ.stxx.setChartType("candle"); 
            var node = document.querySelector("cq-menu-container[cq-name = 'menuChartStyle']")
            for(var i = 0;i < node.children.length;i++){
                node.children[i].style.display = "inherit"
            }
        }else{
            for (var i = 0; i < data.length; i++) {
                newQuotes[i] = {};
                var datatime = new Date(data[i].DT)
                var offset = new Date().getTimezoneOffset() * 60 * 1000
                
                newQuotes[i].DT = new Date(datatime.setTime(datatime.getTime() + offset));
    
                newQuotes[i].Open = data[i].Close;
                newQuotes[i].High = data[i].Close;
                newQuotes[i].Low = data[i].Close;
                newQuotes[i].Close = data[i].Close;
                newQuotes[i].Volume = data[i].Close;
                for(var j in CIQ.objIndicator){
                    var str = j==0?'indicator_Close':`indicator${Number(j)+1}_Close`;
                    newQuotes[i][CIQ.objIndicator[j]] = data[i][str];
                }
            }
            CIQ.stxx.setChartType("line"); 
            var node = document.querySelector("cq-menu-container[cq-name = 'menuChartStyle']")
            for(var i = 0;i < node.children.length;i++){
                node.children[i].style.display = "inherit"
            }
            for(var i = 0;i < node.children.length;i++){
                if(node.children[i].firstChild.nodeValue != "Line"){
                    node.children[i].style.display = "none"
                }
            } 
        }
    }catch(err){}
       
    //console.log(newQuotes);
    return newQuotes;
}

export default quoteFeedSimulator;