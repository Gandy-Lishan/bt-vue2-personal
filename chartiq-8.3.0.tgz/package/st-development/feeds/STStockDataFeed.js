// -------------------------------------------------------------------------------------------
// Copyright 2001 - 2021, Sundial Capital Research, Inc. All rights reserved
// -------------------------------------------------------------------------------------------
const quoteFeedSimulator = {};
import {config} from "./STDataFeedAccessUrl.js"
import {CIQ} from "chartiq/js/standard.js"

quoteFeedSimulator.sendAjax = function (url, cb) {
	var server = new XMLHttpRequest();   
	url += (url.indexOf("?") === -1 ? "?" : "&") + new Date().getTime();
	server.open("GET", url);

    server.setRequestHeader("Authorization", "Basic " + btoa(config.username+":"+config.password)); 
    
	server.onload = function () {
		cb(this.status, this.responseText);
	};
	server.onerror = function () {
		cb(500);
	};
	server.send();
};

quoteFeedSimulator.url = config.pairDataUrl;
quoteFeedSimulator.year5 = 5 * 365 * 24 * 60 * 60 * 1000

/**
 * 
 * @param {*} symbol symbolId
 * @param {*} startDate 
 * @param {*} endDate 
 * @param {*} params The list of parameters
 * @param {*} cb The processing function
 */

quoteFeedSimulator.getAllSymbols  = function(){
    var url = config.getAllSymbols;
    this.sendAjax(url,function(status,response){
        if (status != 200) return;
        try {
            CIQ.indicators = []
            response = JSON.parse(response);
            // var symbols = response.payload.symbols;
            for(var i=0;i<response.length;i++){
                var item = {
                    name:response[i].chart_name,
                    url:response[i].url
                };
            CIQ.indicators.push(item)

            }
            // CIQ.Studies.studyLibrary["ST "+response[i].chart_name] = {
            //     inputs: { Period: 13, Overlay: false,url:response[i].url},
            //     outputs: {indicatorClose:"pink"}
            // };
            // obj.reslust = response;
        } catch (e) {}
    })
   
}
// https://05kv55a2v9.execute-api.us-east-1.amazonaws.com/dev/pair_data?symbol=SPY&indicator=etf_spy&indicator_2=etf_qqq&indicator_3=st_combined&indicator_4=model_aim&indicator_5=model_stem&start=2010-05-01&end=2020-07-01
// quoteFeedSimulator.fetchInitialData = function(symbol,startDate,endDate,params,cb){
//     var start = config.timestampToTime(Date.parse(startDate)- this.year5) 
//     var end = config.timestampToTime(Date.parse(endDate)- this.year5)
//     CIQ.symbol = symbol;
//     if (params.symbolObject.indicator === undefined){
//         if (CIQ.objIndicator === undefined){
//             params.symbolObject.indicator = symbol
//             CIQ.objIndicator = params.symbolObject.indicator
//         }
//     }else {
//        CIQ.objIndicator = params.symbolObject.indicator
//     }
    
    
//     var queryUrl = this.url + 
//     "?symbol=" + symbol + 
//     "&indicator=" + CIQ.objIndicator +
//     "&start="+start+
//     "&end=" + end;


//     CIQ.symbol = symbol;
//     try{
//     var div = document.querySelectorAll(".cq-comparison-new")[0].querySelectorAll("div")[0]

// 	var indicators =JSON.parse(window.localStorage.getItem("FavoriteSymbol"))
// 	if (indicators.indexOf(CIQ.symbol) === -1){
// 		// del
// 		div.innerText = "add Favorite Symbol";
// 		div.attributes.stxtap.nodeValue="SentimentLook.addSymbolCookie()";
// 	}else{
//         div.innerText = "del Favorite Symbol";
// 		div.attributes.stxtap.nodeValue="SentimentLook.delSymbolCookie()";
//     }
//     }catch(e){}



//     this.sendAjax(queryUrl,function (status, response){
//         if (status == 200){
           
//             var newQuotes = quoteFeedSimulator.formatChartData(response);
//             cb({quotes:newQuotes});
//         }else{
//             cb({error:response ? response : status});
//         }
//     });
//     // this.getAllSymbols()
    
//     // this.getIndicatorMatedata(params)
//     // location.reload();




// };

quoteFeedSimulator.fetchInitialData = function(symbol,startDate,endDate,params,cb){
    // initEndDate for testing
    
    this.initEndDate = endDate 
    var start = config.timestampToTime(Date.parse(startDate)) 
    var end = config.timestampToTime(Date.parse(endDate))
    //this.fetchStatus(symbol,start,end,params.symbolObject.indicator)

    CIQ.symbol = symbol;
    // console.log(params.symbolObject.indicator)
    // console.log(CIQ.objIndicator)
    if (params.symbolObject.indicator === undefined){
        if (CIQ.objIndicator === undefined){
            CIQ.objIndicator = symbol
            // AAPL
        }
    }else if(params.symbolObject.indicator.length == 0){
        // when first time loading a technical indicator, no params of indicators in query, pick default value
        CIQ.objIndicator = [symbol]
    }else {
        // console.log(window.sessionStorage.getItem('isValid').toString())
        // if(window.sessionStorage.getItem('isValid').toString()==false.toString()){
        //     alert('no content in this indicator')
        //     CIQ.objIndicator = symbol    
        // }else{CIQ.objIndicator = params.symbolObject.indicator}  
        CIQ.objIndicator = params.symbolObject.indicator
    }

    var new_str = ''
    if(params.symbolObject.indicator === undefined){
        new_str += '&indicator=' +CIQ.objIndicator;
    }else{
        for ( var  i = 0; i < CIQ.objIndicator.length; i++) {
            new_str += `${i==0?'&indicator=':`&indicator_${i+1}=`}`+CIQ.objIndicator[i];
        }
    }   
    
    var queryUrl = this.url + 
    "?symbol=" + symbol + 
    new_str +
    "&start="+start+
    "&end=" + end

    console.log(queryUrl);
    // set initial symbol value to the form
    utils.setSymbol(symbol)

    CIQ.symbol = symbol;
    try{
    var div = document.querySelectorAll(".cq-comparison-new")[0].querySelectorAll("div")[0]

	var indicators =JSON.parse(window.localStorage.getItem("FavoriteSymbol"))
	if (indicators.indexOf(CIQ.symbol) === -1){
		// del
		div.innerHTML = "<svg t='1638255076868' class='button_icon' viewBox='0 0 1024 1024' version='1.1' xmlns='http://www.w3.org/2000/svg' p-id='2654' width='200' height='200'><path d='M885.942179 427.687756l-267.445168-22.933315-104.470353-246.470461L409.553235 404.75444l-267.336698 22.933315 202.846918 175.770236-60.789505 261.34524 229.753731-138.569986 229.859132 138.569986-60.785411-261.34524L885.942179 427.687756zM514.026658 656.403854l-139.875724 84.425831 37.038568-159.160953-123.591853-106.975407 162.91751-14.053064 63.511499-150.116973 63.620993 150.116973 162.860205 14.053064-123.534548 106.975407 37.038568 159.160953L514.026658 656.403854z' p-id='2655' fill='#1296db'></path></svg><span>Add to watchlist</span>";
		div.attributes.stxtap.nodeValue="SentimentLook.addSymbolCookie()";
	}else{
        div.innerText = "del Favorite Symbol";
		div.attributes.stxtap.nodeValue="SentimentLook.delSymbolCookie()";
    }
    }catch(e){}



    this.sendAjax(queryUrl,function (status, response){
        if (status == 200){
            var newQuotes = quoteFeedSimulator.formatChartData(response);
            //window.sessionStorage.setItem('isValid', true)
            cb({quotes:newQuotes});
        }else{
            cb({error:response ? response : status});
        }
    });
    // this.getAllSymbols()
    
    // this.getIndicatorMatedata(params)
    // location.reload();
};


//注释掉是为了不让它刷新时间
quoteFeedSimulator.fetchUpdateData = function (symbol, startDate, params,cb){
    var start = config.timestampToTime(Date.parse(this.initEndDate))

    // if (params.symbolObject.indicator === undefined){
    //     params.symbolObject.indicator = symbol
    // }

    // fetch indicator
    var new_str = ''
    if(params.symbolObject.indicator === undefined){
        //console.log('CIQ.objIndicator is not defined');
        new_str += '&indicator=' +CIQ.objIndicator;
    }else{
        for ( var  i = 0; i < CIQ.objIndicator.length; i++) {
            new_str += `${i==0?'&indicator=':`&indicator_${i+1}=`}`+CIQ.objIndicator[i];
        }
    }   

    var queryUrl = this.url + 
       "?symbol=" + symbol + 
        new_str +
       "&start="+start;
    //console.log('Update url:'+queryUrl);


    this.sendAjax(queryUrl,function(status, response){
        if (status == 200){
            var newQuotes = quoteFeedSimulator.formatChartData(response);
            cb({quotes:newQuotes});
        }else{
            cb({error:response ? response:status});
        }

        
    });
};

quoteFeedSimulator.fetchPaginationData = function(symbol, suggestedStartDate, endDate, params,cb){
    var start = config.timestampToTime(Date.parse(suggestedStartDate)) 
    var end = config.timestampToTime(Date.parse(endDate)) 
 
    var new_str = ''
    if(params.symbolObject.indicator === undefined){
        //console.log('CIQ.objIndicator is not defined');
        new_str += '&indicator=' +CIQ.objIndicator;
    }else{
        for ( var  i = 0; i < CIQ.objIndicator.length; i++) {
            new_str += `${i==0?'&indicator=':`&indicator_${i+1}=`}`+CIQ.objIndicator[i];
        }
    }   
    var queryUrl = this.url + 
       "?symbol=" + symbol + 
        new_str +
       "&start="+start+
       "&end=" + end;
    //console.log('Pagination url:'+queryUrl);

    this.sendAjax(queryUrl, function(status,response){
        if(status == 200){
            var newQuotes = quoteFeedSimulator.formatChartData(response);
         
            cb({
                quotes: newQuotes, 
                upToDate: endDate.getTime() >=  Date.now(),
                moreAvailable: suggestedStartDate.getTime() > 0
            });
        }else{
            cb({error: response ? response :status})
        }
    })

}

quoteFeedSimulator.formatChartData = function(response){
    var data = JSON.parse(response)
    var newQuotes = [];
    var oneDay = (24 *60 *60 *1000) * 0
    //var objIndicatorList = CIQ.objIndicator
    for (var i = 0; i < data.length; i++) {
        newQuotes[i] = {};
        var datatime = new Date(data[i].DT)
        newQuotes[i].DT = new Date(datatime.setTime(datatime.getTime()+oneDay));
        newQuotes[i].Open = data[i].Open;
        newQuotes[i].High = data[i].High;
        newQuotes[i].Low = data[i].Low;
        newQuotes[i].Close = data[i].Close;
        newQuotes[i].Volume = data[i].Volume;
        for(var j in CIQ.objIndicator){
            var str = j==0?'indicator_Close':`indicator${Number(j)+1}_Close`;
            newQuotes[i][CIQ.objIndicator[j]] = data[i][str];
        }
    }    
    //console.log(newQuotes);
    return newQuotes;
}

export default quoteFeedSimulator;