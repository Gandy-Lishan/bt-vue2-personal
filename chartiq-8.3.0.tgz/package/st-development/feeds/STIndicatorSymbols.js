// -------------------------------------------------------------------------------------------
// Copyright 2001 - 2021, Sundial Capital Research, Inc. All rights reserved
// -------------------------------------------------------------------------------------------

import {config}  from "./STDataFeedAccessUrl.js";
// import { CIQ, quoteFeed, symbolLookupBase } from "./jsDemo/js/standard.js";
import { CIQ, quoteFeed, symbolLookupBase } from "chartiq/js/standard.js";
import axios from "axios"
CIQ.activateImports(quoteFeed, symbolLookupBase); // so we can use CIQ.inheritsFrom
/**
 * An example of an asynchronous Lookup.Driver that uses ChartIQ's suggestive search as its source for symbol search
 * @name CIQ.ChartEngine.Driver.Lookup.ChartIQ
 * @constructor
 * @param {string[]} exchanges An array of exchanges that can be searched against
 * @private
 * @since 6.0.0
 */
CIQ.ChartEngine.Driver.Lookup.ChartIQ = function (exchanges) {
	this.exchanges = exchanges;
	this.requestCounter = 0; //used to invalidate old requests
};

// CIQ.postAjax = function (params, arg1, arg2, arg3, arg4) {
//     //console.log("postajax")
// 	var server = new XMLHttpRequest();   
// 	// url += (url.indexOf("?") === -1 ? "?" : "&") + new Date().getTime();
// 	server.open("GET", params.url);

//     server.setRequestHeader("Authorization", "Basic " + btoa(config.username+":"+config.password));  

// 	server.onload = function () {
// 		params.cb(this.status, this.responseText,{results:params.results,text:params.text});
// 	};
// 	server.onerror = function () {
// 		cb(500);
// 	};
// 	server.send();
// };
CIQ.inheritsFrom(
	CIQ.ChartEngine.Driver.Lookup.ChartIQ,
	CIQ.ChartEngine.Driver.Lookup
);
/**
 * @memberof CIQ.ChartEngine.Driver.Lookup.ChartIQ
 * @param {string} text Text to search for
 * @param {string} filter Any filter to be applied to the search results
 * @param {number} maxResults Max number of results to return from the server
 * @param {function} cb Callback upon results
 * @private
 * @since 6.0.0
 */
 const collator = new Intl.Collator('en');
 function SortArray(x, y){
    return collator.compare(x.data.symbol, y.data.symbol);
}
async function loadStocksList(){
    let list = []
    if (CIQ.store.state.stocksList.length != 0) {
        list = CIQ.store.state.stocksList
    }else{
        var loader = document.querySelector(".loaderLookup");
        if (loader) loader.show();  
           
        const res = await CIQ.axios.get(
            config.getStocks, {cache:true}
        )
        loader.hide()
        list = res.data
        CIQ.store.commit('getStocksList',res.data);
    }
    return list
}
async function loadIndexsList(){
    let list = []
    
    if (CIQ.store.state.indexsList.length != 0) {
        list = CIQ.store.state.indexsList
    }else{
        var loader = document.querySelector(".loaderLookup");
        if (loader) loader.show();    
        const res = await CIQ.axios.get(
            config.getIndexes, {cache:true}
        )
        loader.hide()
        list = res.data
        CIQ.store.commit('getIndexsList',res.data);  
    }
    return list
}

CIQ.ChartEngine.Driver.Lookup.ChartIQ.prototype.acceptText = async function (
	text,
	filter,
	maxResults,
	cb
) {
    
    if (filter == 'INDEXES'){
			var results = [];
            let indexsList = await loadIndexsList()
			for (var i = 0; i < indexsList.length; i++) {
				var fields = indexsList[i];
                
                var item = {
                    symbol: fields.symbol,
                    name: fields.name,
                    exchDisp: ""
                };

                if (item.symbol.indexOf(text) === -1 && item.symbol.indexOf(text.toUpperCase()) === -1)
                {
                    continue
                }
				results.push({
					display: [item.symbol, item.name, item.exchDisp],
					data: item
				});
			}
            results.sort(SortArray)
			cb(results);    
	}else if (filter == 'STOCKS') {
        var results = [];
        let stocksList = await loadStocksList()
        for (var i = 0; i < stocksList.length; i++) {
            var fields = stocksList[i];
            var item = {
                symbol: fields.stock,
                name: fields.name,
                exchDisp: " "
            };
            if (item.symbol.indexOf(text) === -1 && item.symbol.indexOf(text.toUpperCase()) === -1)
            {
                continue
            }
            results.push({
                display: [item.symbol, item.name, item.exchDisp],
                data: item
            });
        }
        results.sort(SortArray)
        cb(results);
    } else if (filter == 'FAVORITES'){
        var results = []
        var resu = CIQ.store.state.favoriteSymbolList
        // var resu = []
        // const data = await CIQ.getFavorite()
        // try{
        //     resu = JSON.parse(data.favorite_indicator)
        // }catch{}

            try {
                

                var listStock = []
                if(CIQ.store.state.stocksList.length == 0){
                    var res = await loadStocksList()
                    listStock = res.map(_obj=>{
                        var newObj = {}
                        newObj['name'] = _obj.name
                        newObj['url'] = _obj.stock
                        return newObj
                    })
                }else{
                    listStock = CIQ.store.state.stocksList.map(_obj=>{
                        var newObj = {}
                        newObj['name'] = _obj.name
                        newObj['url'] = _obj.stock
                        return newObj
                    })
                }

                var listIndex = []
                if(CIQ.store.state.indexsList.length == 0){
                    var res = await loadIndexsList()
                    listIndex = res.map(_obj=>{
                        var newObj = {}
                        newObj['name'] = _obj.name
                        newObj['url'] = _obj.symbol
                        return newObj
                    })
                }else{
                    listIndex = CIQ.store.state.indexsList.map(_obj=>{
                        var newObj = {}
                        newObj['name'] = _obj.name
                        newObj['url'] = _obj.symbol
                        return newObj
                    })
                }

                var list = [...listStock,...listIndex]
                
                resu.forEach(element => {
                    var item = {
                        symbol: element,
                        name: list.find(item=>item.url == element).name,
                        exchDisp: ""
                    }
                    
                    if (item.symbol.toUpperCase().indexOf(text.toUpperCase()) !== -1){
                        results.push({
                            display: [item.symbol, item.name, item.exchDisp],
                            data: item
                        });
                    }         
                }); 
               // console.log(results)
            } catch (e) {}
            results.sort(SortArray)    
            cb(results);
    }
   

};
export { CIQ };
