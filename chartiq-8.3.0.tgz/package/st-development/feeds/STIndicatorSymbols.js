// -------------------------------------------------------------------------------------------
// Copyright 2001 - 2021, Sundial Capital Research, Inc. All rights reserved
// -------------------------------------------------------------------------------------------

import {config}  from "./STDataFeedAccessUrl.js";
// import { CIQ, quoteFeed, symbolLookupBase } from "./jsDemo/js/standard.js";
import { CIQ, quoteFeed, symbolLookupBase } from "chartiq/js/standard.js";
CIQ.activateImports(quoteFeed, symbolLookupBase); // so we can use CIQ.inheritsFrom
/**
 * An example of an asynchronous Lookup.Driver that uses ChartIQ's suggestive search as its source for symbol search
 * @name CIQ.ChartEngine.Driver.Lookup.ChartIQ
 * @constructor
 * @param {string[]} exchanges An array of exchanges that can be searched against
 * @private
 * @since 6.0.0
 */
CIQ.ChartEngine.Driver.Lookup.ChartIQ = function (exchanges) {
	this.exchanges = exchanges;
	this.requestCounter = 0; //used to invalidate old requests
};

// CIQ.postAjax = function (params, arg1, arg2, arg3, arg4) {
//     //console.log("postajax")
// 	var server = new XMLHttpRequest();   
// 	// url += (url.indexOf("?") === -1 ? "?" : "&") + new Date().getTime();
// 	server.open("GET", params.url);

//     server.setRequestHeader("Authorization", "Basic " + btoa(config.username+":"+config.password));  

// 	server.onload = function () {
// 		params.cb(this.status, this.responseText,{results:params.results,text:params.text});
// 	};
// 	server.onerror = function () {
// 		cb(500);
// 	};
// 	server.send();
// };
CIQ.inheritsFrom(
	CIQ.ChartEngine.Driver.Lookup.ChartIQ,
	CIQ.ChartEngine.Driver.Lookup
);
/**
 * @memberof CIQ.ChartEngine.Driver.Lookup.ChartIQ
 * @param {string} text Text to search for
 * @param {string} filter Any filter to be applied to the search results
 * @param {number} maxResults Max number of results to return from the server
 * @param {function} cb Callback upon results
 * @private
 * @since 6.0.0
 */
 const collator = new Intl.Collator('en');
 function SortArray(x, y){
    return collator.compare(x.data.symbol, y.data.symbol);
}

CIQ.ChartEngine.Driver.Lookup.ChartIQ.prototype.acceptText = function (
	text,
	filter,
	maxResults,
	cb
) {
    //var url;
    if (filter == 'INDEXES'){
			var results = [];
			for (var i = 0; i < CIQ.store.state.indexsList.length; i++) {
				var fields = CIQ.store.state.indexsList[i];
                
                var item = {
                    symbol: fields.symbol,
                    name: fields.name,
                    exchDisp: ""
                };

                if (item.symbol.indexOf(text) === -1 && item.symbol.indexOf(text.toUpperCase()) === -1)
                {
                    continue
                }
				results.push({
					display: [item.symbol, item.name, item.exchDisp],
					data: item
				});
			}
            results.sort(SortArray)
			cb(results); 
        
    //     this.url= config.getIndexes;
    //     url =config.getIndexes;
    //     function handleResponse(status, response,params) {
	// 	// if (counter < self.requestCounter) return;
	// 	if (status != 200) return;
	// 	try {
	// 		response = JSON.parse(response);
	// 		// var symbols = response.payload.symbols;
	// 		var results = [];
	// 		for (var i = 0; i < response.length; i++) {
	// 			var fields = response[i];
                
    //             var item = {
    //                 symbol: fields.symbol,
    //                 name: fields.name,
    //                 exchDisp: ""
    //             };

    //             if (item.symbol.indexOf(params.text) === -1 && item.symbol.indexOf(params.text.toUpperCase()) === -1)
    //             {
    //                 continue
    //             }
	// 			results.push({
	// 				display: [item.symbol, item.name, item.exchDisp],
	// 				data: item
	// 			});
	// 		}
    //         results.sort(SortArray)
	// 		cb(results);
	// 	} catch (e) {}
    // }
	// CIQ.postAjax({ url: url, cb: handleResponse, text:text});   
	}else if (filter == 'STOCKS') {
        var results = [];
        for (var i = 0; i < CIQ.store.state.stocksList.length; i++) {
            var fields = CIQ.store.state.stocksList[i];
            var item = {
                symbol: fields.stock,
                name: fields.name,
                exchDisp: " "
            };
            if (item.symbol.indexOf(text) === -1 && item.symbol.indexOf(text.toUpperCase()) === -1)
            {
                continue
            }
            results.push({
                display: [item.symbol, item.name, item.exchDisp],
                data: item
            });
        }
        results.sort(SortArray)
        cb(results);
        // url = config.getStocks;
        // this.url= config.getStocks;
        // function handleResponse(status, response,params) {
        //     if (status != 200) return;
        //     try {
        //         response = JSON.parse(response);
        //         var results = [];
        //         for (var i = 0; i < response.length; i++) {
        //             var fields = response[i];
        //             var item = {
        //                 symbol: fields.stock,
        //                 name: fields.name,
        //                 exchDisp: " "
        //             };
        //             if (item.symbol.indexOf(params.text) === -1 && item.symbol.indexOf(params.text.toUpperCase()) === -1)
        //             {
        //                 continue
        //             }
        //             results.push({
        //                 display: [item.symbol, item.name, item.exchDisp],
        //                 data: item
        //             });
        //         }
        //         results.sort(SortArray)
        //         cb(results);
        //     } catch (e) {}
        // }
        // CIQ.postAjax({ url: url, cb: handleResponse , text:text});
    } else if (filter == 'FAVORITES'){
        var results = []
        CIQ.getFavorite().then(data=>{
            var resu = JSON.parse(data.favorite_symbol)
            try {
                resu.forEach(element => {
                    var item = {
                        symbol: element,
                        name: "",
                        exchDisp: ""
                    }
                    if (item.symbol.toUpperCase().indexOf(text.toUpperCase()) !== -1){
                        results.push({
                            display: [item.symbol, item.name, item.exchDisp],
                            data: item
                        });
                    }         
                });  
            } catch (e) {}
            results.sort(SortArray)    
            cb(results);
        })   
        // function handleResponse(status, response,params) {
        //     // if (counter < self.requestCounter) return;
        //     var results = []
        //     var resu =JSON.parse(window.localStorage.getItem("FavoriteSymbol"))
        //     try {
        //     resu.forEach(element => {
        //         var item = {
        //             symbol: element,
        //             name: "",
        //             exchDisp: ""
        //         }
        //             results.push({
        //                 display: [item.symbol, item.name, item.exchDisp],
        //                 data: item
        //             });
        //     });
           
        //     } catch (e) {}
        //     results.sort(SortArray)
        //     cb(results);
        // }
        // var url = config.getStocks;
        // CIQ.postAjax({ url: url, cb: handleResponse, text:text}); 
        // }else  {
        // url = config.getStocks;
        // this.url= config.getStocks;
        // var results = [];
        // function StockResponse(status, response,params) {
        //     if (status != 200) return;
        //     try {
        //         response = JSON.parse(response);
        //         var results = params.results;
        //         for (var i = 0; i < response.length; i++) {
        //             var fields = response[i];
        //             var item = {
        //                 symbol: fields.stock,
        //                 name: fields.name,
        //                 exchDisp: " "
        //             };
        //             if (item.symbol.indexOf(params.text) === -1 && item.symbol.indexOf(params.text.toUpperCase()) === -1)
        //             {
        //                 continue
        //             }
        //             results.push({
        //                 display: [item.symbol, item.name, item.exchDisp],
        //                 data: item
        //             });
        //         }
        //         this.url= config.getIndexes;
        //         CIQ.postAjax({url:config.getIndexes,cb:IndexeResponse,results:results, text:text})
        //     } catch (e) {}
        // }

        // function IndexeResponse(status, response,params) {
        //     // if (counter < self.requestCounter) return;
        //     if (status != 200) return;
        //     try {
        //         response = JSON.parse(response);
        //         // var symbols = response.payload.symbols;
        //         var results = params.results;
        //         for (var i = 0; i < response.length; i++) {
        //             var fields = response[i];
        //             var item = {
        //                 symbol: fields.symbol,
        //                 name: fields.name,
        //                 exchDisp: " "
        //             };
        //             if (item.symbol.indexOf(params.text) === -1 && item.symbol.indexOf(params.text.toUpperCase()) === -1)
        //             {
        //                 continue
        //             }

        //             results.push({
        //                 display: [item.symbol, item.name, item.exchDisp],
        //                 data: item
        //             });
        //         }
        //         results.sort(SortArray)
        //         cb(results)
        //     } catch (e) {}
        // }
        // CIQ.postAjax({ url: url, cb: StockResponse,results:[], text:text});
    }
   

};
export { CIQ };
