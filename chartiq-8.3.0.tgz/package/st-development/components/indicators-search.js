import {CIQ} from "chartiq/js/standard.js"
import {config} from "../feeds/STDataFeedAccessUrl.js"
import axios from "axios"
import { SortArray } from "../js/STTools.js";
//import store from '../../../../src/store/store.ts'
let __js_webcomponents_indicatorsLookup_ = (_exports) => {

    /* global _CIQ, _timezoneJS, _SplinePlotter */
    
    
    var CIQ = typeof _CIQ !== "undefined" ? _CIQ : _exports.CIQ;
    if (!CIQ.ChartEngine.Driver) {
        console.error(
            "lookup component requires first activating quoteFeed feature."
        );
    } else if (!CIQ.ChartEngine.Driver.Lookup) {
        console.error(
            "lookup component requires first activating symbolLookupBase feature."
        );
    } else {
        /**
         * Symbol lookup component `<cq-lookup>`.
         *
         * A {@link CIQ.ChartEngine.Driver.Lookup} must be connected to this web component. The lookup
         * driver searches financial exchanges for symbols that match the text entered in the
         * component's input field.
         *
         * The symbol lookup can be toggled using the Ctrl+Alt+S keystroke combination (see the
         * `symbolLookup` action in `hotkeyConfig.hotkeys` in *js/defaultConfiguration.js*).
         *
         * A default lookup driver is specified in the chart configuration object (see the
         * <a href="tutorial-Chart%20Configuration.html" target="_blank">Chart Configuration</a>
         * tutorial).
         *
         * You can provide a different driver in the following ways:
         * - Assign the driver to the
         *   <a href="tutorial-Chart%20Configuration.html#lookupdriver" target="_blank">
         *   <code class="codeLink">lookupDriver</code></a> property of the chart configuration
         *   object
         * - Connect the driver to this component using
         *   [setDriver]{@link WebComponents.cq-lookup#setDriver}
         * - Add the driver to the UI context with {@link CIQ.UI.Context#setLookupDriver}
         *
         * **Note:** If the lookup component is unable to access a lookup driver, the component's
         * input field is active, but the component does not produce results.
         *
         * **Keyboard control**
         *
         * When selected with tab key navigation and activated with Return/Enter, this component has
         * the following internal controls:
         * - Up/Down arrow &mdash; Move selection between search input, filters, and search results
         * - Left/Right arrow &mdash; Switch between search result filters
         *
         * **Attributes**
         * | Name | Description | Valid Values |
         * | ---- | ----------- | ------------ |
         * | <code style="white-space: nowrap">cq-keystroke-claim</code> | Enables processing of keyboard input. | <a href="https://developer.mozilla.org/en-US/docs/Web/HTML/Attributes#boolean_attributes" target="_blank">Boolean attribute</a> |
         * | <code style="white-space: nowrap">cq-keystroke-default</code> | Enables the component to respond to keystrokes when the lookup input field does not have focus. <p style="margin-bottom: 0">**Warning:** This feature may conflict with keyboard shortcuts set in other components. | <a href="https://developer.mozilla.org/en-US/docs/Web/HTML/Attributes#boolean_attributes" target="_blank">Boolean attribute</a> |
         * | <code style="white-space: nowrap">cq-uppercase</code> | Forces text to uppercase. | <a href="https://developer.mozilla.org/en-US/docs/Web/HTML/Attributes#boolean_attributes" target="_blank">Boolean attribute</a> |
         * | <code style="white-space: nowrap">cq-exchanges</code> | Specifies a list of financial exchanges searched by the lookup driver. Overrides the `exchanges` parameter of {@link CIQ.ChartEngine.Driver.Lookup}. | Comma-delimited list of exchange names; for example, "futures,govt,muni,corp"|
         *
         * **Customization**
         *
         * To hide the lookup results window, modify the CSS as follows:
         * ```css
         * .stxMenuActive cq-lookup-results { opacity: 0 }
         * ```
         *
         * To preload default results (rather than an empty result pane) on initial load , set an
         * `onChartReady` handler in the chart configuration object (see the
         * <a href="tutorial-Chart%20Configuration.html" target="_blank">Chart Configuration</a>
         * tutorial); for example:
         *
         * ```
         * config.onChartReady = (stx) => {
         *     const defaultResults = [
         *         {
         *             "display": ["KW", "Kennedy - Wilson Holdings Inc", "NYSE"],
         *             "data": {
         *                 "symbol": "KW",
         *                 "name": "Kennedy - Wilson Holdings Inc",
         *                 "exchDisp ": "NYSE"
         *             }
         *         },
         *         {
         *             "display": ["RWR", "SPDR Series Trust - SPDR DJ Wilshire REIT ETF", "NYSEArca"],
         *             "data": {
         *                 "symbol": "RWR",
         *                 "name": "SPDR Series Trust - SPDR DJ Wilshire REIT ETF",
         *                 "exchDisp": "NYSEArca"
         *             }
         *         }
         *     ];
         *
         *     const UISymbolLookup = document.querySelector(".ciq-search cq-lookup");
         *     UISymbolLookup.results(defaultResults);
         * }
         * ```
         *
         * @namespace WebComponents.cq-lookup
         * @since
         * - 4.0.0 Added optional `cq-uppercase` attribute.
         * - 7.4.0 Added optional `cq-exchanges` attribute.
         * - 8.3.0 Enabled internal keyboard navigation and selection.
         *
         * @example
         * <cq-lookup cq-keystroke-claim cq-uppercase cq-keystroke-default>
         *     <cq-lookup-input cq-no-close>
         *         <input type="text" spellcheck="false" autocomplete="off"
         *                autocorrect="off" autocapitalize="none" name="symbol"
         *                placeholder="Enter Symbol">
         *         <cq-lookup-icon></cq-lookup-icon>
         *     </cq-lookup-input>
         *     <cq-lookup-results>
         *         <cq-lookup-filters cq-no-close>
         *             <cq-filter class="true">ALL</cq-filter>
         *             <cq-filter>STOCKS</cq-filter>
         *             <cq-filter>FX</cq-filter>
         *             <cq-filter>INDEXES</cq-filter>
         *             <cq-filter>FUNDS</cq-filter>
         *             <cq-filter>FUTURES</cq-filter>
         *         </cq-lookup-filters>
         *         <cq-scroll></cq-scroll>
         *     </cq-lookup-results>
         * </cq-lookup>
         */
        class IndicatorsLookup extends CIQ.UI.ContextTag {
            constructor() {
                super();
                this.usingEmptyDriver = false;
                this.currentFilter = null;
                // Will hold references to filter tabs for keyboard navigation
                this.filterElements = null;
                this.params = {};
            }
    
            /**
             * With the decoupling of the uiHelper to the Lookup.Driver you must be sure to include both an argument for maxResults and the closure to handle the results.
             * maxResults must either be a number or a string to result in default value of 100.
             * @alias acceptText
             * @memberof WebComponents.cq-lookup#
             * @since 3.0.0
             */

            acceptText(value, filter) {
                var self = this;
                if (!this.params.driver) {
                    if (this.context.lookupDriver) {
                        this.setDriver(this.context.lookupDriver);
                    } else {
                        this.setDriver(new CIQ.ChartEngine.Driver.Lookup());
                        this.usingEmptyDriver = true;
                    }
                }
                var restoredExchanges = this.params.driver.exchanges;
                function closure(results) {
                    self.params.driver.exchanges = restoredExchanges;
                    var results = results
                    self.results(results);
                    
                    var stClose = document.getElementsByClassName("st-close")
                    if(filter == 'FAVORITES'){
                        for(var el = 0;el<stClose.length;el++){     
                            var removeFavorite = function(data){
                                var url = data
                                CIQ.UI.stxtap(stClose[el],()=>{
                                CIQ.getFavorite().then(data=>{
                                    var favoriteSymbolList = JSON.parse(data.favorite_symbol)
                                    var favoriteIndicatorList = JSON.parse(data.favorite_indicator)
                                        for(var item in favoriteIndicatorList){
                                            if(favoriteIndicatorList[item].url == url){
                                                favoriteIndicatorList.splice(item,1)
                                                CIQ.updateFavorite(JSON.stringify(favoriteIndicatorList),JSON.stringify(favoriteSymbolList))
                                            }
                                        }
                                    })
                                });       
                                // stClose[el].addEventListener('click',function(){
                                //     console.log('remove f')
                                //     CIQ.getFavorite().then(data=>{
                                //         console.log(url)
                                //         var favoriteSymbolList = JSON.parse(data.favorite_symbol)
                                //         var favoriteIndicatorList = JSON.parse(data.favorite_indicator)
                                //             for(var item in favoriteIndicatorList){
                                //                 if(favoriteIndicatorList[item].url == url){
                                //                     favoriteIndicatorList.splice(item,1)
                                //                     CIQ.updateFavorite(JSON.stringify(favoriteIndicatorList),JSON.stringify(favoriteSymbolList))
                                //                 }
                                //             }
                                //         })
                                // },false);
                            }
                            removeFavorite(results[el].data.symbol)
                        }               
                    }
                }
                var exchanges = this.getAttribute("cq-exchanges");
                if (exchanges) this.params.driver.exchanges = exchanges.split(",");
                this.filters_data(value, filter, null, closure)  
            }
            // collator = new Intl.Collator('en');
            // SortArray(x, y){
            //     return collator.compare(x.data.symbol, y.data.symbol);
            // }

            filters_data(value,filter,params, closure){
                
                CIQ.symbols = []
                if (filter == "ALL"){
                    var results = []
                    for(var i=0;i<CIQ.store.state.allSymbolsList.length;i++){
                        var fields = CIQ.store.state.allSymbolsList[i]
                        
                        var item = {
                            name: fields.chart_name,
                            url: fields.url,
                            updated: fields.updated,
                        };

                        if (CIQ.symbols.indexOf(item.name) !==-1){
                            continue;
                        }
                        if (item.name.toUpperCase().indexOf(value.toUpperCase()) === -1){
                            continue;
                        }
                        results.push({
                            display:[item.name,item.updated],
                            data:item
                        })
                    }
                    //results.sort(SortArray)
                    closure(results)
                    
                    // function StockResponse(status, response,params) {
                    //     if (status != 200) return;
                    //     try {
                    //         response = JSON.parse(response);
                    
                    //         var results = params.results;
          			// 		for(var i=0;i<response.length;i++){
                    //             var item = {
                    //                 name:response[i].chart_name,
                    //                 url:response[i].url
                    //             };

                    //             if (CIQ.symbols.indexOf(item.name) !==-1){
                    //                 continue;
                    //             }
                    //             if (item.name.toUpperCase().indexOf(value.toUpperCase()) === -1){
                    //                 continue;
                    //             }
                    //             results.push({
                    //                 display:[item.name],
                    //                 data:item
                    //             })
                    //         }
						
                    //     closure(results)
                    //     } catch (e) {}
                    // }
                    // CIQ.postAjax({ url: config.getAllSymbols, cb: StockResponse,results:[]});
                }else if (filter == "FAVORITES"){  
                        var results = []
                        CIQ.getFavorite().then(data=>{
                            var resu = JSON.parse(data.favorite_indicator)
                            try {
                                resu.forEach(element => {
                                    var item = {
                                        symbol: element.url,
                                        name: element.name,
                                        updated: CIQ.store.state.allSymbolsList.find(item=> {return item.url == element.url}).updated,
                                        exchDisp: ""
                                    }
                                    if (item.symbol.toUpperCase().indexOf(value.toUpperCase()) !== -1){
                                        if(CIQ.store.state.stocksList.find(i=>i.stock==item.symbol) || 
                                           CIQ.store.state.indexsList.find(i=>i.stock==item.symbol)){
                                            results.push({
                                                display: [item.symbol + ' Optix'],
                                                data: item
                                            });
                                        }else{
                                            results.push({
                                                display: [item.name, item.updated],
                                                data: item
                                            });
                                        }
                                        
                                    }         
                                });  
                            } catch (e) {}
                            //results.sort(SortArray)
                            closure(results);
                        })}                
                // }else{
                //     //stocks + indexes
                //     var results = []
                //     for (var i = 0; i < CIQ.store.state.stocksList.length; i++) {
                //         var fields = CIQ.store.state.stocksList[i];
                //         var item = {
                //             symbol: fields.stock,
                //             name: fields.name,
                //             exchDisp: " "
                //         };
                //         CIQ.symbols.push(fields.stock)
        
                //         if (item.symbol.toUpperCase().indexOf(value.toUpperCase()) === -1){
                //             continue;
                //         }
                //         // results.push({
                //         //     display: [item.symbol, item.name, item.exchDisp],
                //         //     data: item
                //         // });
                //         results.push({
                //             display: [item.symbol + ' Optix', item.name],
                //             data: item
                //         });
                //     }
                //     for (var i = 0; i < CIQ.store.state.indexsList.length; i++) {
                //         var fields = CIQ.store.state.indexsList[i];
                //         var item = {
                //             symbol: fields.symbol,
                //             name: fields.name,
                //             exchDisp: " "
                //         };

                //         if (item.symbol.toUpperCase().indexOf(value.toUpperCase()) === -1){
                //             continue;
                //         }
                //         results.push({
                //             display: [item.symbol + ' Optix', item.name],
                //             data: item
                //         });
                //         // results.push({
                //         //     display: [item.symbol, item.name],
                //         //     data: item
                //         // });
                //     }
                //     //results.sort(SortArray)
                //     closure(results)

                //     // var url = config.getStocks;
                //     // this.url= config.getStocks;
                //     // function StockResponse(status, response,params) {
                //     //     if (status != 200) return;
                //     //     try {
                //     //         response = JSON.parse(response);
                //     //         var results = params.results;
                //     //         for (var i = 0; i < response.length; i++) {
                //     //             var fields = response[i];
                //     //             var item = {
                //     //                 symbol: fields.stock,
                //     //                 name: fields.name,
                //     //                 exchDisp: " "
                //     //             };
                //     //             CIQ.symbols.push(fields.stock)
                
                       
                //     //             if (item.symbol.toUpperCase().indexOf(value.toUpperCase()) === -1){
                //     //                 continue;
                //     //             }
                //     //             results.push({
                //     //                 display: [item.symbol, item.name, item.exchDisp],
                //     //                 data: item
                //     //             });
                //     //             // results.push({
                //     //             //     display: [item.symbol + ' Optix'],
                //     //             //     data: item
                //     //             // });
                //     //         }
                //     //         this.url= config.getIndexes;
                //     //         CIQ.postAjax({url:config.getIndexes,cb:IndexeResponse,results:results})
                //     //     } catch (e) {}
                //     // }
            
                //     // function IndexeResponse(status, response,params) {
                //     //     if (status != 200) return;
                //     //     try {
                //     //         response = JSON.parse(response);
                //     //         // var symbols = response.payload.symbols;
                //     //         var results = params.results;
                //     //         for (var i = 0; i < response.length; i++) {
                //     //             var fields = response[i];
                //     //             var item = {
                //     //                 symbol: fields.symbol,
                //     //                 name: fields.name,
                //     //                 exchDisp: " "
                //     //             };
    
                     
                //     //             if (item.symbol.toUpperCase().indexOf(value.toUpperCase()) === -1){
                //     //                 continue;
                //     //             }
                //     //             // results.push({
                //     //             //     display: [item.symbol + ' Optix'],
                //     //             //     data: item
                //     //             // });
                //     //             results.push({
                //     //                 display: [item.symbol, item.name,],
                //     //                 data: item
                //     //             });
                //     //         }
                //     //         // results.sort(SortArray)
                //     //         closure(results)
                //     //     } catch (e) {}
                //     // }
                //     // CIQ.postAjax({ url: url, cb: StockResponse,results:[]});
    
                // }
            }
            attachDriver(driver) {
                this.driver = driver;
            }
    
            close() {
                if (this.keyboardNavigation) {
                    // Position the highlight over the input to wait for the collapse animation to complete
                    this.highlightItem(this.input[0]);
                    // Reposition the highlight after css animation is complete.
                    setTimeout(this.highlightItem.bind(this, this.input[0]), 250);
    
                    // Remove any focused property from the filter tabs
                    this.removeFocused(this.filterElements);
                    // Remove keyboard control from scroll
                    this.resultList[0].keyboardNavigation = null;
                }
                this.closest("cq-dialog,cq-menu").close();
            }
    
            forceInput() {
                var input = this.input[0];
                this.selectItem({ symbol: input.value });
                CIQ.blur(input);
                this.close();
                input.value = "";
            }
            async loadAllSymbolsList() {
                const res = await axios.get(
                    config.getAllSymbols
                )
                
                CIQ.store.commit('getAllSymbolsList',res.data);
            }
            async loadStocksList(){
                const res = await axios.get(
                    config.getStocks
                )
                //console.log('indicator-search save stocksList')
                CIQ.store.commit('getStocksList',res.data);
            }
            async loadIndexsList(){
                const res = await axios.get(
                    config.getIndexes
                )
                CIQ.store.commit('getIndexsList',res.data);
            }
            initialize() {
                // allSymbolsList for ALL tag is initiated in StockDataFeed
                //this.loadAllSymbolsList();
                this.loadStocksList();
                this.loadIndexsList();

                this.addDefaultMarkup();
                var node = this.node;
                this.resultList = node.find("cq-indicators-scroll");
    
                this.input = node.find("input");
                if (!this.input.length) {
                    var hiddenInput = document.createElement("input");
                    hiddenInput.setAttribute("type", "hidden");
                    hiddenInput.value = "";
                    this.input = node.append(hiddenInput);
                }
                CIQ.UI.stxtap(this.input[0], function () {
                    this.focus();
                });
                var self = this;
                
                Array.from(this.input).forEach(function (input) {
                    input.addEventListener("paste", function (e) {
                        var input = e.target;
                        setTimeout(function () {
                            self.acceptText(input.value, self.currentFilter);
                        }, 0);
                    });
                });
                var filters = this.querySelector("cq-indicators-lookup-filters");
                
                if (filters) {
                    var allFilters = filters.querySelectorAll("cq-indicators-filter");
                    var lookupInput = this.querySelector("cq-indicators-lookup-input");

                    allFilters.forEach(function (filter) {   
                        // a dumb function to solve the display bug     
                        CIQ.UI.stxtap(lookupInput, function () {
                            allFilters.forEach(function (f) {
                                if(f.classList.contains("true")){
                                    self.acceptText(self.input.val(), f.innerHTML);
                                }
                            });
                        });
                        
                        CIQ.UI.stxtap(filter, function () {
                            allFilters.forEach(function (f) {
                                f.classList.remove("true");
                            });
                            this.classList.add("true");
                            //console.log(typeof self.currentFilter)
                            var translate = this.querySelector("translate");
                            if (translate) {
                                // if the filter text has been translated then it will be in a <translate> tag
                                self.currentFilter = translate.getAttribute("original");
                            } else {
                                self.currentFilter = this.innerHTML;
                            }
                            self.acceptText(self.input.val(), self.currentFilter);
                        });

                        CIQ.UI.stxtap()
                    });
                }
    
                if (typeof node.attr("cq-keystroke-claim") != "undefined") {
                    // add keyboard claim for entire body
                    this.addClaim(this);
                }    
                self.currentFilter = "ALL"     
            }
    
            isActive() {
                return this.input[0].value !== "";
            }
    
            // Note that this captures keystrokes on the body. If the input box is focused then we need to allow the input box itself
            // to handle the strokes but we still want to capture them in order to display the lookup results. We first check
            // activeElement to see if the input is focused. If so then we bypass logic that manipulates the input.value. In order make
            // sure that the lookup menu is responding to an up-to-date input.value therefore we have to put all of those pieces of code
            // in setTimeout(0)
            //
            // Note that when comparisons are enabled, there are two Lookup components on the screen. Each keypress will therefore pass
            // through this function twice, once for each Lookup component. Only the active component will process the keystroke.
            keyStroke(hub, key, e, keystroke) {
                if (keystroke.ctrl || keystroke.cmd) return false;
                if (key == "Meta" || key == "Win") return false;
    
                var input = this.input[0];
                var result = false;
                var focused = document.activeElement === input; // If focused then we need to allow the input box to get most keystrokes
                // Rejecting alt key combinations only when the input is out of focus because some special chars can be typed with an alt key
                if (
                    !focused &&
                    (e.altKey ||
                        (document.activeElement &&
                            (document.activeElement.tagName == "INPUT" ||
                                document.activeElement.tagName == "TEXTAREA")))
                ) {
                    return false; // either an alt key combination was pressed or some other input has focus
                }
    
                var iAmActive = false,
                    iAmDisplayed = false;
                if (CIQ.climbUpDomTree(this, ".stxMenuActive").length) {
                    iAmDisplayed = true; // if my menu chain is active then I'm alive
                }
                if (focused || iAmDisplayed) iAmActive = true; // If my input is focused or I'm displayed, then I'm alive
                if (!iAmActive) {
                    // Otherwise, I may still be alive under certain conditions
                    if (typeof this.node.attr("cq-keystroke-default") == "undefined")
                        return; // I'm always alive if I have default body keystrokes
                    if (!iAmDisplayed && this.uiManager.topMenu()) return; // unless there's another menu active and it isn't me
                }
                if ((key === " " || key === "Spacebar") && input.value === "") {
                    return false;
                }
                var self = this;
                var focusedElements = this.findFocused(this.filterElements);
    
                switch (key) {
                    case "Delete":
                    case "Backspace":
                    case "Del":
                        if (input.value.length) {
                            //ctrl-a or highlight all text + delete implies remove all text
                            if (window.getSelection().toString()) {
                                input.value = "";
                            } else {
                                if (!focused)
                                    input.value = input.value.substring(0, input.value.length - 1);
                                if (input.value.length) {
                                    self.acceptText(input.value, self.currentFilter);
                                }
                            }
    
                            result = true; // only capture delete key if there was something to delete
                        }
                        if (key == "Backspace") result = true; // always capture backspace because otherwise chrome will navigate back
                        break;
                    case "Escape":
                    case "Esc":
                        input.value = "";
                        this.close();
                        CIQ.blur(input);
                        result = true;
                        break;
                    case "Enter":
                        if (input.value === "" || !this.isActive()) break;
    
                        var scrollable = this.resultList;
                        focused = scrollable.length && scrollable[0].focused(); // Using cursor keys to maneuver down lookup results
                        if (focused && focused.selectFC) {
                            focused.selectFC.apply(focused, {});
                        } else {
                            var val = input.value;
                            var toUpperCase =
                                ["false", "0", null].indexOf(this.getAttribute("cq-uppercase")) ==
                                -1;
                            if (toUpperCase) val = val.toUpperCase();
                            if(self.currentFilter == 'ALL'){
                                for(var i=0;i<CIQ.store.state.allSymbolsList.length;i++){
                                    var fields = CIQ.store.state.allSymbolsList[i]
                                    if(scrollable[0].firstChild.firstChild.innerHTML == fields.chart_name){       
                                        var item = {
                                            name: fields.chart_name,
                                            url: fields.url
                                        };
                                        this.selectItem(item)
                                    }   
                                }
                            }else{
                                CIQ.getFavorite().then(data=>{
                                    var resu = JSON.parse(data.favorite_indicator)
                                    try {
                                        resu.forEach(element => {
                                            if(scrollable[0].firstChild.firstChild.innerHTML == element.name){
                                                var item = {
                                                    symbol: element.url,
                                                    name: element.name,
                                                    exchDisp: ""
                                                }
                                                this.selectItem(item)
                                            } 
                                        });  
                                    } catch (e) {}
                                })
                            }
                            //scrollable[0].firstChild.firstChild.innerHTML
                            //this.selectItem({ symbol: val });
                        }
    
                        CIQ.blur(input);
                        this.close();
                        input.value = "";
                        result = true;
                        break;
                    case "ArrowRight":
                    case "Right":
                        if (focusedElements.length) {
                            // Remove control from the result list
                            if (this.resultList[0].keyboardNavigation)
                                this.resultList[0].keyboardNavigation = null;
                            // Ignore right if a tab is not focused to allow cursor movement in input
                            this.focusNextItem(this.filterElements);
                            this.clickFocusedItem(this.filterElements, e);
                        }
                        break;
                    case "ArrowLeft":
                    case "Left":
                        // Remove control from the result list
                        if (this.resultList[0].keyboardNavigation)
                            this.resultList[0].keyboardNavigation = null;
                        // Ignore left if a tab is not focused to allow cursor movement in input
                        if (focusedElements.length) {
                            this.focusNextItem(this.filterElements, true);
                            this.clickFocusedItem(this.filterElements, e);
                        }
                        break;
                    case "ArrowDown":
                    case "Down":
                        // Up/Down arrows are only used in this component when keyboard navigation is enabled
                        if (!this.keyboardNavigation) break;
                        // If no tab is focused, then give the first one focus, otherwise, pass control to the resultList
                        focusedElements = this.findFocused(this.filterElements);
                        if (!focusedElements.length) {
                            // If a tab hasn't been focused, highlight the active one.
                            for (
                                let filterIdx = 0;
                                filterIdx < this.filterElements.length;
                                filterIdx++
                            ) {
                                let filterElement = this.filterElements[filterIdx];
                                if (filterElement.classList.contains("true")) {
                                    this.focusItem(filterElement);
                                    break;
                                }
                            }
                        } else if (!this.resultList[0].keyboardNavigation) {
                            // Only pass control to the result list if there are results
                            var resultItem = this.resultList[0].querySelector("cq-item");
                            if (resultItem)
                                this.resultList[0].keyboardNavigation = this.keyboardNavigation;
                        }
                        CIQ.blur(input);
                        break;
                    case "ArrowUp":
                    case "Up":
                        // Up/Down arrows are only used in this component when keyboard navigation is enabled
                        if (!this.keyboardNavigation) break;
                        // resultList has its own up/down control.
                        if (this.resultList[0].keyboardNavigation) {
                            // If the scroll has control, check for the top item selected and move highlight back to the tabs
                            var firstResult = this.resultList[0].querySelector(
                                "cq-item:first-of-type"
                            );
                            if (firstResult && firstResult.hasAttribute("cq-focused")) {
                                firstResult.removeAttribute("cq-focused");
                                this.resultList[0].keyboardNavigation = null;
                                this.highlightFocusedItem(this.filterElements);
                            }
                        } else if (focusedElements.length) {
                            //If a tab has the highlight, reset the highlight back to the input
                            this.removeFocused(focusedElements);
                            this.highlightItem(input);
                            CIQ.focus(input);
                        }
                        break;
                    default:
                        // Prevent keys like Control and ArrowLeft from triggering focus
                        if (key.length === 1) {
                            // Changes the <input> value when keystrokes are registered against the body.
                            if (!focused) input.value = input.value + key;
                            self.acceptText(input.value, self.currentFilter);
                            result = true;
                        }
                        break;
                }
    
                if (result) {
                    // If we're focused, then keep the lookup open unless we hit escape.
                    // Otherwise, if there is no length close it (user hit "escape", "enter", or "backspace/delete" while unfocused)
                    if (
                        this.usingEmptyDriver ||
                        (!input.value.length &&
                            (key == "Escape" || key == "Esc" || key == "Enter" || !focused))
                    ) {
                        this.close();
                    } else {
                        this.open();
                    }
                    if (focused) return { allowDefault: true };
                    return true;
                }
            }
    
            open() {
                // Reposition the highlight after css animation is complete.
                window.setTimeout(this.highlightItem.bind(this, this.input[0]), 250);
                this.closest("cq-dialog,cq-menu").open();
            }
    
            onKeyboardDeselection() {
                CIQ.blur(this.input[0]);
                this.close();
                // If we're using keyboard navigation, return the highlight to the tab selected element
                if (this.keyboardNavigation) this.keyboardNavigation.highlightPosition();
                this.resultList[0].keyboardNavigationWait = false;
            }
    
            onKeyboardSelection() {
                // If we're using keyboard navigation, return the highlight to the tab selected element
                this.highlightItem(this.input[0]);
                CIQ.focus(this.input[0]);
                this.resultList[0].keyboardNavigationWait = true;
                this.open();
            }
    
            /**
             * Displays an array of results returned by the {@link CIQ.ChartEngine.Driver.Lookup}.
             *
             * Each element in the array should be in the following format (see
             * {@link CIQ.ChartEngine.Driver.Lookup#acceptText}):
             * ```
             * {
             *     display: ["symbol ID", "symbol description", "exchange"],
             *     data: {
             *         symbol: "symbol ID",
             *         name: "symbol description",
             *         exchDis: "exchange"
             *     }
             * }
             * ```
             *
             * The lookup component by default displays three columns as represented by the array. The
             * data object can be a format required by your quote feed, or it can be a simple string
             * if you just need to support a stock symbol.
             *
             * @param {array} arr The array of results.
             *
             * @alias results
             * @memberof WebComponents.cq-lookup#
             */
            

            results(arr) {
                function closure(self, data) {
                    return function (e) {
                        CIQ.blur(self.input[0]);
                        //self.close();
                        self.selectItem(data);
                        self.input[0].value = "";
                    };
                }
                var filters = this.querySelector("cq-indicators-lookup-filters");
                var allFilters = filters.querySelectorAll("cq-indicators-filter");
                var currentFilter;
                allFilters.forEach(function (f) {     
                     if(f.classList.contains("true")){
                        currentFilter = f.innerHTML;
                    }
                });

                this.resultList = CIQ.UI.$(this.resultList);
                this.resultList.empty();
                for (var i = 0; i < arr.length; i++) {
                    var item = arr[i];
                    var nodeText = "";

                    for (var j = 0; j < item.display.length; j++) {
                        nodeText += "<SPAN>" + item.display[j] + "</SPAN>";
                    }
                    if(currentFilter == 'FAVORITES'){
                        nodeText += "<div class='ciq-icon ciq-close st-close'></div>"
                    }
                    
                    var node = document.createElement("cq-item");
                    node.innerHTML = nodeText;
                    this.resultList.append(node);
                    node.selectFC = closure(this, item.data);
                    CIQ.UI.stxtap(node.querySelector("span"), node.selectFC);
                }
                var scrollable = this.resultList;
                if (scrollable[0]) scrollable[0].top();
    
                // Reset the hilight position
                this.highlightFocusedItem(this.filterElements);
            }
    
            /**
             * Accepts a new symbol or symbol object.
             *
             * @param {object} data Contains a symbol or symbol object in a form accepted by
             * 		{@link CIQ.ChartEngine#loadChart}.
             * @param {function} fn Function to execute when the callback set by
             * 		[setCallback]{@link WebComponents.cq-lookup#setCallback} finishes.
             *
             * @alias selectItem
             * @memberof WebComponents.cq-lookup#
             * @since 8.2.0 Removed the `params` parameter. Added the `fn` parameter.
             */
            selectItem(data, fn) {
                // if (data.symbol ==undefined){
                // 	this.getIndicatorMatedata(data.url,data.name)
                // }else{
                // 	this.getIndicatorMatedata(data.symbol,data.symbol)
                // }
                // if (data.url == undefined && data.symbol!= undefined){
                //     data.url = data.symbol
                // }
                
                // avoid add indicator redundantly
                for (var studyInstanceName in CIQ.stxx.layout.studies) {
					var sd = CIQ.stxx.layout.studies[studyInstanceName]
					if (sd.type == data.url) {return}
                }
                CIQ.addCover()
                CIQ.store.commit("setCurrentSenti",{url: data.url, name: data.name})
                
                let extraIndicators = []
                extraIndicators.push(...CIQ.store.state.indicators.extraIndicators)
                
                if (data.symbol == undefined){
                    extraIndicators.push(data.url)
                    //CIQ.store.commit()
                }else{
                    extraIndicators.push(data.symbol)
                }
                
                CIQ.store.commit('getExtraIndicators',extraIndicators)

                let indicatorsList = [CIQ.store.state.indicators.formIndicators.entry,CIQ.store.state.indicators.formIndicators.exit]
                // remove redundant elements and empty string

                for(var i=0;i<indicatorsList.length;i++){
                    if(indicatorsList[i]==''){
                    indicatorsList.splice(i,1)
                    i--;
                    }
                }
                indicatorsList = indicatorsList.concat(extraIndicators)
                const set = new Set(indicatorsList)
                indicatorsList = [...set]

                for (var studyInstanceName in CIQ.stxx.layout.studies) {
                    CIQ.Studies.removeStudy(CIQ.stxx, CIQ.stxx.layout.studies[studyInstanceName])
                }

                this.getIndicatorMatedata(indicatorsList,arguments[0])
                // if there's a built-in study in indicatorList, remove it before loading chart
                let techList = CIQ.store.state.indicators.technicalIndicators
                let list = []
                for(var i in indicatorsList){
                    if(techList.indexOf(indicatorsList[i]) == -1){
                        list.push(indicatorsList[i])
                    }
                } 
                CIQ.stxx.loadChart(	{ symbol: CIQ.symbol,startDate:new Date(),endDate:new Date(), indicator:list}, function () {
                    // callback - your code to be executed after the chart is loaded
                    CIQ.hideCover()
                    //alert("Load sucess")
                    //CIQ.loadMessage()
                    CIQ.hideMarker()
                    for (var studyInstanceName in CIQ.stxx.layout.studies) {                  
                        var sd = CIQ.stxx.layout.studies[studyInstanceName];
        
                        var panel = CIQ.stxx.panels  
                        //panel["‌etf_spy‌ (13,n)"].yAxis.displayGridLines = true;
                        //CIQ.stxx.setYAxisPosition(panel["‌etf_spy‌ (13,n)"].yAxis,"left")
                        //CIQ.Studies.createYAxis(panel["‌etf_spy‌ (13,n)"],)
                        //console.log(panel["‌etf_spy‌ (13,n)"])
                        CIQ.stxx.draw();
                        
                    }
                    
                })
            }
    		getIndicatorMatedata(indicatorList,period){
                var color = ["rgb(26 139 251)","#7257f2",'black',"#ff8a8a","#f98e23"]
                for (var studyInstanceName in CIQ.stxx.layout.studies) {
                    
                    var sd = CIQ.stxx.layout.studies[studyInstanceName];
                    if (CIQ.studys.indexOf(sd.type) === -1){
                        CIQ.Studies.removeStudy(CIQ.stxx, sd);
                    }
                }

                var chartBox = document.getElementsByClassName("chart_box")[0]
                var height = 65 + indicatorList.length*15
                chartBox.style.height = height.toString()+ 'vh'
                    
                for(var i in indicatorList){
                    let techList = CIQ.store.state.indicators.technicalIndicators
                    if(techList.indexOf(indicatorList[i]) != -1){
                        // load built-in study, no need for adding MA
                        // if it's a built-in study, skip sending query
                        var sd = CIQ.Studies.addStudy(CIQ.stxx, indicatorList[i],{display:indicatorList[i]});
                        continue
                    }
                    var queryUrl =  config.indicatorMetadata + 
                    "?indicator=" + indicatorList[i];
            
                    console.log(queryUrl);
                    (function(i){
                        // now it changed to async call
                        var server = new XMLHttpRequest();   
                        server.open("GET", queryUrl,true);
                        server.setRequestHeader("Authorization", "Basic " + btoa(config.username+":"+config.password));  
                        server.send(null);
            
                        // timeout detector
                        server.ontimeout = function(){
                            console.log('request timeout')
                        }
            
                        server.onreadystatechange = function(){
                            // load list from vuex
                            if(server.readyState == 4){
                                if (server.status===200) {
                                    console.log(server.statusText)
                                    try {
                                        // load list from vuex
                                        let indicatorsList = [CIQ.store.state.indicators.formIndicators.entry,CIQ.store.state.indicators.formIndicators.exit]
                                        for(var k=0;k<indicatorsList.length;k++){
                                          if(indicatorsList[k]==''){
                                            indicatorsList.splice(k,1)
                                            k--;
                                          }
                                        }
                                        indicatorsList = indicatorsList.concat(CIQ.store.state.indicators.extraIndicators)
                                        const set = new Set(indicatorsList)
                                        indicatorsList = [...set]
                                    
                                        if(indicatorsList.length==0){
                                            indicatorsList = ['AAPL']
                                        }
                                        indicatorList = indicatorsList
                                        // console.log("after nreadystatechange: ",indicatorList)
                                        // console.log("index i is:",i)
                                            var newQuotes = JSON.parse(server.response);
                                            
                                            if (newQuotes !== null){
                                                var newStudy = {
                                                    inputs: { Period: 13, Overlay: false},
                                                    outputs: 
                                                    {indicatorClose:color[i%5],description: newQuotes.description,url:indicatorList[i]},
                                                    parameters: { init: {
                                                        studyOverZonesEnabled: true,
                                                        studyOverBoughtValue: newQuotes.opt_extreme,
                                                        studyOverBoughtColor: "#FF0000",
                                                        studyOverSoldValue: newQuotes.pess_extreme,
                                                        studyOverSoldColor: "#00DD00",
                                                    }},
                                                    attributes:{
                                                        studyOverBoughtValue:{"step":0.01},
                                                        studyOverSoldValue:{"step":0.01}
                                                    }
                                                }
                                                
                                                    var str = JSON.stringify(newStudy);                                   
                                                    str = str.replace(/indicatorClose/g, indicatorList[i]);
                                                    newStudy = JSON.parse(str)                                     
                                                    
                                                    CIQ.Studies.studyLibrary[indicatorList[i]] = newStudy
                                                    var sd = CIQ.Studies.addStudy(CIQ.stxx,indicatorList[i])
                                                    var newExtremeValue = {indicator:indicatorList[i],extremeOptimism:sd.parameters.studyOverBoughtValue,extremePessimism:sd.parameters.studyOverSoldValue}
                                                    var extremeValueList = CIQ.store.state.extremeValue
                                                
                                                    if(!extremeValueList.some((item)=>{return item.indicator == newExtremeValue.indicator})){
                                                        
                                                        extremeValueList.push(newExtremeValue)
                                                    }
                                                    console.log('curremt extremeValueList is: ',extremeValueList)
                                                    CIQ.store.commit("getExtremeValue", extremeValueList)
                                                    console.log(sd)
                                                // stxx.panels[sd.panel].yAxis
                                                
                                            }
                                    }catch (e) {
                                        if (newQuotes !== null){
                                            var newStudy = {
                                                inputs: { Period: 13, Overlay: false,},
                                                outputs: 
                                                {indicatorClose:color[i%5],description: newQuotes.description,url:indicatorList[i]},
                                                parameters: { init: {
                                                    studyOverZonesEnabled: true,
                                                    studyOverBoughtValue: 80,
                                                    studyOverBoughtColor: "#FF0000",
                                                    studyOverSoldValue: 20,
                                                    studyOverSoldColor: "#00DD00",
                                                }},
                                                attributes:{
                                                    studyOverBoughtValue:{"step":0.01},
                                                    studyOverSoldValue:{"step":0.01}
                                                }
                                            }
                                            
                                            var str = JSON.stringify(newStudy);                                   
                                            str = str.replace(/indicatorClose/g, indicatorList[i]);
                                            newStudy = JSON.parse(str)                                     
                                            
                                            CIQ.Studies.studyLibrary[indicatorList[i]] = newStudy
                                            var sd = CIQ.Studies.addStudy(CIQ.stxx,indicatorList[i])
                                            var newExtremeValue = {indicator:indicatorList[i],extremeOptimism:sd.parameters.studyOverBoughtValue,extremePessimism:sd.parameters.studyOverSoldValue}
                                            var extremeValueList = CIQ.store.state.extremeValue
                                        
                                            if(!extremeValueList.some((item)=>{return item.indicator == newExtremeValue.indicator})){
                                                
                                                extremeValueList.push(newExtremeValue)
                                            }
                                            console.log('curremt extremeValueList is: ',extremeValueList)
                                            CIQ.store.commit("getExtremeValue", extremeValueList)
                                            console.log(sd)
                                        }
                                    }
                                }else{
                                    console.error(server.statusText)
                                }
                            }
                        }
                        
                        server.onerror = function(e){
                            console.error(server.statusText)
                        }
                    })(i)
                }
                console.log(CIQ.store.state.activatedMA)
                            
                for(var i in CIQ.store.state.activatedMA){
                    if(CIQ.store.state.activatedMA[i].url != ''){
                        if(CIQ.store.state.activatedMA[i].url == 'ma'){
                            var sd = CIQ.Studies.addStudy(CIQ.stxx, 'ST MA', {
                                // Type: CIQ.store.state.activatedMA[i].type,
                                // Period: CIQ.store.state.activatedMA[i].period,
                                display: 'ST MA',
                            })
                        }else{
                            sd = CIQ.Studies.addStudy(CIQ.stxx, "ST MA",{Period: CIQ.store.state.activatedMA[i].period,display:"ST MA",Field: CIQ.store.state.activatedMA[i].url});
                        }    
                    }   
                }
            }
            /**
             * Sets a callback function to be called when the user selects a symbol.
             *
             * @param {function} cb The callback function; for example, an implementation of
             * 		{@link CIQ.UI.Context#changeSymbol}.
             *
             * @alias setCallback
             * @memberof WebComponents.cq-lookup#
             */
            setCallback(cb) {
                this.params.cb = cb;
            }
    
            setContext(context) {
                this.initialize();
    
                const symbolInput = this.querySelector("cq-indicators-lookup-input input");
                const { config, stx } = context;
                if (!config) return;
                const { channels = {} } = config;
                this.channelSubscribe(
                    channels.breakpoint || "channel.breakpoint",
                    (breakPoint) => {
                        var placeholder = stx.crossSection
                            ? stx.crossSection.symbolInputType
                            : "Select Sentiment Indicators";
                        if (breakPoint === "break-lg") {
                            placeholder = "" + placeholder;
                        }
                        symbolInput.setAttribute(
                            "placeholder",
                            breakPoint === "break-sm" ? "" : placeholder
                        );
                    }
                );

    
                // Get a list of filter tabs for keyboard navigation
                this.filterElements = this.querySelectorAll(
                    "cq-indicators-lookup-filters cq-indicators-filter"
                );
                    
                if (!this.params.cb && context.changeSymbol)
                    this.params.cb = context.changeSymbol;
            }
    
            /**
             * Connects a {@link CIQ.ChartEngine.Driver.Lookup} to the web component.
             *
             * The lookup driver searches financial exchanges for symbols that match the text entered
             * in the component's input field.
             *
             * @param {CIQ.ChartEngine.Driver.Lookup} driver The lookup driver to connect to the web
             * 		component.
             *
             * @alias setDriver
             * @memberof WebComponents.cq-lookup#
             */
            setDriver(driver) {
                this.params.driver = driver;
            }
        }
    
        IndicatorsLookup.markup = `
            <cq-indicators-lookup-input cq-no-close>
                <input type="text" spellcheck="false" autocomplete="off" autocorrect="off" autocapitalize="none" name="symbol" placeholder="Select Sentiment Indicators">
                <cq-lookup-icon class="ciq-lookup-icon"></cq-lookup-icon>
            </cq-indicators-lookup-input>
            <cq-indicators-lookup-results>
                <cq-indicators-lookup-filters cq-no-close>
                  
                    <cq-indicators-filter class="true">ALL</cq-indicators-filter>
                    <cq-indicators-filter>FAVORITES</cq-indicators-filter>
                </cq-indicators-lookup-filters>
                <cq-indicators-scroll></cq-indicators-scroll>
            </cq-indicators-lookup-results>
        `;
        CIQ.UI.addComponentDefinition("cq-indicators-lookup", IndicatorsLookup);
    }
    
    };
export {__js_webcomponents_indicatorsLookup_}