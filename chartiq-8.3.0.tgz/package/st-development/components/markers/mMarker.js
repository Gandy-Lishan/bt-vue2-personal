//
// Sample trade analytics with markers
// This file contains functions which create a sample implementation of post trade analysis using markers.  This file is meant to be used in conjuction with the markersSample.js file by extending the functionality of MarkersSample. There is a stylesheet which goes along with it as well.
// Usage: new MarkersSample(stxx);
//
import { CIQ, markers } from "../../../js/standard.js";
import marker from "./markersSample.js";
var _css;
if (
	typeof define === "undefined" &&
	typeof module === "object" &&
	typeof require === "function"
)
	_css = require("./tradeAnalyticsSample.css");
else if (typeof define === "function" && define.amd)
	define(["./tradeAnalyticsSample.css"], function (m) {
		_css = m;
	});
else if (typeof window !== "undefined")
	CIQ.loadStylesheet("st-development/components/markers/tradeAnalyticsSample.css");
if (_css) CIQ.addInternalStylesheet(_css, "tradeAnalyticsSample.css");
CIQ.activateImports(markers);

CIQ.Marker.STSimple = function (params) {
	var node = (this.node = document.createElement("div"));
	node.className = "stx-marker";
	node.classList.add(params.type);
	if (params.category) node.classList.add(params.category);
	var stem = CIQ.newChild(node, "div", "stx-stem");
	stem.style.float = 'none'
	stem.style.marginLeft = '12px'
	
	var visual = CIQ.newChild(node, "div", "stx-visual");

	var expand;
	if (params.type == "callout") {
		var content = CIQ.newChild(visual, "div", "stx-marker-content");
		CIQ.newChild(content, "h4", null, params.headline);
		expand = CIQ.newChild(content, "div", "stx-marker-expand");
		CIQ.newChild(expand, "p", null, params.story);
	} else {
		expand = CIQ.newChild(node, "div", "stx-marker-expand");
		CIQ.newChild(expand, "h4", null, params.headline);
		CIQ.newChild(expand, "p", null, params.story);
		CIQ.safeClickTouch(expand, function (e) {
			node.classList.toggle("highlight");
		});
	}

	function cb() {
		CIQ.Marker.positionContentVerticalAndHorizontal(node);
	}
	CIQ.safeClickTouch(visual, function (e) {
		node.classList.toggle("highlight");
		setTimeout(cb, 10);
	});
	this.nodeType = "Simple";
	this.expand = expand;
};

CIQ.inheritsFrom(CIQ.Marker.STSimple, CIQ.Marker.NodeCreator, false);


const MarkersSample = marker.MarkersSample;
MarkersSample.registerType("mMarker", "showmMarker");
let mDataSet = []
MarkersSample.prototype.loadDataSet = function(dataSet){
	mDataSet =  dataSet
	//console.log("loadDataSet",dataSet)
},
MarkersSample.prototype.showmMarker = function () {
	if (!CIQ.Marker.Performance) {
		return console.error(
			"tradeAnalyticsSample feature requires first activating highPerformanceMarkers feature."
		);
	}
	var markerTypes = ["analysis","dividend"];
	let { stx } = this;
	// //(stx.chart.dataSegment[stx.chart.dataSegment.length - 1].Date); 
	
	for (var data in mDataSet) {
			var color = mDataSet[data].Type === 'BUY' ? 0 : 1
			
			var datatime = new Date(mDataSet[data].DT)
			var offset = new Date().getTimezoneOffset() * 60 * 1000
			//newQuotes[i].DT = new Date(datatime.setTime(datatime.getTime() + offset));
			if(mDataSet[data].Type == "BUY"){
				
				var a = new CIQ.Marker({
					stx: stx,
					label: "circle",
					xPositioner: "date",
					yPositioner: "below_candle",
					x: new Date(datatime.setTime(datatime.getTime() + offset)),
					node: new CIQ.Marker.STSimple({
						type: "circle",
						headline: mDataSet[data].Type,
						category: markerTypes[color],
						story:
							'trade entered on ' +  mDataSet[data].DT + '\nat ' + mDataSet[data].Price + '\ndue to ' + mDataSet[data].Indicator
					})
				});
			}else{
				var a = new CIQ.Marker({
					stx: stx,
					label: "circle",
					xPositioner: "date",
					x: new Date(datatime.setTime(datatime.getTime() + offset)),
					node: new CIQ.Marker.Simple({
						type: "circle",
						headline: mDataSet[data].Type,
						category: markerTypes[color],
						story:
							'trade entered on ' +  mDataSet[data].DT + '\nat ' + mDataSet[data].Price + '\ndue to ' + mDataSet[data].Indicator
					})
				});
			}
			
	}
	return ["circle"];
};

export default marker;
