//
// Sample trade analytics with markers
// This file contains functions which create a sample implementation of post trade analysis using markers.  This file is meant to be used in conjuction with the markersSample.js file by extending the functionality of MarkersSample. There is a stylesheet which goes along with it as well.
// Usage: new MarkersSample(stxx);
//
import { CIQ, markers } from "../../../js/standard.js";
import marker from "./markersSample.js";
var _css;
if (
	typeof define === "undefined" &&
	typeof module === "object" &&
	typeof require === "function"
)
	_css = require("./tradeAnalyticsSample.css");
else if (typeof define === "function" && define.amd)
	define(["./tradeAnalyticsSample.css"], function (m) {
		_css = m;
	});
else if (typeof window !== "undefined")
	CIQ.loadStylesheet("st-development/components/markers/tradeAnalyticsSample.css");
if (_css) CIQ.addInternalStylesheet(_css, "tradeAnalyticsSample.css");
CIQ.activateImports(markers);
const MarkersSample = marker.MarkersSample;
MarkersSample.registerType("mMarker", "showmMarker");
let mDataSet = []
MarkersSample.prototype.loadDataSet = function(dataSet){
	mDataSet =  dataSet
},
MarkersSample.prototype.showmMarker = function () {
	if (!CIQ.Marker.Performance) {
		return console.error(
			"tradeAnalyticsSample feature requires first activating highPerformanceMarkers feature."
		);
	}
	var markerTypes = ["analysis","dividend"];
	let { stx } = this;
	// console.log(stx.chart.dataSegment[stx.chart.dataSegment.length - 1].Date); 
    
	for (var data in mDataSet) {
			var color = mDataSet[data].Type === 'BUY' ? 0 : 1
			console.log(new Date(mDataSet[data].DT))
			
			new CIQ.Marker({
				stx: stx,
				label: "circle",
				xPositioner: "date",
				x: new Date(mDataSet[data].DT),
				node: new CIQ.Marker.Simple({
					type: "circle",
					headline: mDataSet[data].Type,
					category: markerTypes[color],
					story:
						'\ntrade entered on ' +  mDataSet[data].DT + '\nat ' + mDataSet[data].Price + '\ndue to ' + mDataSet[data].Indicator
				})
			});
	}
	return ["circle"];
};

export default marker;
