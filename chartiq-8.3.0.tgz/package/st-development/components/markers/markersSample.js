//
// Sample markers file
// This file contains functions which create sample markers.  There is a stylesheet which goes along with it as well.
// Usage: new MarkersSample(stxx);
//
import { CIQ, markers } from "../../../js/standard.js";
var _css;
if (
	typeof define === "undefined" &&
	typeof module === "object" &&
	typeof require === "function"
)
	_css = require("./markersSample.css");
else if (typeof define === "function" && define.amd)
	define(["./markersSample.css"], function (m) {
		_css = m;
	});
else if (typeof window !== "undefined")
	CIQ.loadStylesheet("st-development/components/markers/markersSample.css");
if (_css) CIQ.addInternalStylesheet(_css, "markersSample.css");
CIQ.activateImports(markers);
var MarkersSample = function (stx) {
	this.stx = stx;
	this.activeLabels = [];
};
/**
 * The specialTypes property provides a lookup of type -> method dictionary
 * that allows to extend MarketSample#showMarkers functionality with
 * additional event types not available in this file.
 * Use #registerType to populate it as it will provide additional extensibility in future
 */
MarkersSample.specialTypes = {};
/**
 * Registers new prototype method to as type handler be available in #showMarkers
 * When invoked the registered method will receive type and renderType parameters
 *
 * Example: register video event handler
 *
 *		MarkersSample.registerType('video', 'showVideoMarkers');
 *		MarkersSample.prototype.showVideoMarkers = function (type) {
 *		}
 *
 */
MarkersSample.registerType = function (type, methodName, overwrite) {
	if (this.specialTypes[type] && !overwrite) {
		console.error(
			"ERROR: failed to register event type " +
				type +
				". Event already registered"
		);
		return;
	}
	this.specialTypes[type] = methodName;
};
MarkersSample.prototype.processLabelsAndDraw = function (labels) {
	
	this.activeLabels = this.activeLabels.concat(labels);
	this.stx.draw();
	return labels;
};
MarkersSample.prototype.createMarkers = function (label, markerType) {
	var stx = this.stx,
		ds = stx.chart.dataSet,
		t = stx.tickFromDate(stx.chart.endPoints.end);
	// An example of a data array to drive the marker creation
	var data = [];
	if (!markerType) markerType = "Simple";
	if (!ds) return;
	while (t && !ds[t]) t--;
	if (t >= 5)
		data.push({
			x: ds[t - 5].DT,
			type: label,
			category: "news",
			headline: "This is a Marker for a News Item"
		});
	if (t >= 15)
		data.push({
			x: ds[t - 15].DT,
			type: label,
			category: "earningsUp",
			headline: "This is a Marker for Earnings (+)"
		});
	if (t >= 25)
		data.push({
			x: ds[t - 25].DT,
			type: label,
			category: "earningsDown",
			headline: "This is a Marker for Earnings (-)"
		});
	if (t >= 35)
		data.push({
			x: ds[t - 35].DT,
			type: label,
			category: "dividend",
			headline: "This is a Marker for Dividends"
		});
	if (t >= 45)
		data.push({
			x: ds[t - 45].DT,
			type: label,
			category: "filing",
			headline: "This is a Marker for a Filing"
		});
	if (t >= 55)
		data.push({
			x: ds[t - 55].DT,
			type: label,
			category: "split",
			headline: "This is a Marker for a Split"
		});
	var story =
		"Like all ChartIQ markers, the object itself is managed by the chart, so when you scroll the chart the object moves with you. It is also destroyed automatically for you when the symbol is changed.";
	// Loop through the data and create markers
	console.log(data)
	for (var i = 0; i < data.length; i++) {
		var datum = data[i];
		datum.story = story;
		// Add some additional copy to the first marker to demonstrate the scrollbar
		if (i == 0)
			datum.story +=
				" <br><br> The marker can also accommodate a large amount of text and will allow scrolling if the content does not fit in the available space. Lorem ipsum dolor sit amet, consectetur adipiscing elit. In risus quam, suscipit eu imperdiet sed, finibus vitae neque. Aenean gravida erat vel arcu bibendum pharetra. Nullam arcu nibh, ullamcorper a quam quis, aliquam mollis ex. Nulla lacus ligula, sollicitudin ac lacinia a, tempus nec sem. Aliquam erat volutpat. Phasellus magna mauris, maximus eget imperdiet eu, tincidunt ut neque. Maecenas rutrum nisl sed laoreet placerat. Nunc semper eu diam eget pretium. Fusce est lectus, feugiat nec metus sed, auctor laoreet ligula. Fusce et felis ut quam finibus porttitor. Fusce mollis felis quis velit rutrum laoreet. Maecenas dignissim mattis facilisis. Aenean tempor fermentum dictum.";
		new CIQ.Marker({
			stx: stx,
			label: label,
			xPositioner: "date",
			x: datum.x,
			node: new CIQ.Marker[markerType](datum)
		});
	}
	return label;
};
MarkersSample.prototype.createAbstractMarker = function (abstractType) {
	var stx = this.stx;
	var abstract = document
		.querySelector(".stx-marker-templates")
		.querySelector(".stx-marker.abstract")
		.cloneNode(true);
	Object.assign(abstract.style, {
		"z-index": 30,
		left: (0.4 * stx.chart.width).toString() + "px"
	});
	new CIQ.Marker({
		stx: stx,
		xPositioner: "none",
		yPositioner: "above_candle",
		label: abstractType,
		permanent: true,
		chartContainer: true,
		node: abstract
	});
	return abstractType;
};
MarkersSample.prototype.hideMarkers = function () {
	////('before hide lables: '+this.activeLabels)
	var stx = this.stx;
	this.activeLabels.forEach(function (label) {
		CIQ.Marker.removeByLabel(stx, label);
	});
	this.activeLabels = [];
};
MarkersSample.prototype.showMarkers = function (type, renderType) {
	// Remove any existing markers
	////('type is: '+type)
	if (!type) {
		////('enter hide')
		return this.hideMarkers();
	}
	var specialType = MarkersSample.specialTypes[type];
	if (specialType) {
		return this.processLabelsAndDraw(this[specialType](type, renderType));
	}
	if (type === "abstract") {
		return this.processLabelsAndDraw(this.createAbstractMarker("helicopter"));
	}
	return this.processLabelsAndDraw(this.createMarkers(type, renderType));
};
let marker = { MarkersSample };
//console.log(MarkersSample.stx)
CIQ.loadChart = function(dataSet,callback){
	
	// 用setTimeout模拟异步耗时操作
	setTimeout(function(){
		callback()
	},0)
	CIQ.MarkersSample = new marker.MarkersSample(CIQ.stxx)
	CIQ.MarkersSample.loadDataSet(dataSet)
}
CIQ.addMarker = function(){
	CIQ.MarkersSample.showMarkers()
	CIQ.MarkersSample.showMarkers('mMarker')
	// CIQ.MarkersSample.showMarkers()
	// CIQ.MarkersSample.showMarkers('mMarker')

	CIQ.addPrompt()
}

CIQ.addPrompt = function(){
	var node = document.getElementsByClassName("stx-subholder")[0]
	
	var promptGreen = document.createElement("div");
	promptGreen.className = 'green'
	promptGreen.innerHTML = "<span style='margin-right:10px'><svg t='1641979722051' class='icon' viewBox='0 0 1024 1024' version='1.1' xmlns='http://www.w3.org/2000/svg' p-id='2092' width='30' height='30'><path d='M512 124L64 900h896z' p-id='2093' fill='#1afa29'></path></svg></span>BUY "
	node.appendChild(promptGreen)
	var promptRed = document.createElement("div");
	promptRed.className = 'red'
	promptRed.innerHTML = "<span style='margin-right:10px'><svg t='1636008125523' class='icon' viewBox='0 0 1024 1024' version='1.1' xmlns='http://www.w3.org/2000/svg' p-id='2169' width='30' height='30' ><path d='M525.873548 897.156129l-383.174193-761.723871 763.045161-1.981935-379.870968 763.705806z' p-id='2170' fill='#d81e06'></path></svg></span>SELL"
	node.appendChild(promptRed)
}

CIQ.removePrompt = function(){
	while(document.getElementsByClassName("green")[0]){
		var nodeGreen = document.getElementsByClassName("green")[0]
		var nodeRed = document.getElementsByClassName("red")[0]
		nodeGreen.remove()
		nodeRed.remove()
	}
}

CIQ.hideMarker = function(){
	try{
		console.log('Marker hide')
		CIQ.removePrompt()
		CIQ.MarkersSample.showMarkers()
	}catch(err){}	
}
export {CIQ};
export default marker;
