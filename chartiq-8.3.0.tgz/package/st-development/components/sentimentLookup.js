let __js_webcomponents_sentimentLookup_ = (_exports) => {

	/* global _CIQ, _timezoneJS, _SplinePlotter */
	
	
	
	
	
	var CIQ = typeof _CIQ !== "undefined" ? _CIQ : _exports.CIQ;
	
	/**
	 * The comparison lookup web component `<cq-sentiment-lookup>`.
	 *
	 * An encapsulation of the markup for the comparison lookup control, **+ Compare...**
	 *
	 * @namespace WebComponents.cq-comparison-sentiment
	 * @since 7.5.0
	 *
	 * @example
	 * <cq-comparison cq-marker>
	 *     <cq-menu class="cq-comparison-new" cq-focus="input">
	 *         <cq-comparison-add-label class="ciq-no-share">
	 *             <cq-comparison-plus></cq-comparison-plus><span>Compare</span><span>...</span>
	 *         </cq-comparison-add-label>
	 *         <cq-comparison-add>
	 *             <cq-comparison-lookup-frame>
	 *                 <cq-lookup cq-keystroke-claim cq-uppercase></cq-lookup>
	 *             </cq-comparison-lookup-frame>
	 *             <cq-swatch cq-no-close></cq-swatch>
	 *             <span><cq-accept-btn class="stx-btn">ADD</cq-accept-btn></span>
	 *         </cq-comparison-add>
	 *     </cq-menu>
	 * </cq-comparison>
	 */
	class SentimentLookup extends CIQ.UI.ContextTag {
		/**
		 * Adds the default markup.
		 *
		 * @alias setContext
		 * @memberof WebComponents.cq-sentiment-lookup
		 * @since 7.5.0
		 */
		setContext() {
			if (this.contextSet) return;
			this.contextSet = true;
			// this.addDefaultMarkup();
			this.initialize()
		}
		settest(){
			alert("aaaa")
		}
		initialize(){
			
			
			var div = this.node.find(".test")
			// this.params = params || {};
			if (window.localStorage.getItem("FavoriteSymbol")===null){
				window.localStorage.setItem("FavoriteSymbol","[]")
			}
		
			var indicators =JSON.parse(window.localStorage.getItem("FavoriteSymbol"))
			if (indicators.indexOf(CIQ.symbol) === -1){
				// add
				SentimentLookup.markup = `
				<cq-comparison cq-marker>
					<cq-menu class="cq-comparison-new" cq-focus="input">
					<div class="test" stxtap='SentimentLook.addSymbolCookie()'>add Favorite Symbol</div>
					</cq-menu>
				</cq-comparison>
			`;
				// var menu = this.node.find("cq-menu").innHTML=`<div stxtap='StudyEdit.addSymbolCookie()'>add Favorite Symbol</div>`
				// document.querySelectorAll(".cq-comparison-new")[0].querySelectorAll("div")[0].innerText = "add Favorite Symbol"
			}else{
				//del
				SentimentLookup.markup = `
				<cq-comparison cq-marker>
					<cq-menu class="cq-comparison-new" cq-focus="input">
					<div class="test" stxtap='SentimentLook.delSymbolCookie()'>del Favorite Symbol</div>
					</cq-menu>
				</cq-comparison>
			`;
				// var menu = this.node.find("cq-menu").innHTML= `<div stxtap='StudyEdit.addSymbolCookie()'>del Favorite Symbol</div>`
				// document.querySelectorAll(".cq-comparison-new")[0].querySelectorAll("div")[0].innerText = "del Favorite Symbol"
			}

			this.addDefaultMarkup();
		}
	
	}
	
	// SentimentLookup.markup = `
	// 		<cq-comparison cq-marker>
	// 			<cq-menu class="cq-comparison-new" cq-focus="input">
	// 			</cq-menu>
	// 		</cq-comparison>
	// 	`;

	
	CIQ.UI.addComponentDefinition("cq-sentiment-lookup", SentimentLookup);
	
	};

export {__js_webcomponents_sentimentLookup_}
    